// import React, { useEffect, useState } from 'react';
// import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Checkbox, Button, MenuItem, Select } from '@mui/material';
// import { Link } from 'react-router-dom';
// import axios from 'axios';
// import { evaluate } from 'mathjs'; // ... const expression = '2 + 3 * 4'; // 
//  // result will be 14


// const PatientOrderTable = () => {
//   const [selectedOrderId, setSelectedOrderId] = useState(null);
//   const [selectedMedicine, setSelectedMedicine] = useState('');
  
//   const[orders, setorders]=useState([]);
//   var patientId=sessionStorage.getItem("email");

//   window.addEventListener("unload", (event) => {
//     GetOrdersData();
//     console.log("API call after page reload");
//   });
//   useEffect(() => {
//     GetOrdersData();
//   }, []);
//   const GetOrdersData = async () => {
//     try {
//       const Response = await axios({
//         method: 'GET',
//         url: `http://localhost:9092/PatientOrders/${patientId}`, // Update with your actual endpoint
//         headers: { 'content-type': 'application/json' },
//       });

//       if (Response.data) {
//         console.log(Response.data);
//         setorders(Response.data.orders)
//       }
//       else {
//         alert("No Orders Found")
//       }
//     } catch (error) {
//       console.error('Error:', error);
//     }
//   }


//   const handleRowClick = (orderId) => {
//     setSelectedOrderId(orderId);
//     setSelectedMedicine(''); // Reset selectedMedicine when selecting a different order
//   };

//   const handledeliveryButton = () => {
//     alert("Delivery Started")
//     setSelectedOrderId(null);
//   };

//   const formatDate = (dateString) => {
//     const options = { year: 'numeric', month: 'long', day: 'numeric' };
//     const formattedDate = new Date(dateString);
//     formattedDate.setFullYear(formattedDate.getFullYear() - 2000);
//     return formattedDate.toLocaleDateString(undefined, options);
//   };
//   const calculateTotalAmount = (medicines) => {
//     return medicines.reduce((total, medicine) => {
//       const medicineTotal =parseInt(medicine.quantity_ordered) * parseInt(medicine.unitPrice);
//       return total + medicineTotal;
//     }, 0);
//   };


//   return (
//     <div>
//     <TableContainer component={Paper} style={{ marginLeft: '15rem', marginTop: '20px', marginBottom: '20px', width: '80%' }}>
//       <Table>
//         <TableHead>
//           <TableRow>
//             <TableCell>Order Id</TableCell>
//             <TableCell>Date of Booking</TableCell>
//             <TableCell>Date of Delivery</TableCell>
//             <TableCell>Amount</TableCell>
//             <TableCell>Current Status</TableCell>
//           </TableRow>
//         </TableHead>
//         <TableBody>
//           {orders.map((order) => (
//             <TableRow
//               key={order.orderId}
//               onClick={() => handleRowClick(order.orderId)}
//               style={{ cursor: 'pointer' }}
//             >
//               <TableCell component="th" scope="row">
//                 {order.orderId}
//               </TableCell>
//               <TableCell>{formatDate(order.orderDate)}</TableCell>
//               <TableCell>{formatDate(order.deliveryDate)}</TableCell>
//               <TableCell>
//               {calculateTotalAmount(order.medicines)} {/* Calculate and display total amount */}
//                 </TableCell>
//               <TableCell>{order.status}</TableCell>

//             </TableRow>
//           ))}
//         </TableBody>
//       </Table>
//     </TableContainer>

//     {selectedOrderId !== null && (
//       <div>
//         <TableContainer component={Paper} style={{ marginLeft: '15rem', marginBottom: '20px', width: '80%' }}>
//           <Table>
//             <TableHead>
//             <TableRow>
//                 <TableCell>Medicine Name</TableCell>
//                 <TableCell>Quantity</TableCell>
//                 <TableCell>Unit Price</TableCell>
//                 <TableCell>ManufacturerName</TableCell>
//               </TableRow>
//             </TableHead>
//             <TableBody>
//               {orders.find((o) => o.orderId === selectedOrderId).medicines.map((medicine, index) => (
//                 <TableRow key={index}>
//                   <TableCell>{medicine.medicineName}</TableCell>
//                   <TableCell>{medicine.quantity_ordered}</TableCell>
//                   <TableCell>{medicine.unitPrice}</TableCell>
//                   <TableCell>{medicine.manufacturerName}</TableCell>
//                 </TableRow>
//               ))}
//             </TableBody>
//           </Table>
//         </TableContainer>
//       </div>
//     )}
//   </div>
// );
// };

// export default PatientOrderTable;
// import React, { useEffect, useState } from 'react';
// import {
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   Paper,
//   Checkbox,
//   Button,
//   MenuItem,
//   Select,
//   IconButton,
//   Collapse,
//   TablePagination, // Import TablePagination for pagination
// } from '@mui/material';
// import { Link } from 'react-router-dom';
// import axios from 'axios';
// import { evaluate } from 'mathjs';
// import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
// import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';

// const PatientOrderTable = () => {
//   const [selectedOrderId, setSelectedOrderId] = useState(null);
//   const [selectedMedicine, setSelectedMedicine] = useState('');
//   const [orders, setOrders] = useState([]);
//   const [page, setPage] = useState(0); // Current page
//   const [rowsPerPage, setRowsPerPage] = useState(3); // Rows per page
//   const [expandedRows, setExpandedRows] = useState([]); 

//   const patientId = sessionStorage.getItem("email");

//   window.addEventListener("unload", (event) => {
//     GetOrdersData();
//     console.log("API call after page reload");
//   });

//   useEffect(() => {
//     GetOrdersData();
//   }, []);

//   const GetOrdersData = async () => {
//     try {
//       const Response = await axios({
//         method: 'GET',
//         url: `http://localhost:9092/PatientOrders/${patientId}`,
//         headers: { 'content-type': 'application/json' },
//       });

//       if (Response.data) {
//         console.log(Response.data);
//         setOrders(Response.data.orders);
//       } else {
//         alert("No Orders Found");
//       }
//     } catch (error) {
//       console.error('Error:', error);
//     }
//   };

//   const handleRowClick = (orderId) => {
//     setSelectedOrderId(orderId);
//     setSelectedMedicine('');
//   };

//   const handleDeliveryButton = () => {
//     alert("Delivery Started");
//     setSelectedOrderId(null);
//   };

//   const handleRowExpand = (orderId) => { // Define handleRowExpand
//     if (expandedRows.includes(orderId)) {
//       setExpandedRows(expandedRows.filter((id) => id !== orderId));
//     } else {
//       setExpandedRows([...expandedRows, orderId]);
//     }
//   };
//   const formatDate = (dateString) => {
//     const options = { year: 'numeric', month: 'long', day: 'numeric' };
//     const formattedDate = new Date(dateString);
//     formattedDate.setFullYear(formattedDate.getFullYear() - 2000);
//     return formattedDate.toLocaleDateString(undefined, options);
//   };

//   const calculateTotalAmount = (medicines) => {
//     return medicines.reduce((total, medicine) => {
//       const medicineTotal = parseInt(medicine.quantity_ordered) * parseInt(medicine.unitPrice);
//       return total + medicineTotal;
//     }, 0);
//   };

//   // Change the current page
//   const handleChangePage = (event, newPage) => {
//     setPage(newPage);
//   };

//   // Change the number of rows per page
//   const handleChangeRowsPerPage = (event) => {
//     setRowsPerPage(parseInt(event.target.value, 10));
//     setPage(0); // Reset page to 0 when changing rows per page
//   };

//   return (
//     <div>
//       <TableContainer component={Paper} style={{ marginLeft: '15rem', marginTop: '20px', marginBottom: '20px', width: '80%' }}>
//         <Table>
//           <TableHead>
//             <TableRow>
//               <TableCell />
//               <TableCell>Order Id</TableCell>
//               <TableCell>Date of Booking</TableCell>
//               <TableCell>Date of Delivery</TableCell>
//               <TableCell>Amount</TableCell>
//               <TableCell>Current Status</TableCell>
//             </TableRow>
//           </TableHead>
//           <TableBody>
//             {(rowsPerPage > 0
//               ? orders.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
//               : orders
//             ).map((order) => (
//               <React.Fragment key={order.orderId}>
//                 <TableRow
//                   onClick={() => handleRowClick(order.orderId)}
//                   style={{ cursor: 'pointer' }}
//                 >
//                   <TableCell>
//                     <IconButton
//                       size="small"
//                       onClick={() => handleRowExpand(order.orderId)}
//                     >
//                       {expandedRows.includes(order.orderId) ? (
//                         <KeyboardArrowUpIcon />
//                       ) : (
//                         <KeyboardArrowDownIcon />
//                       )}
//                     </IconButton>
//                   </TableCell>
//                   <TableCell component="th" scope="row">
//                     {order.orderId}
//                   </TableCell>
//                   <TableCell>{formatDate(order.orderDate)}</TableCell>
//                   <TableCell>{formatDate(order.deliveryDate)}</TableCell>
//                   <TableCell>
//                     {calculateTotalAmount(order.medicines)}
//                   </TableCell>
//                   <TableCell>{order.status}</TableCell>
//                 </TableRow>
//                 <TableRow>
//                   <TableCell colSpan={6}>
//                     <Collapse
//                       in={expandedRows.includes(order.orderId)}
//                       timeout="auto"
//                       unmountOnExit
//                     >
//                       {/* Render the expanded content here */}
//                       {/* ... (your expanded content) */}
//                     </Collapse>
//                   </TableCell>
//                 </TableRow>
//               </React.Fragment>
//             ))}
//           </TableBody>
//         </Table>
//         <TablePagination
//           rowsPerPageOptions={[5, 10, 25]}
//           component="div"
//           count={orders.length}
//           rowsPerPage={rowsPerPage}
//           page={page}
//           onPageChange={handleChangePage}
//           onRowsPerPageChange={handleChangeRowsPerPage}
//         />
//       </TableContainer>
//       {selectedOrderId !== null && (
//         <div>
//           <TableContainer component={Paper} style={{ marginLeft: '15rem', marginBottom: '20px', width: '80%' }}>
//             <Table>
//               <TableHead>
//                 <TableRow>
//                   <TableCell>Medicine Name</TableCell>
//                   <TableCell>Quantity</TableCell>
//                   <TableCell>Unit Price</TableCell>
//                   <TableCell>ManufacturerName</TableCell>
//                 </TableRow>
//               </TableHead>
//               <TableBody>
//                 {orders.find((o) => o.orderId === selectedOrderId).medicines.map((medicine, index) => (
//                   <TableRow key={index}>
//                     <TableCell>{medicine.medicineName}</TableCell>
//                     <TableCell>{medicine.quantity_ordered}</TableCell>
//                     <TableCell>{medicine.unitPrice}</TableCell>
//                     <TableCell>{medicine.manufacturerName}</TableCell>
//                   </TableRow>
//                 ))}
//               </TableBody>
//             </Table>
//           </TableContainer>
//         </div>
//       )}
//     </div>
//   );
// };

// export default PatientOrderTable;
import React, { useEffect, useState } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Collapse,
  TablePagination,
  TableSortLabel, // Import TableSortLabel for sorting
} from '@mui/material';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { evaluate } from 'mathjs';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';

const PatientOrderTable = () => {
  const [selectedOrderId, setSelectedOrderId] = useState(null);
  const [selectedMedicine, setSelectedMedicine] = useState('');
  const [orders, setOrders] = useState([]);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(3);
  const [expandedRows, setExpandedRows] = useState([]);
  const [orderBy, setOrderBy] = useState('orderDate'); // Default sorting by Order Date
  const [order, setOrder] = useState('asc'); // Default order is ascending

  const patientId = sessionStorage.getItem("email");

  useEffect(() => {
    GetOrdersData();
  }, []);

  const GetOrdersData = async () => {
    try {
      const Response = await axios({
        method: 'GET',
        url: `http://localhost:9092/PatientOrders/${patientId}`,
        headers: { 'content-type': 'application/json' },
      });

      if (Response.data) {
        console.log(Response.data);
        setOrders(Response.data.orders);
      } else {
        alert("No Orders Found");
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleRowClick = (orderId) => {
    setSelectedOrderId(orderId);
    setSelectedMedicine('');
  };

  const handleDeliveryButton = () => {
    alert("Delivery Started");
    setSelectedOrderId(null);
  };

  const handleRowExpand = (orderId) => {
    if (expandedRows.includes(orderId)) {
      setExpandedRows(expandedRows.filter((id) => id !== orderId));
    } else {
      setExpandedRows([...expandedRows, orderId]);
    }
  };

  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    const formattedDate = new Date(dateString);
    formattedDate.setFullYear(formattedDate.getFullYear() - 2000);
    return formattedDate.toLocaleDateString(undefined, options);
  };

  const calculateTotalAmount = (medicines) => {
    return medicines.reduce((total, medicine) => {
      const medicineTotal = parseInt(medicine.quantity_ordered) * parseInt(medicine.unitPrice);
      return total + medicineTotal;
    }, 0);
  };

  const handleSort = (property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  // Sort the orders based on the selected column and order
  const sortedOrders = stableSort(orders, getComparator(order, orderBy));

  // Change the current page
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  // Change the number of rows per page
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0); // Reset page to 0 when changing rows per page
  };

  return (
    <div>
      <TableContainer component={Paper} style={{ marginLeft: '15rem', marginTop: '20px', marginBottom: '20px', width: '80%' }}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell />
              <TableCell>
                <TableSortLabel
                  active={orderBy === 'orderId'}
                  direction={orderBy === 'orderId' ? order : 'asc'}
                  onClick={() => handleSort('orderId')}
                >
                  Order Id
                </TableSortLabel>
              </TableCell>
              <TableCell>
                <TableSortLabel
                  active={orderBy === 'orderDate'}
                  direction={orderBy === 'orderDate' ? order : 'asc'}
                  onClick={() => handleSort('orderDate')}
                >
                  Date of Booking
                </TableSortLabel>
              </TableCell>
              <TableCell>Date of Delivery</TableCell>
              <TableCell>Amount</TableCell>
              <TableCell>Current Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {(rowsPerPage > 0
              ? sortedOrders.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              : sortedOrders
            ).map((order) => (
              <React.Fragment key={order.orderId}>
                <TableRow
                  onClick={() => handleRowClick(order.orderId)}
                  style={{ cursor: 'pointer' }}
                >
                  <TableCell>
                    <IconButton
                      size="small"
                      onClick={() => handleRowExpand(order.orderId)}
                    >
                      {expandedRows.includes(order.orderId) ? (
                        <KeyboardArrowUpIcon />
                      ) : (
                        <KeyboardArrowDownIcon />
                      )}
                    </IconButton>
                  </TableCell>
                  <TableCell component="th" scope="row">
                    {order.orderId}
                  </TableCell>
                  <TableCell>{formatDate(order.orderDate)}</TableCell>
                  <TableCell>{formatDate(order.deliveryDate)}</TableCell>
                  <TableCell>
                    {calculateTotalAmount(order.medicines)}
                  </TableCell>
                  <TableCell>{order.status}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell colSpan={6}>
                    <Collapse
                      in={expandedRows.includes(order.orderId)}
                      timeout="auto"
                      unmountOnExit
                    >
                      <Table>
                        <TableHead>
                          <TableRow>
                            <TableCell>Medicine Name</TableCell>
                            <TableCell>Quantity</TableCell>
                            <TableCell>Unit Price</TableCell>
                            <TableCell>Manufacturer Name</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {order.medicines.map((medicine, index) => (
                            <TableRow key={index}>
                              <TableCell>{medicine.medicineName}</TableCell>
                              <TableCell>{medicine.quantity_ordered}</TableCell>
                              <TableCell>{medicine.unitPrice}</TableCell>
                              <TableCell>{medicine.manufacturerName}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </Collapse>
                  </TableCell>
                </TableRow>
              </React.Fragment>
            ))}
          </TableBody>
        </Table>
        <TablePagination
          rowsPerPageOptions={[3, 5, 10]}
          component="div"
          count={sortedOrders.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </TableContainer>
    </div>
  );
};

export default PatientOrderTable;

// Helper function to sort the data
function stableSort(array, comparator) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  return stabilizedThis.map((el) => el[0]);
}

// Function to get the sorting order
function getComparator(order, orderBy) {
  return (a, b) => {
    if (a[orderBy] < b[orderBy]) {
      return order === 'asc' ? -1 : 1;
    }
    if (a[orderBy] > b[orderBy]) {
      return order === 'asc' ? 1 : -1;
    }
    return 0;
  };
}

