

import React, { useState, useEffect } from 'react';
import { CssBaseline, Drawer, List, ListItem, ListItemText, ListItemIcon, Divider, IconButton, AppBar, Toolbar, InputBase, Badge, Button } from '@material-ui/core';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import { Home as HomeIcon, Settings as SettingsIcon, Menu as MenuIcon, Search as SearchIcon, ShoppingCartRounded, LocalHospital, Receipt } from '@material-ui/icons';
import { Link, useNavigate } from 'react-router-dom';
import { useMediaQuery } from '@material-ui/core';


const drawerWidth = 240;

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    backgroundColor: '#4CAF50',
  },
  logo: {
    marginRight: theme.spacing(2),
    flexGrow: 1,
    color: 'white',
  },
  search: {
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: 'white',
    '&:hover': {
      backgroundColor: 'white',
    },
    marginLeft: theme.spacing(2),
    width: 'auto',
    [theme.breakpoints.up('sm')]: {
      marginLeft: theme.spacing(3),
      width: 'auto',
    },
  },
  searchIcon: {
    padding: theme.spacing(0, 2),
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: 'black',
  },
  inputRoot: {
    color: 'black',
  },
  inputInput: {
    padding: theme.spacing(1, 1, 1, 0),
    paddingLeft: `calc(1em + ${theme.spacing(4)}px)`,
    transition: theme.transitions.create('width'),
    width: '100%',
    [theme.breakpoints.up('sm')]: {
      width: '12ch',
      '&:focus': {
        width: '20ch',
      },
    },
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
  },
  drawerPaper: {
    width: drawerWidth,
  },
  drawerContainer: {
    overflow: 'auto',
  },
  menuButton: {
    marginRight: theme.spacing(2),
    [theme.breakpoints.up('md')]: {
      display: 'none',
    },
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
  },
  drawerContent: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  activeLink: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  iconGreen: {
    color: 'green',
  },
}));

const PatientHome = ({ cartItemsCount, cartItemsData, notificationActived }) => {
  const classes = useStyles();
  const theme = useTheme();
  const [mobileOpen, setMobileOpen] = useState(false);
  const isTabletOrLarger = useMediaQuery(theme.breakpoints.up('md'));
const navigate=useNavigate();
  // const [cartItemCount, setCartItemCount] = useState(0);
   const [notificationActive, setNotificationActive] = useState(true);
  //const [cartItemsData, setCartItemsData] = useState([]);

console.log(cartItemsData);
  const handleNotificationClick = () => {
    setNotificationActive(notificationActived);
   
  };

console.log("CartItems count from HomePage "+cartItemsCount);
console.log("CartItems count from HomePage "+cartItemsData);
  
  const handlelogout = () => {
  
    sessionStorage.removeItem("roleName");
    navigate("/")
  }
  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

 
  useEffect(() => {
    // Hide the notification badge when the user clicks on any other route
    const handleRouteChange = () => {
      setNotificationActive(false);
    };

    // Add the event listener for route change
    window.addEventListener('hashchange', handleRouteChange);

    // Clean up the event listener on component unmount
    return () => {
      window.removeEventListener('hashchange', handleRouteChange);
    };

  }, []);

  return (
    <div className={classes.root}>
      <CssBaseline />
      <AppBar position="fixed" className={classes.appBar}>
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            className={classes.menuButton}
          >
            <MenuIcon />
          </IconButton>
          <div className={classes.logo}>
            <h2>Health Sure</h2>
          </div>
          <div >
            <div>
              <Button style={{ backgroundColor: 'white', color: 'black' }} onClick={handlelogout} >Logout </Button>
            </div>
          </div>
          <IconButton color="inherit" component={Link} to="/cart" cartItemsData={cartItemsData}>
            <Badge badgeContent={cartItemsCount} color="secondary">
              <ShoppingCartRounded onClick={handleNotificationClick} />
            </Badge>
          </IconButton>
        </Toolbar>
      </AppBar>
      <nav>
        {isTabletOrLarger ? (
          <Drawer
            className={classes.drawer}
            variant="permanent"
            classes={{
              paper: classes.drawerPaper,
            }}
            open
          >
            <Toolbar />
            <div className={classes.drawerContainer}>
              <div className={classes.drawerContent}>
                <List>
                  <ListItem
                    button
                    component={Link}
                    to="/home"
                    className={classes.activeLink}
                  >
                    <ListItemIcon>
                      <HomeIcon className={classes.iconGreen} />
                    </ListItemIcon>
                    <ListItemText primary="Home" />
                  </ListItem>
                  <ListItem
                    button
                    component={Link}
                    to="/DeliveryStatus"
                    className={classes.activeLink}
                  >
                    <ListItemIcon>
                      <LocalHospital className={classes.iconGreen} />
                    </ListItemIcon>
                    <ListItemText primary="Delivery Status" />
                  </ListItem>
                  <ListItem
                    button
                    component={Link}
                    to="/accessbill"
                    className={classes.activeLink}
                  >
                    <ListItemIcon>
                      <Receipt className={classes.iconGreen} />
                    </ListItemIcon>
                    <ListItemText primary="Access Bills" />
                  </ListItem>
                </List>
                <Divider />
                {/* Add more routes as ListItems for the side nav-bar */}
              </div>
            </div>
          </Drawer>
        ) : (
          <Drawer
            className={classes.drawer}
            variant="temporary"
            classes={{
              paper: classes.drawerPaper,
            }}
            open={mobileOpen}
            onClose={handleDrawerToggle}
          >
            <Toolbar />
            <div className={classes.drawerContainer}>
              <div className={classes.drawerContent}>
                <List>
                  <ListItem
                    button
                    component={Link}
                    to="/"
                    className={classes.activeLink}
                  >
                    <ListItemIcon>
                      <HomeIcon className={classes.iconGreen} />
                    </ListItemIcon>
                    <ListItemText primary="Home" />
                  </ListItem>
                  <ListItem
                    button
                    component={Link}
                    to="/settings"
                    className={classes.activeLink}
                  >
                    <ListItemIcon>
                      <SettingsIcon className={classes.iconGreen} />
                    </ListItemIcon>
                    <ListItemText primary="Settings" />
                  </ListItem>
                </List>
                <Divider />
                {/* Add more routes as ListItems for the side nav-bar */}
              </div>
            </div>
          </Drawer>
        )}
      </nav>
      <main className={classes.content}>
        {/* Render the routes */}
      </main>
    </div>
  );
};

export default PatientHome;
