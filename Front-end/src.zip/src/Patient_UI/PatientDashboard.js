// import { Route, Routes } from "react-router-dom";
// import LoginPage from "../Registration/LoginPage";
// import PatientContent from "./PatientContent";
// import PatientOrderTable from "./DeliveryStatus";
// import AccessBill from "./AccessBill";
// import CheckoutPage from "./Cart";
// import PatientHome from "./PatientHome";
// import { useTheme } from "@emotion/react";
// import { makeStyles } from "@material-ui/core";
// import { useState } from "react";

// const useStyles = makeStyles((theme) => ({

// content: {
//   flexGrow: 1,
//   padding: theme.spacing(3),
//   backgroundColor:'#F5F5F5'
// },}));
// const PatientDashboard =() => {

//   const classes = useStyles();
//   const theme = useTheme();
//   const [cartItemsCount, setCartItemsCount] = useState(0);
//   const [notificationActive, setNotificationActive] = useState(true);
//   const [cartItemsData, setCartItemsData] = useState([]);

//   const updateCartItemsCount = (count) => {
//     setCartItemsCount(count);
//     setNotificationActive(true);
//     console.log("Count From Patient DashBoard " + count);
//   };

//   const handleNotificationClick = () => {
//     setNotificationActive(false);
//     setCartItemsCount(0);
//   };

//   const updatedCartItemsData = (data) => {
//     setCartItemsData(data);
//     setNotificationActive(true);
//   };  
//   const Patinentorders = [
//         {
//           orderId: 1,
//           dateOfBooking: '2023-08-01',
//           dateOfDelivery: '2023-08-10',
//           amount: 1000,
//           status: 'Pending',
//           medicines: [
//             { medicineName: 'Medicine A', quantity: 5, unitPrice: 50, isAvailable: 'yes' },
//             { medicineName: 'Medicine B', quantity: 3, unitPrice: 30, isAvailable: 'yes'},
//             { medicineName: 'Medicine C', quantity: 2, unitPrice: 20, isAvailable: 'yes' },
//           ],
//         },
//         {
//           orderId: 2,
//           dateOfBooking: '2023-08-05',
//           dateOfDelivery: '2023-08-15',
//           amount: 2000,
//           status: 'Completed',
//           medicines: [
//             { medicineName: 'Medicine X', quantity: 4, unitPrice: 70,isAvailable: 'yes' },
//             { medicineName: 'Medicine Y', quantity: 2, unitPrice: 40,isAvailable: 'yes' },
//           ],
//         },
//         // Add more orders here...
//       ];
//     return (
//       <div>
//             <PatientHome handleNotificationClick={handleNotificationClick}  ></PatientHome>
//             <main className={classes.content}>
//                     <Routes>
//                     <Route path="/logout" element={<LoginPage></LoginPage>}></Route>
//                     <Route path="/*" element={<PatientContent handleNotificationClick={handleNotificationClick} updateCartItemsCount={updateCartItemsCount} updatedCartItemsData={updatedCartItemsData}></PatientContent>}></Route>
//                     <Route path="/home" element={<PatientContent handleNotificationClick={handleNotificationClick} updateCartItemsCount={updateCartItemsCount} updatedCartItemsData={updatedCartItemsData}></PatientContent>}></Route>
//                     <Route path="/DeliveryStatus" element={<PatientOrderTable></PatientOrderTable>}></Route>
//                     <Route path="/accessbill" element={<AccessBill></AccessBill>}></Route>
//                     <Route path="/cart" element={<CheckoutPage   updatedCartItemsData={updatedCartItemsData}></CheckoutPage>}></Route>
//                     </Routes>
//             </main>
//       </div>
//     );
//   };

//   export default PatientDashboard;

import { Route, Routes } from "react-router-dom";
import LoginPage from "../Registration/LoginPage";
import PatientContent from "./PatientContent";
import PatientOrderTable from "./DeliveryStatus";
import AccessBill from "./AccessBill";
import CheckoutPage from "./Cart";
import PatientHome from "./PatientHome";
import { useTheme } from "@emotion/react";
import { makeStyles } from "@material-ui/core";
import { useEffect, useState } from "react";

const useStyles = makeStyles((theme) => ({

  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
    backgroundColor: '#F5F5F5'
  },
}));
const PatientDashboard = () => {

  const classes = useStyles();
  const theme = useTheme();
  const [cartItemsCount, setCartItemsCount] = useState(0);
  const [notificationActive, setNotificationActive] = useState(true);
   const [cartItemsData, setCartItemsData] = useState([]);

  useEffect(() => {
    setCartItemsCountProp(cartItemsCount);
  }, [cartItemsCount]);

  const setCartItemsCountProp = (count) => {
  };
  useEffect(() => {
    setCartItemsDataProp(cartItemsData);
  }, [cartItemsData]);

  const setCartItemsDataProp = (data) => {
  };
  return (
    <div>
      <PatientHome cartItemsCount={cartItemsCount}cartItemsData={cartItemsData}notificationActived={notificationActive}  ></PatientHome>
      <main className={classes.content}>
        <Routes>
          <Route path="/logout" element={<LoginPage></LoginPage>}></Route>
          <Route path="/*" element={<PatientContent setCartItemsCount={setCartItemsCount} setCartItemsData={setCartItemsData} setNotificationActive={setNotificationActive} ></PatientContent>}></Route>
          <Route path="/home" element={<PatientContent setCartItemsCount={setCartItemsCount} setCartItemsData={setCartItemsData} setNotificationActive={setNotificationActive}></PatientContent>}></Route>
          <Route path="/DeliveryStatus" element={<PatientOrderTable></PatientOrderTable>}></Route>
          <Route path="/accessbill" element={<AccessBill></AccessBill>}></Route>
          <Route path="/cart" element={<CheckoutPage cartItemsData={cartItemsData}></CheckoutPage>}></Route>
        </Routes>
      </main>
    </div>
  );
};

export default PatientDashboard;
