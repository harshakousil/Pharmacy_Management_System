
// import React, { useEffect, useState } from 'react';
// import {
//   Grid,
//   Card,
//   CardContent,
//   Typography,
//   Button,
//   Box,
//   TextField,
// } from '@material-ui/core';
// import { makeStyles } from '@material-ui/core/styles';
// import useMediaQuery from '@material-ui/core/useMediaQuery';
// import axios from 'axios';

// const useStyles = makeStyles((theme) => ({
//   mainContainer: {
//     marginTop: '100px',
//     marginLeft: '250px',
//     padding: '20px',
//     borderRadius: '5px',
//   },
//   card: {
//     display: 'flex',
//     flexDirection: 'row',
//     alignItems: 'center',
//     marginBottom: theme.spacing(2),
//     backgroundColor: 'white',
//     boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
//     borderRadius: '8px',
//   },
//   cardContent: {
//     display: 'flex',
//     flexDirection: 'column',
//     flex: 1,
//     padding: '10px',
//   },
//   cardImage: {
//     width: '150px',
//     height: 'auto',
//     padding: '5px',
//     objectFit: 'cover',
//     marginRight: theme.spacing(2),
//   },
//   quantityContainer: {
//     display: 'flex',
//     alignItems: 'center',
//     marginTop: theme.spacing(2),
//   },
//   quantityText: {
//     marginRight: theme.spacing(1),
//     fontWeight: 'bold',
//     fontSize: '15px',
//   },
//   addToCartButton: {
//     marginTop: '10px',
//     backgroundColor: '#5D9C59',
//     color: 'white',
//     '&:hover': {
//       backgroundColor: '#3C6255',
//     },
//   },
//   discountedCard: {
//     backgroundColor: '#A4BC92',
//   },
// }));

// const PatientContent = ({
//   setCartItemsCount,
//   setCartItemsData,
//   setNotificationActive,
// }) => {
//   const classes = useStyles();
//   const isTablet = useMediaQuery('(max-width: 1024px)');
//   const isMobile = useMediaQuery('(max-width: 600px)');
//   const [originalData, setOriginalData] = useState([]);
//   const [discountedData, setDiscountedData] = useState([]);
//   const [, forceUpdate] = useState();
//   const [selectedItems, setSelectedItems] = useState([]);
//   const [quantities, setQuantities] = useState([]);
//   const [cardsData, setCardsData] = useState([]);

//   window.addEventListener('unload', (event) => {
//     GetMedincedata();
//     GetDiscountedMedicineData();
//   });

//   useEffect(() => {
//     GetMedincedata();
//     GetDiscountedMedicineData();
//   }, []);

//   const GetMedincedata = async () => {
//     try {
//       const Response = await axios({
//         method: 'GET',
//         url: 'http://localhost:9091/GetAllMedicines',
//         headers: { 'content-type': 'application/json' },
//       });

//       if (Response) {
//         setOriginalData(Response.data);
//       } else {
//         alert('Data Mismatch, try again');
//       }
//     } catch (error) {
//       console.error('Error:', error);
//     }
//   };

//   const GetDiscountedMedicineData = async () => {
//     try {
//       const ResponseData = await axios({
//         method: 'GET',
//         url: 'http://localhost:9091/GetAllDiscountedMedicines',
//         headers: { 'content-type': 'application/json' },
//       });

//       if (ResponseData.data) {
//         setDiscountedData(ResponseData.data);
//       } else {
//         alert('Data Mismatch, try again');
//       }
//     } catch (error) {
//       console.error('Error:', error);
//     }
//   };

//   const mergeData = (originalData, discountedData) => {
//     const mergedData = [];

//     originalData.forEach((originalItem) => {
//       const matchingDiscountedScheme = discountedData.find(
//         (discountedScheme) =>
//           discountedScheme.medicines.some(
//             (discountedMedicine) =>
//               discountedMedicine.medicineId === originalItem.medicineId
//           )
//       );

//       if (matchingDiscountedScheme) {
//         const matchingDiscountedMedicine = matchingDiscountedScheme.medicines.find(
//           (discountedMedicine) =>
//             discountedMedicine.medicineId === originalItem.medicineId
//         );

//         mergedData.push({
//           ...originalItem,
//           unitPrice: matchingDiscountedMedicine.unitPrice,
//           originalPrice: originalItem.unitPrice,
//         });
//       } else {
//         mergedData.push({
//           ...originalItem,
//           originalPrice: originalItem.unitPrice,
//         });
//       }
//     });

//     return mergedData;
//   };
  
//   useEffect(() => {
//     if (originalData.length >= 0 && discountedData.length >= 0) {
//       const mergedData = mergeData(originalData, discountedData);
//       setCardsData(mergedData);

//       const cartItems = mergedData.map((item) => ({
//         medicineId: item.medicineId,
//         medicineName: item.medicineName,
//         manufacturerName: item.manufacturerName,
//         quantity_ordered: 1,
//         unitPrice: item.unitPrice,
//         isAvailble: 'true',
//       }));

//       setCartItemsData(cartItems);
//     }
//   }, [originalData, discountedData]);

//   const handleAddToCart = (index) => {
//     const selectedCard = cardsData[index];
//     const itemExists = selectedItems.findIndex(
//       (item) => item.medicineId === selectedCard.medicineId
//     );
//     const newQuantity = quantities[index] || 1;

//     if (itemExists !== -1) {
//       selectedItems[itemExists].quantity_ordered += newQuantity;
//       alert('Item already in cart, increasing the count');
//     } else {
//       const newItem = {
//         medicineId: selectedCard.medicineId,
//         medicineName: selectedCard.medicineName,
//         manufacturerName: selectedCard.manufacturerName,
//         quantity_ordered: newQuantity,
//         unitPrice: selectedCard.unitPrice,
//         isAvailble: 'true',
//       };
//       alert('Items added successfully');
//       selectedItems.push(newItem);
//     }

//     setCartItemsCount(selectedItems.length);
//     setCartItemsData(selectedItems);
//     setNotificationActive(true);

//     forceUpdate({});
//   };

//   const handleQuantityChange = (index, newValue) => {
//     const updatedQuantities = [...quantities];
//     updatedQuantities[index] = newValue;
//     setQuantities(updatedQuantities);
//   };

//   const getBlobFromBase64 = (base64String) => {
//     const binaryString = window.atob(base64String);
//     const bytes = new Uint8Array(binaryString.length);
//     for (let i = 0; i < binaryString.length; i++) {
//       bytes[i] = binaryString.charCodeAt(i);
//     }
//     return new Blob([bytes], { type: 'image/jpeg' });
//   };

//   const columns = isMobile ? 1 : isTablet ? 2 : 3;

//   return (
//     <div className={classes.mainContainer}>
//       <h3>Welcome to the user home page</h3>
//       <Grid container spacing={2}>
//         {cardsData.map((card, index) => (
//           <Grid
//             item
//             xs={12}
//             sm={6}
//             md={6}
//             lg={Math.floor(12 / columns)}
//             key={index}
//           >
//             <Card
//               className={`${classes.card}`}
//             >
//               <img
//                 src={URL.createObjectURL(getBlobFromBase64(card.image))}
//                 alt={card.title}
//                 className={classes.cardImage}
//               />
//               <CardContent className={classes.cardContent}>
//                 <Typography variant="h6" component="h2">
//                   {card.medicineName}
//                 </Typography>
//                 <Typography variant="p" component="h5">
//                   Manufacturer: {card.manufacturerName}
//                 </Typography>
//                 <Typography variant="p" component="h5">
//                   {card.unitPrice !== card.originalPrice && (
//                     <span style={{ textDecoration: 'line-through' }}>
//                       Original Price: {card.originalPrice}
//                     </span>
//                   )}
//                   <br />
//                   Current Price: {card.unitPrice}
//                 </Typography>
//                 <Box className={classes.quantityContainer}>
//                   <Typography className={classes.quantityText}>
//                     Quantity:
//                   </Typography>
//                   <TextField
//                     type="number"
//                     value={quantities[index] || 1}
//                     inputProps={{ min: 1, max: 999 }}
//                     onChange={(e) =>
//                       handleQuantityChange(index, Number(e.target.value))
//                     }
//                   />
//                 </Box>
//                 <Button
//                   variant="contained"
//                   className={classes.addToCartButton}
//                   onClick={() => handleAddToCart(index)}
//                 >
//                   Add to Cart
//                 </Button>
//               </CardContent>
//             </Card>
//           </Grid>
//         ))}
//       </Grid>
//     </div>
//   );
// };

// export default PatientContent;


import React, { useEffect, useState } from 'react';
import {
  Grid,
  Card,
  CardContent,
  Typography,
  Button,
  Box,
  TextField,
  Tooltip,
  IconButton,
  Select,
  MenuItem,
} from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import ClearIcon from '@material-ui/icons/Clear'; // Import the Clear icon
import FilterListIcon from '@material-ui/icons/FilterList'; // Import the Filter icon
import ArrowUpwardIcon from '@material-ui/icons/ArrowUpward'; // Import the Ascending sort icon
import ArrowDownwardIcon from '@material-ui/icons/ArrowDownward'; // Import the Descending sort icon
import axios from 'axios';
import AscendingIcon from '@material-ui/icons/ArrowUpward';
import DescendingIcon from '@material-ui/icons/ArrowDownward';

const useStyles = makeStyles((theme) => ({
  mainContainer: {
    marginTop: '50px',
    marginLeft: '250px',
    padding: '20px',
    borderRadius: '5px',
  },
  card: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing(2),
    backgroundColor: 'white',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
    borderRadius: '8px',
  },
  cardContent: {
    display: 'flex',
    flexDirection: 'column',
    flex: 1,
    padding: '10px',
  },
  cardImage: {
    width: '150px',
    height: 'auto',
    padding: '5px',
    objectFit: 'cover',
    marginRight: theme.spacing(2),
  },
  quantityContainer: {
    display: 'flex',
    alignItems: 'center',
    marginTop: theme.spacing(2),
  },
  quantityText: {
    marginRight: theme.spacing(1),
    fontWeight: 'bold',
    fontSize: '15px',
  },
  addToCartButton: {
    marginTop: '10px',
    backgroundColor: '#5D9C59',
    color: 'white',
    '&:hover': {
      backgroundColor: '#3C6255',
    },
  },
  discountedCard: {
    backgroundColor: '#A4BC92',
  },
}));

const PatientContent = ({
  setCartItemsCount,
  setCartItemsData,
  setNotificationActive,
}) => {
  const classes = useStyles();
  const isTablet = useMediaQuery('(max-width: 1024px)');
  const isMobile = useMediaQuery('(max-width: 600px)');
  const [originalData, setOriginalData] = useState([]);
  const [discountedData, setDiscountedData] = useState([]);
  const [, forceUpdate] = useState();
  const [selectedItems, setSelectedItems] = useState([]);
  const [quantities, setQuantities] = useState([]);
  const [cardsData, setCardsData] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState(''); // 'asc' for Price Low to High, 'desc' for Price High to Low
  const [showDiscounted, setShowDiscounted] = useState(false);
  const [filteredData, setFilteredData] = useState(cardsData); // Initialize with all data


  window.addEventListener('unload', (event) => {
    GetMedincedata();
    GetDiscountedMedicineData();
  });

  useEffect(() => {
    GetMedincedata();
    GetDiscountedMedicineData();
  }, []);

  const GetMedincedata = async () => {
    try {
      const Response = await axios({
        method: 'GET',
        url: 'http://localhost:9091/GetAllMedicines',
        headers: { 'content-type': 'application/json' },
      });

      if (Response) {
        setOriginalData(Response.data);
      } else {
        alert('Data Mismatch, try again');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const GetDiscountedMedicineData = async () => {
    try {
      const ResponseData = await axios({
        method: 'GET',
        url: 'http://localhost:9091/GetAllDiscountedMedicines',
        headers: { 'content-type': 'application/json' },
      });

      if (ResponseData.data) {
        setDiscountedData(ResponseData.data);
      } else {
        alert('Data Mismatch, try again');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const mergeData = (originalData, discountedData) => {
    const mergedData = [];

    originalData.forEach((originalItem) => {
      const matchingDiscountedScheme = discountedData.find(
        (discountedScheme) =>
          discountedScheme.medicines.some(
            (discountedMedicine) =>
              discountedMedicine.medicineId === originalItem.medicineId
          )
      );

      if (matchingDiscountedScheme) {
        const matchingDiscountedMedicine = matchingDiscountedScheme.medicines.find(
          (discountedMedicine) =>
            discountedMedicine.medicineId === originalItem.medicineId
        );

        mergedData.push({
          ...originalItem,
          unitPrice: matchingDiscountedMedicine.unitPrice,
          originalPrice: originalItem.unitPrice,
        });
      } else {
        mergedData.push({
          ...originalItem,
          originalPrice: originalItem.unitPrice,
        });
      }
    });

    return mergedData;
  };
  
  useEffect(() => {
    if (originalData.length >= 0 && discountedData.length >= 0) {
      const mergedData = mergeData(originalData, discountedData);
      setCardsData(mergedData);

      const cartItems = mergedData.map((item) => ({
        medicineId: item.medicineId,
        medicineName: item.medicineName,
        manufacturerName: item.manufacturerName,
        quantity_ordered: 1,
        unitPrice: item.unitPrice,
        isAvailble: 'true',
      }));

      setCartItemsData(cartItems);
    }
  }, [originalData, discountedData]);

  const handleAddToCart = (index) => {
    const selectedCard = cardsData[index];
    const itemExists = selectedItems.findIndex(
      (item) => item.medicineId === selectedCard.medicineId
    );
    const newQuantity = quantities[index] || 1;
  
    // Check if the entered quantity is less than the stock quantity
    if (newQuantity <= selectedCard.stockQuantity) {
      if (itemExists !== -1) {
        selectedItems[itemExists].quantity_ordered += newQuantity;
        alert('Item already in cart, increasing the count');
      } else {
        const newItem = {
          medicineId: selectedCard.medicineId,
          medicineName: selectedCard.medicineName,
          manufacturerName: selectedCard.manufacturerName,
          quantity_ordered: newQuantity,
          unitPrice: selectedCard.unitPrice,
          isAvailble: 'true',
        };
        alert('Items added successfully');
        selectedItems.push(newItem);
      }
  
      setCartItemsCount(selectedItems.length);
      setCartItemsData(selectedItems);
      setNotificationActive(true);
  
      forceUpdate({});
    } else {
      alert('Entered quantity exceeds available stock quantity.');
      alert(`Max quantity you can order fo the medicine is ${selectedCard.stockQuantity-10}`);
    }
  };

  const handleQuantityChange = (index, newValue) => {
    const updatedQuantities = [...quantities];
    updatedQuantities[index] = newValue;
    setQuantities(updatedQuantities);
  };

  const getBlobFromBase64 = (base64String) => {
    const binaryString = window.atob(base64String);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return new Blob([bytes], { type: 'image/jpeg' });
  };

  const columns = isMobile ? 1 : isTablet ? 2 : 3;

  // Add a new useEffect to filter and sort the data based on user selections
  useEffect(() => {
    let filteredData = cardsData;

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filteredData = filteredData.filter(
        (card) =>
          card.medicineName.toLowerCase().includes(query) ||
          card.manufacturerName.toLowerCase().includes(query)
      );
    }

    // Sort by price
    if (sortOrder === 'asc') {
      filteredData.sort((a, b) => a.unitPrice - b.unitPrice);
    } else if (sortOrder === 'desc') {
      filteredData.sort((a, b) => b.unitPrice - a.unitPrice);
    }

    // Filter by discounted
    if (showDiscounted) {
      filteredData = filteredData.filter((card) => card.unitPrice !== card.originalPrice);
    }

    setFilteredData(filteredData);
  }, [searchQuery, sortOrder, showDiscounted, cardsData]);

  const handleClearFilters = () => {
    setSearchQuery('');
    setSortOrder('asc');
    setShowDiscounted(false);
    setFilteredData(cardsData); // Reset to all data
  };

  // ... your existing event handlers ...

  return (
    <div className={classes.mainContainer}>
      <h3>Welcome to the user home page</h3>

 
      <Grid container spacing={2} alignItems="center" style={{borderRadius: '10px', }}>
        <Grid item xs={12} sm={6} md={6} >
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <TextField
              label="Search Medicines"
              variant="outlined"
              fullWidth
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </Grid>
        <Grid item xs={12} sm={6} md={6}>
          <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-evenly' }}>
            <div style={{ display: 'flex', alignItems: 'center' }}>
            <MenuItem value="" disabled>
                    Sort By
            </MenuItem> {/* Add the Ascending Sort Icon */}
              <Select
                className={classes.filterSelect}
                value={sortOrder}
                onChange={(e) => setSortOrder(e.target.value)}
                displayEmpty
              >
                <MenuItem value="asc">Price Low to High</MenuItem>
                <MenuItem value="desc">Price High to Low</MenuItem>
              </Select>
            </div>
            <div style={{ display: 'flex', flexDirection: 'row', marginTop: '8px' }}>
            <MenuItem value="" disabled>
                  Filter By
            </MenuItem> {/* Add the Filter Icon */}
              <Select
                className={classes.filterSelect}
                value={showDiscounted ? 'discounted' : 'all'}
                onChange={(e) => setShowDiscounted(e.target.value === 'discounted')}
                displayEmpty
              >
                <MenuItem value="all">Show All</MenuItem>
                <MenuItem value="discounted">Show Discounted</MenuItem>
              </Select>
            </div>
            <Button title="Clear Filters" variant='outlined' color="success" onClick={handleClearFilters}>Clear
            </Button>
          </div>
        </Grid>
      </Grid>

      <Grid container spacing={2}  style={{marginTop:"30px", borderRadius: '10px'}}>
        {filteredData.map((card, index) => (
          <Grid
            item
            xs={12}
            sm={6}
            md={6}
            lg={Math.floor(12 / columns)}
            key={index}
          >
             <Card
              className={`${classes.card}`}
            >
              <img
                src={URL.createObjectURL(getBlobFromBase64(card.image))}
                alt={card.title}
                className={classes.cardImage}
              />
              <CardContent className={classes.cardContent}>
                <Typography variant="h6" component="h2">
                  {card.medicineName}
                </Typography>
                <Typography variant="p" component="h5">
                  Manufacturer: {card.manufacturerName}
                </Typography>
                <Typography variant="p" component="h5">
                  {card.unitPrice !== card.originalPrice && (
                    <span style={{ textDecoration: 'line-through' }}>
                      Original Price: {card.originalPrice}
                    </span>
                  )}
                  <br />
                  Current Price: {card.unitPrice}
                </Typography>
                <Box className={classes.quantityContainer}>
                  <Typography className={classes.quantityText}>
                    Quantity:
                  </Typography>
                  <TextField
                    type="number"
                    value={quantities[index] || 1}
                    inputProps={{ min: 1, max: 999 }}
                    onChange={(e) =>
                      handleQuantityChange(index, Number(e.target.value))
                    }
                  />
                </Box>
                <Button
                  variant="contained"
                  className={classes.addToCartButton}
                  onClick={() => handleAddToCart(index)}
                >
                  Add to Cart
                </Button>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </div>
  );
};

export default PatientContent;
