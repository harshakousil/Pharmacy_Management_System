// import React, { useEffect, useState } from 'react';
// import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Checkbox, Button } from '@mui/material';
// import axios from 'axios';

// const AccessBill = () => {
//   const [selectedOrderId, setSelectedOrderId] = useState(null);

//   const[orders, setorders]=useState([]);
//   var patientId=sessionStorage.getItem("email");

//   const handleRowClick = (orderId) => {
//     setSelectedOrderId(orderId);
//   };
//   window.addEventListener("unload", (event) => {
//     GetOrdersData();
//     console.log("API call after page reload");
//   });
//   useEffect(() => {
//     GetOrdersData();
//   }, []);
//   const GetOrdersData = async () => {
//     try {
//       const Response = await axios({
//         method: 'GET',
//         url: `http://localhost:9092/PatientOrders/${patientId}`, // Update with your actual endpoint
//         headers: { 'content-type': 'application/json' },
//       });

//       if (Response.data) {
//         console.log(Response.data);
//         setorders(Response.data.orders);
//       }
//       else {
//         alert("No Orders Found")
//       }
//     } catch (error) {
//       console.error('Error:', error);
//     }
//   }


//   const handleDownloadBill = () => {
//     // Code to handle the download functionality (e.g., generate PDF and provide print option)
//     // You can use external libraries like react-pdf or pdfmake to generate PDF
//     // For demonstration purposes, we will just log a message here.
//     alert("Bill downloaded")
//     setSelectedOrderId(null);
//     console.log('Downloading bill for Order ID:', selectedOrderId);
//   };
//   const formatDate = (dateString) => {
//     const options = { year: 'numeric', month: 'long', day: 'numeric' };
//     const formattedDate = new Date(dateString);
//     formattedDate.setFullYear(formattedDate.getFullYear() - 2000);
//     return new Intl.DateTimeFormat(undefined, options).format(formattedDate);
//   };
//   const calculateTotalAmount = (medicines) => {
//     return medicines.reduce((total, medicine) => {
//       const medicineTotal = parseInt(medicine.quantity_ordered) * parseInt(medicine.unitPrice);
//       return total + medicineTotal;
//     }, 0);
//   };

//   return (
//     <div>
//     <TableContainer component={Paper} style={{ marginLeft: '15rem', marginTop: '20px', marginBottom: '20px', width: '80%' }}>
//       <Table>
//         <TableHead>
//           <TableRow>
//             <TableCell>Order Id</TableCell>
//             <TableCell>Date of Booking</TableCell>
//             <TableCell>Date of Delivery</TableCell>
//             <TableCell>Amount</TableCell>
//             <TableCell>Status</TableCell>
//           </TableRow>
//         </TableHead>
//         <TableBody>
//           {orders.filter(order => order.status === "Delivered").map((order) => (
//             <TableRow
//               key={order.orderId}
//               onClick={() => handleRowClick(order.orderId)}
//               style={{ cursor: 'pointer' }}
//             >
//               <TableCell component="th" scope="row">
//                 {order.orderId}
//               </TableCell>
//               <TableCell>{formatDate(order.orderDate)}</TableCell>
//               <TableCell>{formatDate(order.deliveryDate)}</TableCell>
//               <TableCell>
//               {calculateTotalAmount(order.medicines)} {/* Calculate and display total amount */}
//                 </TableCell>
//               <TableCell>{order.status}</TableCell>
//             </TableRow>
//           ))}
//         </TableBody>
//       </Table>
//     </TableContainer>

//     {selectedOrderId !== null && (
//       <div>
//         <TableContainer component={Paper} style={{ marginLeft: '15rem', marginBottom: '20px', width: '80%' }}>
//           <Table>
//             <TableHead>
//               <TableRow>
//                 <TableCell>Medicine Name</TableCell>
//                 <TableCell>Quantity</TableCell>
//                 <TableCell>Unit Price</TableCell>
//                 <TableCell>ManufacturerName</TableCell>
//                 <TableCell>Receipt</TableCell>
//               </TableRow>
//             </TableHead>
//             <TableBody>
//               {orders.find((o) => o.orderId === selectedOrderId).medicines.map((medicine, index) => (
//                 <TableRow key={index}>
//                   <TableCell>{medicine.medicineName}</TableCell>
//                   <TableCell>{medicine.quantity_ordered}</TableCell>
//                   <TableCell>{medicine.unitPrice}</TableCell>
//                   <TableCell>{medicine.manufacturerName}</TableCell>
//                 </TableRow>
//               ))}
//             </TableBody>
//           </Table>
        
//         </TableContainer>
       
//       </div>
//     )}
//   </div>
    
//   );
// };

// export default AccessBill;

// // {/*  */}

import React, { useEffect, useState } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Collapse,
  TablePagination,
  TableSortLabel,
} from '@mui/material';
import axios from 'axios';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import { Button } from '@material-ui/core';
import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';

// Import the fonts

const AccessBill = () => {
  const [selectedOrderId, setSelectedOrderId] = useState(null);
  const [orders, setOrders] = useState([]);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(3);
  const [expandedRows, setExpandedRows] = useState([]);
  const [orderBy, setOrderBy] = useState('orderDate');
  const [order, setOrder] = useState('asc');

  const patientId = sessionStorage.getItem("email");

  useEffect(() => {
    GetOrdersData();
  }, []);

  const GetOrdersData = async () => {
    try {
      const Response = await axios({
        method: 'GET',
        url: `http://localhost:9092/PatientOrders/${patientId}`,
        headers: { 'content-type': 'application/json' },
      });

      if (Response.data) {
        console.log(Response.data);
        setOrders(Response.data.orders);
      } else {
        alert("No Orders Found");
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleRowClick = (orderId) => {
    setSelectedOrderId(orderId);
  };

  const handleDownloadBill = () => {
    // Code to handle the download functionality (e.g., generate PDF and provide print option)
    // You can use external libraries like react-pdf or pdfmake to generate PDF
    // For demonstration purposes, we will just log a message here.
    alert("Bill downloaded");
    setSelectedOrderId(null);
    console.log('Downloading bill for Order ID:', selectedOrderId);
  };

  const handleRowExpand = (orderId) => {
    if (expandedRows.includes(orderId)) {
      setExpandedRows(expandedRows.filter((id) => id !== orderId));
    } else {
      setExpandedRows([...expandedRows, orderId]);
    }
  };

  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    const formattedDate = new Date(dateString);
    formattedDate.setFullYear(formattedDate.getFullYear() - 2000);
    return new Intl.DateTimeFormat(undefined, options).format(formattedDate);
  };
    const calculateTotalAmount = (medicines) => {
    return medicines.reduce((total, medicine) => {
      const medicineTotal = parseInt(medicine.quantity_ordered) * parseInt(medicine.unitPrice);
      return total + medicineTotal;
    }, 0);
  };
  pdfMake.vfs = pdfFonts.pdfMake.vfs;

  const generatePDF = () => {
    if (!selectedOrderId) return;

    const selectedOrder = orders.find((order) => order.orderId === selectedOrderId);

    if (!selectedOrder) return;

    const pdfContent = {
      content: [
        {
          text: 'Healthsure Pharma', // Header
          style: 'header',
          alignment: 'center',
        },
        { text: '\n' }, // Add some spacing
        { text: 'Order Details', style: 'subheader' },
        `Order ID: ${selectedOrder.orderId}`,
        `Delivery Date: ${formatDate(selectedOrder.deliveryDate)}`,
        `Status: ${selectedOrder.status}`,
        {
          text: 'Medicines:',
          style: 'subheader',
        },
        selectedOrder.medicines.map((medicine) => ({
          ul: [
            `Name: ${medicine.medicineName}`,
            `Manufacturer: ${medicine.manufacturerName}`,
            `Quantity Ordered: ${medicine.quantity_ordered}`,
            `Unit Price: ${medicine.unitPrice}`,
          ],
        })),
        { text: '\n' }, // Add some spacing
        { text: 'Shop Again', alignment: 'center' },
        { text: '\n' }, // Add some spacing
        { text: 'Copyright@2023 Healthsure Pharma', alignment: 'center' }, // Footer
      ],
      styles: {
        header: {
          fontSize: 18,
          bold: true,
        },
        subheader: {
          fontSize: 14,
          bold: true,
          margin: [0, 10, 0, 5], // top, right, bottom, left margins
        },
      },
    };

    const pdfDoc = pdfMake.createPdf(pdfContent);
    pdfDoc.download(`Invoice_Order_${selectedOrderId}.pdf`);
  };
  return (
    <div>
      <TableContainer component={Paper} style={{ marginLeft: '15rem', marginTop: '20px', marginBottom: '20px', width: '80%' }}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell />
              <TableCell>
                <TableSortLabel
                  active={orderBy === 'orderId'}
                  direction={orderBy === 'orderId' ? order : 'asc'}
                  onClick={() => setOrderBy('orderId')}
                >
                  Order Id
                </TableSortLabel>
              </TableCell>
              <TableCell>
                <TableSortLabel
                  active={orderBy === 'orderDate'}
                  direction={orderBy === 'orderDate' ? order : 'asc'}
                  onClick={() => setOrderBy('orderDate')}
                >
                  Date of Booking
                </TableSortLabel>
              </TableCell>
              <TableCell>Date of Delivery</TableCell>
              <TableCell>Amount</TableCell>
              <TableCell>Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {(rowsPerPage > 0
              ? orders.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              : orders
            ).map((order) => (
              <React.Fragment key={order.orderId}>
                <TableRow
                  onClick={() => handleRowClick(order.orderId)}
                  style={{ cursor: 'pointer' }}
                >
                  <TableCell>
                    <IconButton
                      size="small"
                      onClick={() => handleRowExpand(order.orderId)}
                    >
                      {expandedRows.includes(order.orderId) ? (
                        <KeyboardArrowUpIcon />
                      ) : (
                        <KeyboardArrowDownIcon />
                      )}
                    </IconButton>
                  </TableCell>
                  <TableCell component="th" scope="row">
                    {order.orderId}
                  </TableCell>
                  <TableCell>{formatDate(order.orderDate)}</TableCell>
                  <TableCell>{formatDate(order.deliveryDate)}</TableCell>
                  <TableCell>
                    {calculateTotalAmount(order.medicines)}
                  </TableCell>
                  <TableCell>{order.status}</TableCell>
                </TableRow>
                {selectedOrderId === order.orderId && (
                      <TableRow>
                        <TableCell colSpan={6}>
                          {/* Render details for selected order */}
                          {/* You can display the order details here */}
                          <p><strong>Order ID:</strong> {order.orderId}</p>
                          <p><strong>Delivery Date:</strong> {formatDate(order.deliveryDate)}</p>
                          <p><strong>Status:</strong> {order.status}</p>
                          <h3>Medicines:</h3>
                          <ul>
                            {order.medicines.map((medicine) => (
                              <li key={medicine.medicineId}>
                                <strong>Name:</strong> {medicine.medicineName}<br />
                                <strong>Manufacturer:</strong> {medicine.manufacturerName}<br />
                                <strong>Quantity Ordered:</strong> {medicine.quantityOrdered}<br />
                                <strong>Unit Price:</strong> {medicine.unitPrice}<br />
                              </li>
                            ))}
                          </ul>
                          <TableCell><Button variant="contained" color='primary' onClick={generatePDF}>Download Invoice</Button></TableCell>
                        </TableCell>
                       
                      </TableRow>
                    )}
              </React.Fragment>
            ))}
          </TableBody>
        </Table>
        <TablePagination
          rowsPerPageOptions={[3, 5, 10]}
          component="div"
          count={orders.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={(event, newPage) => setPage(newPage)}
          onRowsPerPageChange={(event) => {
            setRowsPerPage(parseInt(event.target.value, 10));
            setPage(0);
          }}
        />
      </TableContainer>
      {/* {selectedOrderId !== null && (
        <div>
          <TableContainer component={Paper} style={{ marginLeft: '15rem', marginBottom: '20px', width: '80%' }}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Medicine Name</TableCell>
                  <TableCell>Quantity</TableCell>
                  <TableCell>Unit Price</TableCell>
                  <TableCell>Manufacturer Name</TableCell>
                  <TableCell>Action</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {orders.find((o) => o.orderId === selectedOrderId).medicines.map((medicine, index) => (
                  <TableRow key={index}>
                    <TableCell>{medicine.medicineName}</TableCell>
                    <TableCell>{medicine.quantity_ordered}</TableCell>
                    <TableCell>{medicine.unitPrice}</TableCell>
                    <TableCell>{medicine.manufacturerName}</TableCell>
                    <TableCell>
                      <Button variant="contained" color="primary" onClick={handleDownloadBill}>
                        Download Bill
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </div>
      )} */}
    </div>
  );
};

export default AccessBill;
