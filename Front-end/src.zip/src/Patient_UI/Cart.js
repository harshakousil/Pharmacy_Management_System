import React, { useState } from 'react';
import { Card, CardContent, Typography, Grid, Button, IconButton, Box, TextField } from '@mui/material';
import { Delete as DeleteIcon } from '@mui/icons-material';
import { useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';


const CheckoutPage = ({cartItemsData }) => {
  console.log(cartItemsData);
  const location = useLocation();
  const initialCartItemsData = location.state;
  const [updatedCartItemsData, setUpdatedCartItemsData] = useState(cartItemsData);
  const navigate= useNavigate();

  const handleQuantityChange = (index, value) => {
    const newCartItemsData = [...updatedCartItemsData];
    newCartItemsData[index].quantity_ordered = parseInt(value, 10);
    setUpdatedCartItemsData(newCartItemsData);
  };

  const totalAmount = updatedCartItemsData.reduce((acc, item) => acc + item.unitPrice * item.quantity_ordered, 0);
  var email= sessionStorage.getItem('email')
 
  console.log(email);
  const handleCheckout = async() => {
    if(updatedCartItemsData.length<1)
    {
      alert("Nothing in Cart, Explore Home")
      navigate("/home");
    }
    else{
    const today = new Date();
    const tomorrow = new Date();
    tomorrow.setDate(today.getDate() + 1);
   

    const Orderdata = {
      "email":"",
      "name": "",
      "password": "",
      "orders": [
        {
          "_id": "",
          "orderDate":"",
          "deliveryDate":"",
          "status": "",
          "medicines": []
        }
      ]
    };
  
    Orderdata.email=email
    Orderdata.orders[0].status="Confirmed"
    Orderdata.orders[0].orderDate= today;
    Orderdata.orders[0].deliveryDate=tomorrow;
    Orderdata.orders[0].medicines.push(...updatedCartItemsData);
      try {
        const Response = await axios({
          method: 'POST',
          url: 'http://localhost:9092/addOrder',
          headers: { 'content-type': 'application/json' },
          data:Orderdata
        });
  
        console.log(Response.data);
        if (Response.data==="success") {
          alert('Order placed successfully');
          //navigate("/home");
          window.location.reload(true);
        }
        else {
          alert("data Mismatch try Again")
        }
      } catch (error) {
        console.error('Error:', error);
      }
   

    }
  };

  const handleDeleteItem = (index) => {
    const updatedItems = updatedCartItemsData.filter((item, i) => i !== index);
    setUpdatedCartItemsData(updatedItems);
  };

  return (
    <div style={{ marginTop: '50px', marginLeft:'250px', padding: '100px', boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.1)' }}>
      <Typography variant="h6" component="h6" style={{ marginBottom: '20px', textAlign: 'center', color: '#333' }}>
      We Deliver On Time
      </Typography>
      {/* Outer div with box shadow */}
      <Grid container spacing={2}>
        <Grid item xs={12} sm={6}>
          {updatedCartItemsData.map((item, index) => (
            <Card key={index} style={{ marginBottom: '10px', position: 'relative' }}>
              <CardContent>
                <Typography variant="h5" component="div">
                  Medicine : {item.medicineName}
              </Typography>
                <Typography color="text.secondary">
                  manufacturer : {item.manufacturerName}
                </Typography>
                <Typography color="text.secondary">Cost :{item.unitPrice}</Typography>
                <Typography color="text.secondary">Quantity:</Typography>
                <TextField
                  type="number"
                  value={item.quantity_ordered}
                  onChange={(e) => handleQuantityChange(index, e.target.value)}
                  inputProps={{
                    min: 1,
                  }}
                />
              </CardContent>
              <Box sx={{ position: 'absolute', top: '5px', right: '5px' }}>
                <IconButton onClick={() => handleDeleteItem(index)} size="small" color="error">
                  <DeleteIcon />
                </IconButton>
              </Box>
            </Card>
          ))}
        </Grid>
        <Grid item xs={12} sm={6}>
          <div style={{ textAlign: 'center', marginTop: '50px' }}>
            <Typography variant="h5" component="div">
              Total amount: {totalAmount.toFixed(2)}
            </Typography>
            <Button sx={{ marginTop: '20px' }} variant="contained" color="primary" onClick={handleCheckout}>
              Checkout
            </Button>
          </div>
        </Grid>
      </Grid>
    </div>
  );
};

export default CheckoutPage;
