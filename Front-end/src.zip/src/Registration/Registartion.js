import React, { useState } from 'react';
import { TextField, Button, Typography } from '@material-ui/core';
import { AccountCircle, Email, Lock } from '@material-ui/icons';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const initialFormData = {
  name: '',
  email: '',
  password: '',
  orders: [],
};

const RegistrationPage = () => {
  const navigate=useNavigate();
  const [formData, setFormData] = useState(initialFormData);
  const [errors, setErrors] = useState({});

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };


  const initialPatientData = {
    name: '',
    email: '',
    password: '',
    orders: [],
  };
  const [patientData, setPatientData] = useState(initialPatientData);

  const handleSubmit = async(event) => {
    event.preventDefault();
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length === 0) {
      // Form is valid, you can handle form submission here
      console.log('Form submitted:', formData);

      setFormData(initialFormData);
      setPatientData(formData);
      try {
        var Response = await axios({

          method: "POST",
          url: "http://localhost:9092/addPatient",
          headers: { "content-type": "application/json" },
          data: formData
        })

      }
      catch (e) {
        console.log(e)
      }
      if (Response) {
        if(Response.data){
          alert("Registration Sucessfull")
         navigate("/")}
         else{
          alert("User already exists, try with another mail");
         }
      }
      else {
        alert("Server Issue");
      }
      
    } else {
      // Form has errors, display them
      setErrors(validationErrors);
    }
  };

  const validateForm = () => {
    const validationErrors = {};

    if (!formData.name) {
      validationErrors.name = 'Name is required';
    }

    if (!formData.email) {
      validationErrors.email = 'Email is required';
    } else if (!isValidEmail(formData.email)) {
      validationErrors.email = 'Invalid email format';
    }

    if (!formData.password) {
      validationErrors.password = 'Password is required';
    } else if (formData.password.length < 6) {
      validationErrors.password = 'Password must be at least 6 characters long';
    }

    if (formData.confirmPassword !== formData.password) {
      validationErrors.confirmPassword = 'Passwords do not match';
    }

    return validationErrors;
  };

  const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  return (
    <div style={{ display: 'flex', height: '100vh' ,border: '1px solid #ccc' }}>
      <div style={{ flex: 1, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <img src="/pharmacy.png" alt="Pharmacy Management" style={{ maxWidth: '100%', maxHeight: '100%' }} />
      </div>
      <div style={{ flex: 1, display: 'flex',flexDirection: 'column',  justifyContent: 'center', alignItems: 'center' }}>
      <Typography variant="h4"sx={{ fontFamily: 'Montserrat, sans-serif',
    fontSize: '2rem',
    fontWeight: 400,
    color:'#dcdcdc',
    textTransform: 'uppercase',
    textAlign: 'start',
    marginBottom:"3px",
    textShadow: '2px 2px 4px rgba(0, 0, 0, 0.3)'}}>
        Welcome To <br/>
    Pharma Health
    </Typography>
        <form onSubmit={handleSubmit} style={{ maxWidth: 400, width: '100%', padding: '20px', }}>
          <h2>Register Here to Continue</h2>
          <TextField
            fullWidth
            label="Name"
            name="name"
            value={formData.name}
            onChange={handleInputChange}
            error={!!errors.name}
            helperText={errors.name}
            margin="normal"
            variant="outlined"
            InputProps={{
              startAdornment: <AccountCircle />,
            }}
          />
          <TextField
            fullWidth
            label="Email"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            error={!!errors.email}
            helperText={errors.email}
            margin="normal"
            variant="outlined"
            InputProps={{
              startAdornment: <Email />,
            }}
          />
          <TextField
            fullWidth
            label="Password"
            name="password"
            type="password"
            value={formData.password}
            onChange={handleInputChange}
            error={!!errors.password}
            helperText={errors.password}
            margin="normal"
            variant="outlined"
            InputProps={{
              startAdornment: <Lock />,
            }}
          />
          <TextField
            fullWidth
            label="Confirm Password"
            name="confirmPassword"
            type="password"
            value={formData.confirmPassword}
            onChange={handleInputChange}
            error={!!errors.confirmPassword}
            helperText={errors.confirmPassword}
            margin="normal"
            variant="outlined"
            InputProps={{
              startAdornment: <Lock />,
            }}
          />
          <Button type="submit" variant="contained" color="primary" fullWidth>
            Register
          </Button>
        </form>
      </div>
    </div>
  );
};

export default RegistrationPage;
