import React, { useState } from 'react';
import { TextField, Button, Typography } from '@material-ui/core';
import { Email, Lock } from '@material-ui/icons';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';



const initialFormData = {
  email: '',
  password: '',
};

const LoginPage = () => {

  const navigate = useNavigate();
  const [formData, setFormData] = useState(initialFormData);
  const [errors, setErrors] = useState({});

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length === 0) {
      // Form is valid, you can handle form submission here
      console.log('Form submitted:', formData);



      try {
        var Response = await axios({

          method: "POST",
          url: "http://localhost:9090/login",
          headers: { "content-type": "application/json" },
          data: formData
        })

      }
      catch (e) {
        console.log(e)
      }
      if (Response) {
        if(Response.data.rolename){
        const roleName = Response.data.rolename;
        console.log(roleName);
        sessionStorage.setItem('email',Response.data.email)
        sessionStorage.setItem('roleName', roleName)
        navigate("/*")
        }
        else{
          alert("User Not Found");
        }
      }
      else {
        alert("Server Issue");
      }

      setFormData(initialFormData);
      //window.location.reload(true)
    } else {
      // Form has errors, display them
      setErrors(validationErrors);
    }
  };

  const validateForm = () => {
    const validationErrors = {};

    if (!formData.email) {
      validationErrors.email = 'Email is required';
    } else if (!isValidEmail(formData.email)) {
      validationErrors.email = 'Invalid email format';
    }

    if (!formData.password) {
      validationErrors.password = 'Password is required';
    } else if (formData.password.length < 6) {
      validationErrors.password = 'Password must be at least 6 characters long';
    }


    return validationErrors;
  };

  const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  return (

    <div style={{ display: 'flex', height: '100vh', border: '1px solid #ccc', fontFamily: 'Montserrat, sans-serif' }}>

      <div style={{ flex: 2, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <img src="/pharmacy.png" alt="Pharmacy Management" style={{ maxWidth: '100%', maxHeight: '100%', }} />
      </div>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', border: '1px solid #fff' }}>
        <Typography variant="h4" sx={{
          fontFamily: 'Montserrat, sans-serif',
          fontSize: '2rem',
          fontWeight: 700,
          color: '#dcdcdc',
          textTransform: 'uppercase',
          textAlign: 'start',
          marginBottom: "3px",
          textShadow: '2px 2px 4px rgba(0, 0, 0, 0.3)'
        }}>
          Pharma Health
        </Typography>
        <form onSubmit={handleSubmit} style={{ maxWidth: 400, width: '100%', padding: '20px', fontFamily: 'Montserrat, sans-serif' }}>
          <h2 style={{ fontFamily: 'Montserrat, sans-serif' }}>Login Here to Continue</h2>
          <TextField
            fullWidth
            label="Email"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            error={!!errors.email}
            helperText={errors.email}
            margin="normal"
            variant="outlined"
            InputProps={{
              startAdornment: <Email />,
            }}
            style={{ marginBottom: '20px' }} // Add margin to create spacing
          />
          <TextField
            fullWidth
            label="Password"
            name="password"
            type="password"
            value={formData.password}
            onChange={handleInputChange}
            error={!!errors.password}
            helperText={errors.password}
            margin="normal"
            variant="outlined"
            InputProps={{
              startAdornment: <Lock />,
            }}
            style={{ marginBottom: '20px' }} // Add margin to create spacing
          />

          <Button type="submit" variant="contained" color="primary" fullWidth>
            Login
          </Button>

          <Link to="/register" style={{ paddingTop: '20px', marginTop: '30px', textAlign: 'center', textDecoration: 'none', display: 'block' }}>
            <span style={{ color: 'black' }}>Don't have an account?</span> <span style={{ color: 'green' }}>Register here</span>
          </Link>
        </form>

      </div>
    </div>
  );
};

export default LoginPage;
