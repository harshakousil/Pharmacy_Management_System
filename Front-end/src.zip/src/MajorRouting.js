
import React from "react";
import LoginPage from "./Registration/LoginPage";
import AdminDashboard from "./Admin_UI/AdminDashBoard";
import InchargeDashboard from "./InCharge_UI/InchargeDashbaord";
import PatientDashboard from "./Patient_UI/PatientDashboard";

export default function MajorDashboard() {
  const roleName = sessionStorage.getItem("roleName");

  return (
    <div>
      {(() => {
        switch (roleName) {
          case "Admin":
            return <AdminDashboard />;
          case "Incharge":
            return <InchargeDashboard />;
          case "Patient":
            return <PatientDashboard />;
        default:
            return <LoginPage />;
        }
      })()}
    </div>
  );
}
