
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import LoginPage from './Registration/LoginPage'
import MajorDashboard from './MajorRouting';
import RegistrationPage from './Registration/Registartion';
function App() {

  var role=sessionStorage.getItem("roleName")
  console.log(role);
  return(
    
 
<div>
<BrowserRouter>

<Routes>
  <Route path="/" element={<LoginPage></LoginPage>}></Route>
  <Route path="/register" element={<RegistrationPage></RegistrationPage>}></Route>
  <Route path="/*" element={<MajorDashboard></MajorDashboard>}></Route>
</Routes>
</BrowserRouter>
</div>

  );
  }
export default App;
