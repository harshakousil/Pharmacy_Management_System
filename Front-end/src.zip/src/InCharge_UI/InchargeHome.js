
import React, { useState } from 'react';
import { CssBaseline, Drawer, List, ListItem, ListItemText, ListItemIcon, Divider, IconButton, AppBar, Toolbar, InputBase, Button } from '@material-ui/core';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import { Home as HomeIcon, Settings as SettingsIcon, Menu as MenuIcon, Search as SearchIcon, ShoppingCartRounded as ShoppingCartIcon } from '@material-ui/icons';
import { Link, useNavigate } from 'react-router-dom';
import { useMediaQuery } from '@material-ui/core';

const drawerWidth = 240;

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
  },
  appBar: {
    backgroundColor: '#4CAF50', // Green color related to pharma
    zIndex: theme.zIndex.drawer + 1,
  },
  iconGreen: {
    color: 'green', // Apply the green color to the icons
  },
  logo: {
    marginRight: theme.spacing(2),
    flexGrow: 1,
  },
  search: {
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: '#FFFFFF', // White background color
    '&:hover': {
      backgroundColor: '#FFFFFF', // White background color on hover
    },
    marginLeft: theme.spacing(2),
    width: 'auto',
    [theme.breakpoints.up('sm')]: {
      marginLeft: theme.spacing(3),
      width: 'auto',
    }
  },
  searchIcon: {
    padding: theme.spacing(0, 2),
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: 'black', // Set the icon color to black
  },
  inputRoot: {
    color: 'black',
  },
  inputInput: {
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)}px)`,
    transition: theme.transitions.create('width'),
    width: '100%',
    [theme.breakpoints.up('sm')]: {
      width: '12ch',
      '&:focus': {
        width: '20ch',
      },
    },
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
  },
  drawerPaper: {
    width: drawerWidth,
  },
  drawerContainer: {
    overflow: 'auto',
  },
  menuButton: {
    marginRight: theme.spacing(2),
    [theme.breakpoints.up('md')]: {
      display: 'none',
    },
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
  },
  drawerContent: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
}));

const InchargeHome = () => {
  const navigate=useNavigate();
  const classes = useStyles();
  const theme = useTheme();
  const [mobileOpen, setMobileOpen] = useState(false);
  const isTabletOrLarger = useMediaQuery(theme.breakpoints.up('md'));

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };
  const handlelogout = () => {
  
    sessionStorage.removeItem("roleName");
    navigate("/")
  }
  const sideNavRoutes = [
    { path: '/home', label: 'Home', icon: <HomeIcon /> },
    { path: '/OrderDetails', label: 'Order Details', icon: <ShoppingCartIcon /> },
    { path: '/generatebill', label: 'Generate Bills', icon: <SettingsIcon /> },
  ];

  return (
    <div className={classes.root}>
      <CssBaseline />
      <AppBar position="fixed" className={classes.appBar}>
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            className={classes.menuButton}
          >
            <MenuIcon />
          </IconButton>
          <div className={classes.logo}>
            <h2>Health Sure</h2>
          </div>
          <div >
            <div>
              <Button style={{ backgroundColor: 'white', color: 'black' }} onClick={handlelogout} >Logout </Button>
              
            </div>
          </div>
        </Toolbar>
      </AppBar>
      <nav>
        {isTabletOrLarger ? (
          <Drawer
            className={classes.drawer}
            variant="permanent"
            classes={{
              paper: classes.drawerPaper,
            }}
            open
          >
            <Toolbar />
            <div className={classes.drawerContainer}>
              <div className={classes.drawerContent}>
                <List>
                  {sideNavRoutes.map((route) => (
                    <ListItem
                      button
                      component={Link}
                      to={route.path}
                      key={route.path}
                      autoFocus={route.path === '/home'} // Auto focus on the Home route by default
                    >
                      <ListItemIcon className={classes.iconGreen}>{route.icon}</ListItemIcon>
                      <ListItemText primary={route.label} />
                    </ListItem>
                  ))}
                </List>
                <Divider />
              </div>
            </div>
          </Drawer>
        ) : (
          <Drawer
            className={classes.drawer}
            variant="temporary"
            classes={{
              paper: classes.drawerPaper,
            }}
            open={mobileOpen}
            onClose={handleDrawerToggle}
          >
            <Toolbar />
            <div className={classes.drawerContainer}>
              <div className={classes.drawerContent}>
                <List>
                  {sideNavRoutes.map((route) => (
                    <ListItem
                      button
                      component={Link}
                      to={route.path}
                      key={route.path}
                      autoFocus={route.path === '/home'} // Auto focus on the Home route by default
                    >
                      <ListItemIcon>{route.icon}</ListItemIcon>
                      <ListItemText primary={route.label} />
                    </ListItem>
                  ))}
                </List>
                <Divider />
              </div>
            </div>
          </Drawer>
        )}
      </nav>
    </div>
  );
};

export default InchargeHome;
