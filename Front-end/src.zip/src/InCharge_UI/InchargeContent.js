// import React, { useEffect, useState } from 'react';
// import {
//   Grid,
//   Card,
//   CardContent,
//   Typography,
//   Button,
//   Box,
//   TextField,
//   Select,
//   MenuItem,
// } from '@material-ui/core';
// import { makeStyles } from '@material-ui/core/styles';
// import useMediaQuery from '@material-ui/core/useMediaQuery';
// import axios from 'axios';

// const useStyles = makeStyles((theme) => ({
//   mainContainer: {
//     marginTop: '100px',
//     marginLeft: '250px',
//     padding: '20px',
//     // backgroundColor: 'lightgrey',
//     borderRadius: '5px',
//   },
//   card: {
//     display: 'flex',
//     width: "300px",
//     flexDirection: 'column', // Change the flexDirection to colum
//     marginBottom: theme.spacing(2),
//     backgroundColor: 'white',
//     boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
//     borderRadius: '10px',
//     padding: 0,
//   },
//   cardContent: {
//     display: 'flex',
//     flexDirection: 'column',
//     flex: 1,
//     padding: '8px',
//   },
//   cardImage: {
//     width: '150px',
//     height: 'auto',
//     padding: '5px',
//     objectFit: 'cover',
//     marginRight: theme.spacing(2),
//   },
//   quantityContainer: {
//     display: 'flex',
//     alignItems: 'center',
//     marginTop: theme.spacing(2),
//   },
//   imageContainer: {
//     flex: '1 0 auto', // This ensures the image takes up space but doesn't grow
//     display: 'flex',
//     alignItems: 'center',
//     justifyContent: 'center',
//   },
//   quantityText: {
//     marginRight: theme.spacing(1),
//     fontWeight: 'bold',
//     fontSize: '15px',
//   },
//   addToCartButton: {
//     marginTop: '10px',
//     backgroundColor: '#5D9C59',
//     color: 'white',
//     '&:hover': {
//       backgroundColor: '#3C6255',
//     },
//   },
//   soldContainer: {
//     display: 'flex',
//     alignItems: 'center',
//     marginTop: theme.spacing(1),
//   },
//   textField: {
//     marginLeft: theme.spacing(1),
//     marginRight: theme.spacing(1),
//     width: '100px',
//   },
//   updateButton: {
//     backgroundColor: '#5D9C59',
//     color: 'white',
//     marginTop: theme.spacing(2), // Add marginTop to the Update button
//     '&:hover': {
//       backgroundColor: '#3C6255',
//     },
//   },
//   cardTitle: {
//     fontSize: '18px',
//     fontWeight: 'bold',
//     marginBottom: theme.spacing(1),
//   },
//   cardContentText: {
//     fontSize: '14px',
//     marginBottom: theme.spacing(1),
//   },
//   updateButtonText: {
//     textTransform: 'uppercase',
//   },
// }));

// const InchargeContent = () => {
//   const classes = useStyles();
//   const isTablet = useMediaQuery('(max-width: 1024px)');
//   const isMobile = useMediaQuery('(max-width: 600px)');

//   const [cardsData, setCardsData] = useState([]);
//   const [selectedCardData, setSelectedCardData] = useState(null);
//   const [searchText, setSearchText] = useState('');
//   const [sortOption, setSortOption] = useState('');
//   const [filterOption, setFilterOption] = useState('');

//   const columns = isMobile ? 1 : isTablet ? 2 : 3;

//   window.addEventListener("unload", (event) => {
//     GetMedincedata();
//   });

//   useEffect(() => {
//     GetMedincedata();
//   }, []);
//   useEffect(() => {
//     // Update selectedCardData whenever cardsData changes
//     if (selectedCardData) {
//       const updatedSelectedCardData = cardsData.find((card) => card.id === selectedCardData.id);
//       setSelectedCardData(updatedSelectedCardData);
//     }
//   }, [cardsData]);

//   const GetMedincedata = async () => {
//     try {
//       const Response = await axios({
//         method: 'GET',
//         url: 'http://localhost:9091/GetAllMedicines', // Update with your actual endpoint
//         headers: { 'content-type': 'application/json' },
//       });

//       if (Response) {
//         setCardsData(Response.data);
//       } else {
//         alert("Data Mismatch. Try Again");
//       }
//     } catch (error) {
//       console.error('Error:', error);
//     }
//   };

//   const getBlobFromBase64 = (base64String) => {
//     const binaryString = window.atob(base64String);
//     const bytes = new Uint8Array(binaryString.length);
//     for (let i = 0; i < binaryString.length; i++) {
//       bytes[i] = binaryString.charCodeAt(i);
//     }
//     return new Blob([bytes], { type: 'image/jpeg' });
//   };

//   const handleSoldUpdate = (cardId, soldValue) => {
//     const updatedCardsData = cardsData.map((card) => {
//       if (card.id === cardId) {
//         const availableQuantity = card.stockQuantity;
//         const soldQuantity = parseInt(soldValue, 10);
//         if (!isNaN(soldQuantity)) {
//           const updatedCard = { ...card };
//           updatedCard.stockQuantity = Math.max(availableQuantity - soldQuantity, 0);
//           return updatedCard;
//         }
//       }
//       return card;
//     });

//     setCardsData(updatedCardsData);
//   };

//   const handleUpdateClick = async () => {
//     const updatedCardsData = [...cardsData];
//     setCardsData(updatedCardsData);
//     try {
//       const response = await axios({
//         method: 'POST',
//         url: 'http://localhost:9091/addMedicine',
//         data: selectedCardData,
//         headers: { 'content-type': 'application/json' },
//       });

//       if (response) {
//         alert("Data Updated Successfully");
//       }
//     } catch (error) {
//       console.error('Error updating data:', error);
//     }
//   };

//   const handleClear = () => {
//     setSearchText('');
//     setSortOption('');
//     setFilterOption('');
//   };

//   const filteredAndSortedData = () => {
//     let filteredData = [...cardsData];

//     if (searchText) {
//       filteredData = filteredData.filter((card) =>
//         card.medicineName.toLowerCase().includes(searchText.toLowerCase())
//       );
//     }

//     else if (sortOption === 'quantityLowToHigh') {
//       filteredData.sort((a, b) => a.stockQuantity - b.stockQuantity);
//     }

//     else if (sortOption === 'quantityHighToLow') {
//       filteredData.sort((a, b) => b.stockQuantity - a.stockQuantity);
//     }

//     else if (sortOption === 'priceLowToHigh') {
//       filteredData.sort((a, b) => a.unitPrice - b.unitPrice);
//     }

//     return filteredData;

//   };

//   return (
//     <div className={classes.mainContainer}>
//       <h3>Welcome to Incharge home page</h3>

//       <Grid container spacing={2} alignItems="center">
//         <Grid item xs={12} sm={6} md={6}>
//           <div style={{ display: 'flex', alignItems: 'center' }}>
//             <TextField
//               label="Search by Medicine Name"
//               variant="outlined"
//               fullWidth
//               value={searchText}
//               onChange={(e) => setSearchText(e.target.value)}
//             />
//           </div>
//         </Grid>
//         <Grid item xs={12} sm={6} md={6}>
//           <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-evenly' }}>
//             <Select
//               value={sortOption}
//               onChange={(e) => setSortOption(e.target.value)}
//               displayEmpty
//             >
//               <MenuItem value="">Sort By</MenuItem>
//               <MenuItem value="quantityLowToHigh">Quantity: Low to High</MenuItem>
//               <MenuItem value="quantityHighToLow">Quantity: High to Low</MenuItem>
//               <MenuItem value="priceLowToHigh">Price: Low to High</MenuItem>
//             </Select>
//             {/* Add your Filter Select here */}
//             <Button variant="contained" color="secondary" onClick={handleClear}>
//               Clear
//             </Button>
//           </div>
//         </Grid>
//       </Grid>

//       <Grid container spacing={2}>
//         {filteredAndSortedData().map((card, index) => (
//           <Grid item xs={12} sm={6} md={4} lg={Math.floor(12 / columns)} key={index}>
//             <Card className={classes.card}>
//               <div className={classes.cardContent}>
//                 <div className={classes.imageContainer}>
//                   <img
//                     src={URL.createObjectURL(getBlobFromBase64(card.image))}
//                     alt={card.title}
//                     className={classes.cardImage}
//                   />
//                 </div>
//                 <div className={classes.cardDetails}>
//                   <Typography variant="h6" component="h2" className={classes.cardTitle}>
//                     {card.medicineName}
//                   </Typography>
//                   <Typography variant="p" component="h4" className={classes.cardContentText}>
//                     Manufacturer: {card.manufacturerName}
//                   </Typography>
//                   <Typography variant="p" component="h4" className={classes.cardContentText}>
//                     Cost: {card.unitPrice}
//                   </Typography>
//                   <Box className={classes.quantityContainer}>
//                     <Typography className={classes.quantityText}>
//                       Available: {card.stockQuantity}
//                     </Typography>
//                   </Box>
//                   <TextField
//                     className={classes.textField}
//                     label="Sold:"
//                     type="number"
//                     value={card.quantity}
//                     inputProps={{ min: 0, max: card.available }}
//                     onChange={(e) => handleSoldUpdate(card.id, e.target.value)}
//                   />
//                   <Button
//                     variant="contained"
//                     className={classes.updateButton}
//                     onClick={() => handleUpdateClick()}
//                     disabled={card.quantity === 0}
//                   >
//                     <Typography variant="button" className={classes.updateButtonText}>
//                       Update
//                     </Typography>
//                   </Button>
//                 </div>
//               </div>
//             </Card>
//           </Grid>
//         ))}
//       </Grid>
//     </div>
//   );
// };

// export default InchargeContent;

import React, { useEffect, useState } from 'react';
import {
  Grid,
  Card,
  CardContent,
  Typography,
  Box,
  TextField,
  Button,
} from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import axios from 'axios';

const useStyles = makeStyles((theme) => ({
  mainContainer: {
    marginTop: '100px',
    marginLeft: '250px',
    padding: '20px',
    borderRadius: '5px',
  },
  card: {
    display: 'flex',
    width: "300px",
    flexDirection: 'column',
    marginBottom: theme.spacing(2),
    backgroundColor: 'white',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
    borderRadius: '10px solid black',
    padding: 0,
  },
  cardContent: {
    display: 'flex',
    flexDirection: 'column',
    flex: 1,
    padding: '8px',
  },
  cardImage: {
    width: '150px',
    height: 'auto',
    padding: '5px',
    objectFit: 'cover',
    marginRight: theme.spacing(2),
  },
  quantityContainer: {
    display: 'flex',
    alignItems: 'center',
    marginTop: theme.spacing(2),
  },
  imageContainer: {
    flex: '1 0 auto',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  quantityText: {
    marginRight: theme.spacing(1),
    fontWeight: 'bold',
    fontSize: '15px',
  },
  addToCartButton: {
    marginTop: '10px',
    backgroundColor: '#5D9C59',
    color: 'white',
    '&:hover': {
      backgroundColor: '#3C6255',
    },
  },
  soldContainer: {
    display: 'flex',
    alignItems: 'center',
    marginTop: theme.spacing(1),
  },
  textField: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
    width: '100px',
  },
  updateButton: {
    backgroundColor: '#5D9C59',
    color: 'white',
    marginTop: theme.spacing(2),
    '&:hover': {
      backgroundColor: '#3C6255',
    },
  },
  cardTitle: {
    fontSize: '18px',
    fontWeight: 'bold',
    marginBottom: theme.spacing(1),
  },
  cardContentText: {
    fontSize: '14px',
    marginBottom: theme.spacing(1),
  },
  updateButtonText: {
    textTransform: 'uppercase',
  },
  searchContainer: {
    display: 'flex',
    alignItems: 'center',
    flexDirection:'row',
    width:"80%",
    marginBottom: theme.spacing(2),
  },
}));

const InchargeContent = () => {
  const classes = useStyles();
  const isTablet = useMediaQuery('(max-width: 1024px)');
  const isMobile = useMediaQuery('(max-width: 600px)');

  const [cardsData, setCardsData] = useState([]);
  const [searchText, setSearchText] = useState('');
  const [selectedCardData, setSelectedCardData] = useState(null);

  const columns = isMobile ? 1 : isTablet ? 2 : 3;

  useEffect(() => {
    GetMedincedata();
  }, []);

  const GetMedincedata = async () => {
    try {
      const Response = await axios({
        method: 'GET',
        url: 'http://localhost:9091/GetAllMedicines',
        headers: { 'content-type': 'application/json' },
      });

      if (Response) {
        setCardsData(Response.data);
      } else {
        alert("Data Mismatch. Try Again");
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const getBlobFromBase64 = (base64String) => {
    const binaryString = window.atob(base64String);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return new Blob([bytes], { type: 'image/jpeg' });
  };

  const handleSoldUpdate = (index, soldValue) => {
    const updatedCardsData = cardsData.map((card, cardIndex) => {
      if (cardIndex === index) {
        const availableQuantity = card.stockQuantity;
        const soldQuantity = parseInt(soldValue, 10);
        if (!isNaN(soldQuantity)) {
          console.log(soldQuantity + " " +availableQuantity);
          if (soldQuantity <= availableQuantity) {
            const updatedCard = { ...card };
            updatedCard.stockQuantity = Math.max(availableQuantity - soldQuantity, 0);
            setSelectedCardData(updatedCard);
            return updatedCard;
          } else {
            // Alert when sold quantity is greater than available quantity
            alert("Sold quantity cannot exceed available quantity.");
            
          }
        }
      }
      return card;
    });
  
    setCardsData(updatedCardsData);
  };
  

  const handleUpdateClick = async () => {
    console.log(selectedCardData);
  
    if (selectedCardData) {
      const cardToUpdate = cardsData.find(card => card.index === selectedCardData.index);
   
  console.log(cardToUpdate)
      if (cardToUpdate) {
        console.log(selectedCardData.stockQuantity + " "+cardToUpdate.stockQuantity)
        if (selectedCardData.quantity === cardToUpdate.quantity) {
          try {
            const response = await axios({
              method: 'POST',
              url: 'http://localhost:9091/addMedicine',
              data: selectedCardData,
              headers: { 'content-type': 'application/json' },
            });
  
            if (response) {
              alert("Data Updated Successfully");
            }
          } catch (error) {
            console.error('Error updating data:', error);
          }
        } else {
          alert("Cannot update. Selected quantity exceeds available quantity.");
        }
      } else {
        alert("Selected card not found in the data.");
      }
    } else {
      alert("Please enter the sold quantity to update");
    }
  }
  
    const handleClearSearch = () => {
      setSearchText('');
    };

    const filteredData = cardsData.filter((card) =>
    card.medicineName.toLowerCase().includes(searchText.toLowerCase()) ||
    card.manufacturerName.toLowerCase().includes(searchText.toLowerCase())
  );

    return (
      <div className={classes.mainContainer}>
        <h3>Welcome to Incharge home page</h3>

        <div className={classes.searchContainer}>
          <TextField
            label="Search by Medicine Name or Manufacturer"
            variant="outlined"
            style={{ maxWidth: '60%', width: '100%' }}
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
          />
          <Button
            variant="contained"
            color="primary"
            style={{ marginLeft: '2rem', backgroundColor:'#3C6256' }}
            onClick={handleClearSearch}
          >
            Clear
          </Button>
        </div>

        <Grid container spacing={2}>
          {filteredData.map((card, index) => (
            <Grid item xs={12} sm={6} md={4} lg={Math.floor(12 / columns)} key={index}>
              <Card className={classes.card}>
                <div className={classes.cardContent}>
                  <div className={classes.imageContainer}>
                    <img
                      src={URL.createObjectURL(getBlobFromBase64(card.image))}
                      alt={card.title}
                      className={classes.cardImage}
                    />
                  </div>
                  <div className={classes.cardDetails}>
                    <Typography variant="h6" component="h2" className={classes.cardTitle}>
                      {card.medicineName}
                    </Typography>
                    <Typography variant="p" component="h4" className={classes.cardContentText}>
                      Manufacturer: {card.manufacturerName}
                    </Typography>
                    <Typography variant="p" component="h4" className={classes.cardContentText}>
                      Cost: {card.unitPrice}
                    </Typography>
                    <Box className={classes.quantityContainer}>
                      <Typography className={classes.quantityText}>
                        Available: {card.stockQuantity}
                      </Typography>
                    </Box>
                    <TextField
                      className={classes.textField}
                      label="Sold:"
                      type="number"
                      value={card.quantity}
                      inputProps={{ min: 0, max: card.stockQuantity }}
                      onChange={(e) => handleSoldUpdate(index, e.target.value)}
                    />
                    <Button
                      variant="contained"
                      className={classes.updateButton}
                      onClick={() => handleUpdateClick()}
                      disabled={card.quantity === 0}
                    >
                      <Typography variant="button" className={classes.updateButtonText}>
                        Update
                      </Typography>
                    </Button>
                  </div>
                </div>
              </Card>
            </Grid>
          ))}
        </Grid>
      </div>
    );
  };

  export default InchargeContent;
