
import React, { useEffect, useState } from 'react';
import {
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Select,
  MenuItem,
  InputBase,
  Collapse,
  Typography,
  TableSortLabel,
  TextField,
} from '@mui/material';

import axios from 'axios';
import { TablePagination } from '@material-ui/core';

const OrderTable = () => {
  const [selectedOrderId, setSelectedOrderId] = useState(null);
  const [selectedMedicine, setSelectedMedicine] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [orders, setOrders] = useState([]);
  const [showAllRows, setShowAllRows] = useState(false);
  const [search, setSearch] = useState('');
  const [orderSort, setOrderSort] = useState('asc');
  const [orderBy, setOrderBy] = useState('orderId');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [sortedData, setSortedData] = useState([]);
  const [sortingOccurred, setSortingOccurred] = useState(false);

  useEffect(() => {
    GetOrdersData();
  }, []);

  useEffect(() => {
    if (!sortingOccurred) {
      GetOrdersData();
    }
  }, [sortingOccurred]);
  const GetOrdersData = async () => {
    try {
      const Response = await axios({
        method: 'GET',
        url: 'http://localhost:9092/findAllPatientOrders',
        headers: { 'content-type': 'application/json' },
      });

      if (Response.data) {
        const ordersData = Response.data.map((patient) => {
          const patientEmail = patient.email;
          const patientName = patient.name;
          const patientOrders = patient.orders.map((order) => {
            const orderId = order.orderId;
            const deliveryDate = new Date(order.deliveryDate);
            const status = order.status;
            const medicines = order.medicines.map((medicine) => ({
              medicineId: medicine._id,
              medicineName: medicine.medicineName,
              manufacturerName: medicine.manufacturerName,
              quantityOrdered: medicine.quantity_ordered,
              unitPrice: medicine.unitPrice,
            }));

            return {
              orderId,
              deliveryDate,
              status,
              medicines,
            };
          });

          return {
            patientEmail,
            patientName,
            orders: patientOrders,
          };
        });

        setOrders(ordersData);
        const sortedData = sortData(Response.data, 'asc', 'orderId');
        setSortedData(sortedData);
      } else {
        alert("No Orders Found");
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };


  const handleOrderStatus = async (event, orderId, patientEmail) => {
    const newStatus = event.target.value;
    setSelectedStatus(newStatus);
    const Statusdata = {
      email: patientEmail,
      orderId: orderId,
      newStatus: newStatus,
    };
    try {
      const Response = await axios({
        method: 'POST',
        url: 'http://localhost:9092/updateOrderStatus',
        headers: { 'content-type': 'application/json' },
        data: Statusdata,
      });
      if (Response) {
        alert(`Order ${orderId} status updated to ${newStatus}`);
        window.location.reload(true);
      } else {
        alert("Data Mismatched");
      }
    } catch (error) {
      console.log("Error :" + error);
    }
  };

  const handleRowClick = (orderId) => {
    setSelectedOrderId(orderId);
    setSelectedMedicine('');
  };

  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    const formattedDate = new Date(dateString);
    formattedDate.setFullYear(formattedDate.getFullYear() - 2000);
    return formattedDate.toLocaleDateString(undefined, options);
  };

  const calculateTotalAmount = (medicines) => {
    return medicines.reduce((total, medicine) => {
      const medicineTotal = parseInt(medicine.quantityOrdered) * parseInt(medicine.unitPrice);
      return total + medicineTotal;
    }, 0);
  };

  const handleSort = (property) => (event) => {
    const isAsc = orderBy === property && orderSort === 'asc';
    const newOrder = isAsc ? 'desc' : 'asc';
    setOrderSort(newOrder);
    setOrderBy(property);
  
    // Sort the data based on the clicked column
    const sortedData = sortData(orders, newOrder, property);
    setSortedData(sortedData);
  
    // Set the sortingOccurred flag to true
    setSortingOccurred(true);
  };

  const sortData = (data, order, orderBy) => {
    return data.slice().sort((a, b) => {
      if (orderBy === 'deliveryDate') {
        return order === 'asc'
          ? new Date(a.orders[0][orderBy]) - new Date(b.orders[0][orderBy])
          : new Date(b.orders[0][orderBy]) - new Date(a.orders[0][orderBy]);
      }
      return order === 'asc'
        ? a.orders[0][orderBy].localeCompare(b.orders[0][orderBy])
        : b.orders[0][orderBy].localeCompare(a.orders[0][orderBy]);
    });
  };
  const handleSearchChange = (event) => {
    setSearch(event.target.value);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const filteredOrders = orders.filter((patient) =>
    patient.orders.some((order) => order.status !== "Delivered")
  );

  const filteredAndSortedOrders = filteredOrders
    .filter((patient) =>
      patient.patientName.toLowerCase().includes(search.toLowerCase())
    )
    .sort((a, b) => {
      if (orderBy === 'deliveryDate') {
        return orderSort === 'asc'
          ? new Date(a.orders[0][orderBy]) - new Date(b.orders[0][orderBy])
          : new Date(b.orders[0][orderBy]) - new Date(a.orders[0][orderBy]);
      }
      return orderSort === 'asc'
        ? a.orders[0][orderBy].localeCompare(b.orders[0][orderBy])
        : b.orders[0][orderBy].localeCompare(a.orders[0][orderBy]);
    });

   const renderData = orders;
const paginatedOrders = renderData.slice(
  page * rowsPerPage,
  page * rowsPerPage + rowsPerPage
);

  return (
    <div style={{ marginLeft: '10rem', marginTop: '100px', marginBottom: '20px', width: '80%' }}>
      <TableContainer component={Paper} style={{ marginLeft: '10rem', width: '80%' }}>
      <Table stickyHeader>
          <TableHead>
            <TableRow>
              <TableCell>
                <TableSortLabel
                  active={orderBy === 'patientName'}
                  direction={orderSort}
                  onClick={handleSort('patientName')}
                >
                  Patient Name
                </TableSortLabel>
              </TableCell>
              <TableCell>
                <TableSortLabel
                  active={orderBy === 'orderId'}
                  direction={orderSort}
                  onClick={handleSort('orderId')}
                >
                  Order Id
                </TableSortLabel>
              </TableCell>
              <TableCell>
                <TableSortLabel
                  active={orderBy === 'deliveryDate'}
                  direction={orderSort}
                  onClick={handleSort('deliveryDate')}
                >
                  Delivery Date
                </TableSortLabel>
              </TableCell>
              <TableCell>Total Amount</TableCell>
              <TableCell>
                Status
              </TableCell>
              <TableCell>Set Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {paginatedOrders.map((patient) =>
              patient.orders
                .filter((order) => order.status !== "Delivered")
                .map((order) => (
                  <React.Fragment key={order.orderId}>
                    <TableRow
                      onClick={() => handleRowClick(order.orderId)}
                      style={{ cursor: 'pointer' }}
                    >
                      <TableCell>{patient.patientName}</TableCell>
                      <TableCell component="th" scope="row">
                        {order.orderId}
                      </TableCell>
                      <TableCell>{formatDate(order.deliveryDate)}</TableCell>
                      <TableCell>{calculateTotalAmount(order.medicines)}</TableCell>
                      <TableCell>{order.status}</TableCell>
                      <TableCell>
                        {order.status === "Delivered" ? (
                          ""
                        ) : (
                          <Select
                            sx={{ width: "120px" }}
                            value={selectedStatus}
                            onChange={(event) =>
                              handleOrderStatus(event, order.orderId, patient.patientEmail)
                            }
                          >
                            <MenuItem value="Processing">Processing</MenuItem>
                            <MenuItem value="Shipped">Shipped</MenuItem>
                            <MenuItem value="Delivered">Delivered</MenuItem>
                          </Select>
                        )}
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={6}>
                        <Collapse in={selectedOrderId === order.orderId} timeout="auto" unmountOnExit>
                          <Typography variant="h6" gutterBottom component="div">
                            Medicines
                          </Typography>
                          <Table size="small">
                            <TableHead>
                              <TableRow>
                                <TableCell>Medicine Name</TableCell>
                                <TableCell>Quantity</TableCell>
                                <TableCell>Unit Price</TableCell>
                                <TableCell>Manufacturer Name</TableCell>
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {order.medicines.map((medicine, index) => (
                                <TableRow key={index}>
                                  <TableCell>{medicine.medicineName}</TableCell>
                                  <TableCell>{medicine.quantityOrdered}</TableCell>
                                  <TableCell>{medicine.unitPrice}</TableCell>
                                  <TableCell>{medicine.manufacturerName}</TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </Collapse>
                      </TableCell>
                    </TableRow>
                  </React.Fragment>
                ))
            )}
          </TableBody>
        </Table>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={filteredAndSortedOrders.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />

      </TableContainer>
    </div>
  );
};

export default OrderTable;















// import React, { useEffect, useState } from 'react';
// import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Checkbox, Button, MenuItem, Select } from '@mui/material';
// import { Link } from 'react-router-dom';
// import axios from 'axios';

// const OrderTable = () => {
//   const [selectedOrderId, setSelectedOrderId] = useState(null);
//   const [selectedMedicine, setSelectedMedicine] = useState('');
//   const [selectedStatus, setSelectedStatus] = useState('');
//   const [orders, setorders] = useState([]);
//   const [showAllRows, setShowAllRows] = useState(false);



//   window.addEventListener("unload", (event) => {
//     GetOrdersData();
//     console.log("API call after page reload");
//   });
//   useEffect(() => {
//     GetOrdersData();
//   }, []);
//   const GetOrdersData = async () => {
//     try {
//       const Response = await axios({
//         method: 'GET',
//         url: 'http://localhost:9092/findAllPatientOrders',
//         headers: { 'content-type': 'application/json' },
//       });

//       if (Response.data) {
//         const ordersData = Response.data.map(patient => {
//           const patientEmail=patient.email
//           const patientName = patient.name;
//           const patientOrders = patient.orders.map(order => {
//             const orderId = order.orderId;
//             const deliveryDate = new Date(order.deliveryDate);
//             const status = order.status;
//             const medicines = order.medicines.map(medicine => ({
//               medicineId: medicine._id,
//               medicineName: medicine.medicineName,
//               manufacturerName: medicine.manufacturerName,
//               quantityOrdered: medicine.quantity_ordered,
//               unitPrice: medicine.unitPrice,
//             }));

//             return {
//               orderId,
//               deliveryDate,
//               status,
//               medicines,
//             };
//           });

//           return {
//             patientEmail,
//             patientName,
//             orders: patientOrders,
//           };
//         });

//         setorders(ordersData);
//       } else {
//         alert("No Orders Found");
//       }
//     } catch (error) {
//       console.error('Error:', error);
//     }
//   };

//   const handleOrderStatus =async (event, orderId,patientEmail) => {
//     const newStatus = event.target.value;
//     setSelectedStatus(newStatus);
//   const Statusdata=
//   {
//     email:patientEmail,
//     orderId:orderId,
//     newStatus:newStatus
//   }
//       try {
//         const Response = await axios({
//           method: 'POST',
//           url: 'http://localhost:9092/updateOrderStatus',
//           headers: { 'content-type': 'application/json' },
//           data:Statusdata
//         });
//         if(Response)
//         {
//           alert(`Order ${orderId} status updated to ${newStatus}`);
//           window.location.reload(true);
//         }
//         else{
//           alert("Data Mismatched");
//         }
//       }
//         catch(error){
//         console.log("Error :" +error);
//         }

//   };



//   const handleRowClick = (orderId) => {
//     setSelectedOrderId(orderId);
//     setSelectedMedicine(''); // Reset selectedMedicine when selecting a different order

//   };

//   const handledeliveryButton = () => {
//     alert("Delivery Started")
//     setSelectedOrderId(null);
//   };

//   const formatDate = (dateString) => {
//     const options = { year: 'numeric', month: 'long', day: 'numeric' };
//     const formattedDate = new Date(dateString);
//     formattedDate.setFullYear(formattedDate.getFullYear() - 2000);
//     return formattedDate.toLocaleDateString(undefined, options);
//   };
//   const calculateTotalAmount = (medicines) => {
//     return medicines.reduce((total, medicine) => {
//       const medicineTotal =parseInt(medicine.quantityOrdered) * parseInt(medicine.unitPrice);
//       return total + medicineTotal;
//     }, 0);
//   };
//   return (
//     <div>
//       <TableContainer component={Paper} style={{ marginLeft: '16rem', marginTop: '100px', marginBottom: '20px', width: '80%' }}>
//         <Table>
//           <TableHead>
//             <TableRow>
//               <TableCell>Patinet Name</TableCell>
//               <TableCell>Order Id</TableCell>
//               <TableCell>Delivery Date</TableCell>
//               <TableCell>Total Amount</TableCell>
//               <TableCell>Status</TableCell>
//               <TableCell>Set Status</TableCell>
//             </TableRow>
//           </TableHead>
//           <TableBody>
//             {orders.map((patient) =>
//               patient.orders.map((order) => (
//                 order.status !== "Delivered" &&(
//                 <TableRow
//                   key={order.orderId}
//                   onClick={() => handleRowClick(order.orderId)}
//                   style={{ cursor: 'pointer' }}
//                 >
//                   <TableCell>{patient.patientName}</TableCell>
//                   <TableCell component="th" scope="row">
//                     {order.orderId}
//                   </TableCell>
//                   <TableCell>{formatDate(order.deliveryDate)}</TableCell>
//                   <TableCell>{calculateTotalAmount(order.medicines)}</TableCell>
//                   <TableCell>{order.status}</TableCell>
//                   <TableCell>
//                     {order.status === "Delivered" ? (
//                       ""
//                     ) : (
//                       <Select
//                         sx={{ width: "120px" }}
//                         value={selectedStatus}
//                         onChange={(event) => handleOrderStatus(event, order.orderId,patient.patientEmail)}
//                       >
//                         <MenuItem value="Processing">Processing</MenuItem>
//                         <MenuItem value="Shipped">Shipped</MenuItem>
//                         <MenuItem value="Delivered">Delivered</MenuItem>
//                       </Select>
//                     )}
//                   </TableCell>
//                 </TableRow>
//               )))
//             )}
//           </TableBody>
//         </Table>
//       </TableContainer>

//       {selectedOrderId !== null && (
//         <div>
//           <TableContainer component={Paper} style={{ marginLeft: '16rem', marginBottom: '20px', width: '80%' }}>
//             <Table>
//               <TableHead>
//                 <TableRow>
//                   <TableCell>Medicine Name</TableCell>
//                   <TableCell>Quantity</TableCell>
//                   <TableCell>Unit Price</TableCell>
//                   <TableCell>ManufacturerName</TableCell>
//                 </TableRow>
//               </TableHead>
//               <TableBody>
//                 {orders.find((o) => o.orders.some(order => order.orderId === selectedOrderId))
//                   .orders.find((order) => order.orderId === selectedOrderId)
//                   .medicines.map((medicine, index) => (
//                     <TableRow key={index}>
//                       <TableCell>{medicine.medicineName}</TableCell>
//                       <TableCell>{medicine.quantityOrdered}</TableCell>
//                       <TableCell>{medicine.unitPrice}</TableCell>
//                       <TableCell>{medicine.manufacturerName}</TableCell>
//                     </TableRow>
//                   ))}
//               </TableBody>
//             </Table>
//           </TableContainer>
//         </div>
//       )}
//     </div>
//   );
// };
// export default OrderTable;
