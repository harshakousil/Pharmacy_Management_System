
// import React, { useEffect, useState } from 'react';
// import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Checkbox, Button, MenuItem, Select } from '@mui/material';
// import { Link } from 'react-router-dom';
// import axios from 'axios';

// const GenerateBill = () => {
//   const [selectedOrderId, setSelectedOrderId] = useState(null);
//   const [selectedMedicine, setSelectedMedicine] = useState('');
//   const [selectedStatus, setSelectedStatus] = useState('');
//   const [orders, setorders] = useState([]);


//   window.addEventListener("unload", (event) => {
//     GetOrdersData();
//     console.log("API call after page reload");
//   });
//   useEffect(() => {
//     GetOrdersData();
//   }, []);
//   const GetOrdersData = async () => {
//     try {
//       const Response = await axios({
//         method: 'GET',
//         url: 'http://localhost:9092/findAllPatientOrders',
//         headers: { 'content-type': 'application/json' },
//       });

//       if (Response.data) {
//         const ordersData = Response.data.map(patient => {
//           const patientEmail=patient.email
//           const patientName = patient.name;
//           const patientOrders = patient.orders.map(order => {
//             const orderId = order.orderId;
//             const deliveryDate = new Date(order.deliveryDate);
//             const status = order.status;
//             const medicines = order.medicines.map(medicine => ({
//               medicineId: medicine._id,
//               medicineName: medicine.medicineName,
//               manufacturerName: medicine.manufacturerName,
//               quantityOrdered: medicine.quantity_ordered,
//               unitPrice: medicine.unitPrice,
//             }));

//             return {
//               orderId,
//               deliveryDate,
//               status,
//               medicines,
//             };
//           });

//           return {
//             patientEmail,
//             patientName,
//             orders: patientOrders,
//           };
//         });

//         setorders(ordersData);
//       } else {
//         alert("No Orders Found");
//       }
//     } catch (error) {
//       console.error('Error:', error);
//     }
//   };

//   const handleOrderStatus =async (event, orderId,patientEmail) => {
//     const newStatus = event.target.value;
//     setSelectedStatus(newStatus);
//   const Statusdata=
//   {
//     email:patientEmail,
//     orderId:orderId,
//     newStatus:newStatus
//   }
//       try {
//         const Response = await axios({
//           method: 'POST',
//           url: 'http://localhost:9092/updateOrderStatus',
//           headers: { 'content-type': 'application/json' },
//           data:Statusdata
//         });
//         if(Response)
//         {
//           alert(`Order ${orderId} status updated to ${newStatus}`);
//           window.location.reload(true);
//         }
//         else{
//           alert("Data Mismatched");
//         }
//       }
//         catch(error){
//         console.log("Error :" +error);
//         }
  
//   };

//   const handleDownloadBill = () => {
//     // Code to handle the download functionality (e.g., generate PDF and provide print option)
//     // You can use external libraries like react-pdf or pdfmake to generate PDF
//     // For demonstration purposes, we will just log a message here.
//     alert("Bill downloaded")
//     setSelectedOrderId(null);
//     console.log('Downloading bill for Order ID:', selectedOrderId);
//   };

//   const handleRowClick = (orderId) => {
//     setSelectedOrderId(orderId);
//     setSelectedMedicine(''); // Reset selectedMedicine when selecting a different order
//   };

//   const handledeliveryButton = () => {
//     alert("Delivery Started")
//     setSelectedOrderId(null);
//   };

//   const formatDate = (dateString) => {
//     const options = { year: 'numeric', month: 'long', day: 'numeric' };
//     const formattedDate = new Date(dateString);
//     formattedDate.setFullYear(formattedDate.getFullYear() - 2000);
//     return formattedDate.toLocaleDateString(undefined, options);
//   };
//   const calculateTotalAmount = (medicines) => {
//     return medicines.reduce((total, medicine) => {
//       const medicineTotal =parseInt(medicine.quantityOrdered) * parseInt(medicine.unitPrice);
//       return total + medicineTotal;
//     }, 0);
//   };
//   return (
//     <div>
//       <TableContainer component={Paper} style={{ marginLeft: '16rem', marginTop: '100px', marginBottom: '20px', width: '80%' }}>
//         <Table>
//           <TableHead>
//             <TableRow>
//               <TableCell>Patinet Name</TableCell>
//               <TableCell>Order Id</TableCell>
//               <TableCell>Date of Order</TableCell>
//               <TableCell>Total Amount</TableCell>
//               <TableCell>Status</TableCell>
//               <TableCell>Actions</TableCell>
//             </TableRow>
//           </TableHead>
//           <TableBody>
//             {orders.map((patient) =>
//               patient.orders.map((order) => (
//                 order.status === "Delivered" &&(
//                 <TableRow
//                   key={order.orderId}
//                   onClick={() => handleRowClick(order.orderId)}
//                   style={{ cursor: 'pointer' }}
//                 >
//                   <TableCell>{patient.patientName}</TableCell>
//                   <TableCell component="th" scope="row">
//                     {order.orderId}
//                   </TableCell>
//                   <TableCell>{formatDate(order.deliveryDate)}</TableCell>
//                   <TableCell>{calculateTotalAmount(order.medicines)}</TableCell>
//                   <TableCell>{order.status}</TableCell>
//                   <TableCell><Button variant="contained" color="primary"  onClick={handleDownloadBill}>Generate Bill</Button></TableCell>
//                 </TableRow>
//               )))
//             )}
//           </TableBody>
//         </Table>
//       </TableContainer>

//       {selectedOrderId !== null && (
//         <div>
//           <TableContainer component={Paper} style={{ marginLeft: '16rem', marginBottom: '20px', width: '80%' }}>
//             <Table>
//               <TableHead>
//                 <TableRow>
//                   <TableCell>Medicine Name</TableCell>
//                   <TableCell>Quantity</TableCell>
//                   <TableCell>Unit Price</TableCell>
//                   <TableCell>ManufacturerName</TableCell>
//                 </TableRow>
//               </TableHead>
//               <TableBody>
//                 {orders.find((o) => o.orders.some(order => order.orderId === selectedOrderId))
//                   .orders.find((order) => order.orderId === selectedOrderId)
//                   .medicines.map((medicine, index) => (
//                     <TableRow key={index}>
//                       <TableCell>{medicine.medicineName}</TableCell>
//                       <TableCell>{medicine.quantityOrdered}</TableCell>
//                       <TableCell>{medicine.unitPrice}</TableCell>
//                       <TableCell>{medicine.manufacturerName}</TableCell>
                      
//                     </TableRow>
//                   ))}
//               </TableBody>
//             </Table>
//           </TableContainer>
//         </div>
//       )}
//     </div>
//   );
// };
// export default GenerateBill;



import React, { useEffect, useState } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  TablePagination,
  TableSortLabel,
  IconButton,
} from '@mui/material';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import axios from 'axios';
import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';

// Import the fonts

const GenerateBill = () => {
  const [selectedOrderId, setSelectedOrderId] = useState(null);
  const [selectedMedicine, setSelectedMedicine] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [orders, setOrders] = useState([]);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [orderBy, setOrderBy] = useState('deliveryDate');
  const [order, setOrder] = useState('asc');
  const [filterStatus, setFilterStatus] = useState('');

  pdfMake.vfs = pdfFonts.pdfMake.vfs;
  useEffect(() => {
    GetOrdersData();
  }, []);

  window.addEventListener('unload', (event) => {
    GetOrdersData();
    console.log('API call after page reload');
  });

  const GetOrdersData = async () => {
    try {
      const Response = await axios({
        method: 'GET',
        url: 'http://localhost:9092/findAllPatientOrders',
        headers: { 'content-type': 'application/json' },
      });

      if (Response.data) {
        const ordersData = Response.data.map((patient) => {
          const patientEmail = patient.email;
          const patientName = patient.name;
          const patientOrders = patient.orders.map((order) => {
            const orderId = order.orderId;
            const deliveryDate = new Date(order.deliveryDate);
            const status = order.status;
            const medicines = order.medicines.map((medicine) => ({
              medicineId: medicine._id,
              medicineName: medicine.medicineName,
              manufacturerName: medicine.manufacturerName,
              quantityOrdered: medicine.quantity_ordered,
              unitPrice: medicine.unitPrice,
            }));

            return {
              orderId,
              deliveryDate,
              status,
              medicines,
            };
          });

          return {
            patientEmail,
            patientName,
            orders: patientOrders,
          };
        });

        setOrders(ordersData);
      } else {
        alert('No Orders Found');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleDownloadBill = () => {
    // Code to handle the download functionality (e.g., generate PDF and provide print option)
    // You can use external libraries like react-pdf or pdfmake to generate PDF
    // For demonstration purposes, we will just log a message here.
    alert('Bill downloaded');
    setSelectedOrderId(null);
    console.log('Downloading bill for Order ID:', selectedOrderId);
  };

  const handleRowClick = (orderId) => {
    if (selectedOrderId === orderId) {
      setSelectedOrderId(null);
    } else {
      setSelectedOrderId(orderId);
    }
    setSelectedMedicine('');
  };

  const handledeliveryButton = () => {
    alert('Delivery Started');
    setSelectedOrderId(null);
  };

  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    const formattedDate = new Date(dateString);
    formattedDate.setFullYear(formattedDate.getFullYear() - 2000);
    return formattedDate.toLocaleDateString(undefined, options);
  };

  const calculateTotalAmount = (medicines) => {
    return medicines.reduce((total, medicine) => {
      const medicineTotal =
        parseInt(medicine.quantityOrdered) * parseInt(medicine.unitPrice);
      return total + medicineTotal;
    }, 0);
  };

  const stableSort = (array, comparator) => {
    const stabilizedThis = array.map((el, index) => [el, index]);
    stabilizedThis.sort((a, b) => {
      const order = comparator(a[0], b[0]);
      if (order !== 0) return order;
      return a[1] - b[1];
    });
    return stabilizedThis.map((el) => el[0]);
  };

  const getComparator = (order, orderBy) => {
    return (a, b) => {
      if (a[orderBy] < b[orderBy]) return -1;
      if (a[orderBy] > b[orderBy]) return 1;
      return 0;
    };
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleRequestSort = (property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const handleFilterChange = (property) => (event, value) => {
    if (value.length === 0) {
      setFilterStatus('');
    } else {
      setFilterStatus(value[0]);
    }
  };

  const handleFilterToggle = (property) => {
    if (property === 'status') {
      setFilterStatus(filterStatus ? '' : 'Delivered');
    }
  };
  const generatePDF = () => {
    if (!selectedOrderId) return;

    const order = orders.flatMap((patient) =>
      patient.orders.filter((o) => o.orderId === selectedOrderId)
    )[0];

    const pdfContent = {
      content: [
        {
          text: 'Health Sure Pharma', // Header
          style: 'header',
          alignment: 'center',
        },
        { text: '\n' }, // Add some spacing
        { text: 'Order Details', style: 'subheader' },
        `Order ID: ${order.orderId}`,
        `Delivery Date: ${formatDate(order.deliveryDate)}`,
        `Status: ${order.status}`,
        {
          text: 'Medicines:',
          style: 'subheader',
        },
        order.medicines.map((medicine) => ({
          ul: [
            `Name: ${medicine.medicineName}`,
            `Manufacturer: ${medicine.manufacturerName}`,
            `Quantity Ordered: ${medicine.quantityOrdered}`,
            `Unit Price: ${medicine.unitPrice}`,
          ],
        })),
        { text: '\n' }, // Add some spacing
        { text: 'Copyright@2023 Health SurePharma', alignment: 'center' }, // Footer
      ],
      styles: {
        header: {
          fontSize: 18,
          bold: true,
        },
        subheader: {
          fontSize: 14,
          bold: true,
          margin: [0, 10, 0, 5], // top, right, bottom, left margins
        },
      },
    };

    const pdfDoc = pdfMake.createPdf(pdfContent);
    pdfDoc.download(`Invoice_Order_${selectedOrderId}.pdf`);
  };
  return (
    <div>
      <TableContainer
        component={Paper}
        style={{
          marginLeft: '16rem',
          marginTop: '100px',
          marginBottom: '20px',
          width: '80%',
        }}
      >
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Patient Name</TableCell>
              <TableCell>Order Id</TableCell>
              <TableCell>
                <TableSortLabel
                  active={orderBy === 'deliveryDate'}
                  direction={order}
                  onClick={() => handleRequestSort('deliveryDate')}
                >
                  Date of Order
                </TableSortLabel>
              </TableCell>
              <TableCell>Total Amount</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {stableSort(orders, getComparator(order, orderBy))
              .filter((patient) =>
                filterStatus
                  ? patient.orders.some(
                      (order) => order.status === filterStatus
                    )
                  : true
              )
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((patient) =>
                patient.orders.map((order) => (
                  <React.Fragment key={order.orderId}>
                    <TableRow
                      onClick={() => handleRowClick(order.orderId)}
                      style={{ cursor: 'pointer' }}
                    >
                      <TableCell>{patient.patientName}</TableCell>
                      <TableCell component="th" scope="row">
                        {order.orderId}
                      </TableCell>
                      <TableCell>
                        {formatDate(order.deliveryDate)}
                      </TableCell>
                      <TableCell>
                        {calculateTotalAmount(order.medicines)}
                      </TableCell>
                      <TableCell>
                        <IconButton
                          size="small"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleRowClick(order.orderId);
                          }}
                        >
                          {selectedOrderId === order.orderId ? (
                            <KeyboardArrowUpIcon />
                          ) : (
                            <KeyboardArrowDownIcon />
                          )}
                        </IconButton>
                      </TableCell>
                    </TableRow>
                    {selectedOrderId === order.orderId && (
                      <TableRow>
                        <TableCell colSpan={6}>
                          {/* Render details for selected order */}
                          {/* You can display the order details here */}
                          <p><strong>Order ID:</strong> {order.orderId}</p>
                          <p><strong>Delivery Date:</strong> {formatDate(order.deliveryDate)}</p>
                          <p><strong>Status:</strong> {order.status}</p>
                          <h3>Medicines:</h3>
                          <ul>
                            {order.medicines.map((medicine) => (
                              <li key={medicine.medicineId}>
                                <strong>Name:</strong> {medicine.medicineName}<br />
                                <strong>Manufacturer:</strong> {medicine.manufacturerName}<br />
                                <strong>Quantity Ordered:</strong> {medicine.quantityOrdered}<br />
                                <strong>Unit Price:</strong> {medicine.unitPrice}<br />
                              </li>
                            ))}
                          </ul>
                          <TableCell><Button variant="contained" onClick={generatePDF}>Generate Invoice</Button></TableCell>
                        </TableCell>
                       
                      </TableRow>
                    )}
                  </React.Fragment>
                ))
              )}
          </TableBody>
        </Table>
      </TableContainer>

      <TablePagination
        rowsPerPageOptions={[5, 10, 25]}
        component="div"
        count={orders.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </div>
  );
};

export default GenerateBill;
