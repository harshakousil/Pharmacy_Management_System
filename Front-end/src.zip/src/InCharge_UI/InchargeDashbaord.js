import { Route, Routes } from "react-router-dom";
import InchargeHome from "./InchargeHome";
import LoginPage from "../Registration/LoginPage";
import InchargeContent from "./InchargeContent";
import OrderTable from "./OrderDetails";
import GenerateBill from "./GenerateBill";
import { makeStyles } from "@material-ui/core";


const useStyles = makeStyles((theme) => ({

  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
    backgroundColor: '#F5F5F5'
  },
}));
const InchargeDashboard = () => {

  const classes = useStyles
    return (
      <div className={classes.content}>
            <InchargeHome></InchargeHome>
                    <Routes>
                    <Route path="/logout" element={<LoginPage></LoginPage>}></Route>
                    <Route path="/*" element={<InchargeContent></InchargeContent>}></Route>
                    <Route path="/home" element={<InchargeContent></InchargeContent>}></Route>
                    <Route path="/OrderDetails" element={<OrderTable></OrderTable>}></Route>
                    <Route path="/generatebill" element={<GenerateBill></GenerateBill>}></Route>
                    </Routes>
      </div>
    );
  };
  
  export default InchargeDashboard;
  