
import React, { useCallback, useEffect, useState } from 'react';
import { Grid, Card, CardContent, Typography, TextField, Button, Box, MenuItem, Select } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import EditIcon from '@material-ui/icons/Edit';
import DeleteIcon from '@material-ui/icons/Delete';
import axios from 'axios';
import SortIcon from '@material-ui/icons/Sort'; // Import the Sort Icon
import FilterListIcon from '@material-ui/icons/FilterList'; // Import the Filter Icon
import ReactPaginating from 'react-paginating';





const useStyles = makeStyles((theme) => ({
  mainContent: {
    marginTop: theme.spacing(8), // Adjust top margin to accommodate top nav bar
    marginLeft: theme.spacing(20), // Adjust left margin to accommodate side nav bar
    marginRight: theme.spacing(2), // Add some right margin for spacing
    [theme.breakpoints.down('md')]: {
      marginLeft: theme.spacing(2), // Adjust left margin for smaller screens
    },
  },
  card: {
    display: 'flex',
    flexDirection: 'column',
    marginBottom: theme.spacing(2),
    backgroundColor: '#ffffff', // Change background color to white
    borderRadius: theme.spacing(1), // Add rounded corners
    boxShadow: '0 2px 5px rgba(0, 0, 0, 0.1)', // Add box shadow
  },
  cardImage: {
    width: '100%', // Make the image width 100% to fit the card
    height: '150px', // Set a fixed height for the image
    objectFit: 'cover',
    borderTopLeftRadius: theme.spacing(1), // Add rounded corners to the top of the image
    borderTopRightRadius: theme.spacing(1),
  },
  cardContent: {
    flex: 1,
    padding: theme.spacing(1), // Reduce padding for content
  },
  quantityContainer: {
    display: 'flex',
    alignItems: 'center',
    marginTop: theme.spacing(1),
  },
  buttonContainer: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-around', // Corrected property name
    marginTop: theme.spacing(1), // Reduce top margin
    marginBottom: theme.spacing(1), // Reduce bottom margin
  },
  updateButton: {
    backgroundColor: '#2196f3', // Set the color to a pharmacy-related color
    color: '#ffffff', // Set the text color to white
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(3), // Add some space between buttons
  },
  deleteButton: {
    backgroundColor: '#f44336', // Set the color to a pharmacy-related color
    color: '#ffffff', // Set the text color to white
    marginRight: theme.spacing(1), // Add some space between buttons
  },
  titleField: {
    fontSize: '1rem', // Reduce font size of the title
  },
  contentField: {
    fontSize: '0.875rem', // Reduce font size of the content
  },
  redBackground: {
    backgroundColor: '#C27664', // Light red color
  },
  yellowBackground: {
    backgroundColor: '#F5EA5A', // Yellow color
  },
  greenBackground: {
    backgroundColor: '#68B984', // Green color
  },
  redBorder: {
    border: '2px solid #C27664', // Red border color
    borderRadius: theme.spacing(1), // Add rounded corners
  },
  yellowBorder: {
    border: '2px solid #F5EA5A', // Yellow border color
    borderRadius: theme.spacing(1), // Add rounded corners
  },
  greenBorder: {
    border: '2px solid #68B984', // Green border color
    borderRadius: theme.spacing(1), // Add rounded corners
  },
}));

const MainContent = () => {
  const classes = useStyles();

  const isTablet = useMediaQuery('(max-width: 1024px),(marginLeft:"0rem")');
  const isMobile = useMediaQuery('(max-width: 600px),(marginLeft:"0rem")');
  const columns = isMobile ? 1 : (isTablet ? 2 : 3);


  window.addEventListener("unload", (event) => {
    GetMedincedata();

  });
  useEffect(() => {
    GetMedincedata();
  }, []);
  const GetMedincedata = async () => {
    try {
      const Response = await axios({
        method: 'GET',
        url: 'http://localhost:9091/GetAllMedicines', // Update with your actual endpoint
        headers: { 'content-type': 'application/json' },
      });

      if (Response) {
        setCardsData(Response.data);
        console.log(Response.data)
      }
      else {
        alert("data Mismatch try Again")
      }
    } catch (error) {
      console.error('Error:', error);
    }
  }


  const [cardsData, setCardsData] = useState([]);
  console.log(cardsData);
  const getBorderColorClass = (quantity) => {
    if (quantity <= 10 ) return classes.redBorder;
    if (quantity <= 500) return classes.yellowBorder;
    if (quantity >= 500) return classes.greenBorder;
    return ''; // Default class (no additional border color)
  };

  const [firstGridData, setFirstGridData] = useState([
    { title: 'Sold Out', quantity: 0 },
    { title: 'Yet to Sold Out', quantity: 0 },
    { title: 'Fully Available', quantity: 0 },
  ]);

  // Function to update the firstGridData quantities based on cardsData
  const updateFirstGridDataQuantities = useCallback(() => {
    let soldOutCount = 0;
    let yetToSoldOutCount = 0;
    let fullyAvailableCount = 0;

    cardsData.forEach((card) => {
      const borderClass = getBorderColorClass(card.stockQuantity);
      if (borderClass === classes.redBorder) {
        soldOutCount++;
      } else if (borderClass === classes.yellowBorder) {
        yetToSoldOutCount++;
      } else if (borderClass === classes.greenBorder) {
        fullyAvailableCount++;
      }
    });

    const updatedFirstGridData = [
      { title: 'Sold Out', content: 'Less than 20', quantity: soldOutCount },
      { title: 'Yet to Sold Out', content: 'Less than 500', quantity: yetToSoldOutCount },
      { title: 'Fully Available', content: 'Greater than 500', quantity: fullyAvailableCount },
    ];

    setFirstGridData(updatedFirstGridData);
  }, [cardsData]);

  useEffect(() => {
    // Calls  updateFirstGridDataQuantities function whenever cardsData changes or whenever a card's stockQuantity changes
    updateFirstGridDataQuantities();
  }, [cardsData, updateFirstGridDataQuantities]);


  const handleRemoveCard = async (index) => {
    const updatedCardsData = [...cardsData];
    const removedCard = updatedCardsData[index];
    updatedCardsData.splice(index, 1);
    setCardsData(updatedCardsData);
    try {
      const Response = await axios({
        method: 'GET',
        url: `http://localhost:9091/deleteMedicine/${removedCard.medicineId}`,
        headers: { 'content-type': 'application/json' },
      });

      if (Response) {
        alert("Deleted Successfully");
        window.location.reload(true);
      } else {
        alert("Data Mismatch. Try Again.");
      }
    } catch (error) {
      console.error('Error:', error);
    }
  }

  const initialMedicineData = [
    {
      medicineId: '', medicineName: '', medicineDescription: '', manufacturerName: '', stockQuantity: '', unitPrice: '', expiryDate: '', image: '',
    },]
  const [medicineData, setMedicineData] = useState(initialMedicineData);
  const handleUpdateCard = (index, field, value) => {

    const updatedCardsData = [...cardsData];
    updatedCardsData[index][field] = value;
    setCardsData(updatedCardsData);

    // Update the medicineData state based on the updatedCard and initialMedicineData
    const updatedMedicineData = [...medicineData];
    const updatedCardFields = Object.keys(updatedCardsData[index]);

    for (const fieldName of updatedCardFields) {
      if (initialMedicineData[0][fieldName] !== undefined) {
        updatedMedicineData[0][fieldName] = updatedCardsData[index][fieldName];
      }

    }
    setMedicineData(updatedMedicineData);

  };

  const sendData = async (index) => {
    console.log(index);
    //console.log(medicineData[index]);
    console.log(medicineData);
    try {
      const Response = await axios({
        method: 'POST',
        url: 'http://localhost:9091/updateMedicine',
        headers: { 'content-type': 'application/json' },
        data: medicineData[0]
      });

      if (Response) {
        const updatedCards = [...cardsData];
        updatedCards[index] = Response.data;
        setCardsData(updatedCards);
        alert("Modified Successfully");
      } else {
        alert("Data Mismatch. Try Again.");
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  //Code to chnage the Image  from byte array to Normal Image
  const getBlobFromBase64 = (base64String) => {
    const binaryString = window.atob(base64String);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return new Blob([bytes], { type: 'image/jpeg' }); // Update the MIME type if needed
  };





  const [searchText, setSearchText] = useState('');
  const [sortOption, setSortOption] = useState('');
  const [filterOption, setFilterOption] = useState('');
  const [filteredCardsData, setFilteredCardsData] = useState(cardsData);
  // Function to filter cards based on search, sort, and filter options
  const filterCards = useCallback(() => {
    let filteredCards = [...cardsData];

    // Search
    if (searchText) {
      const searchLower = searchText.toLowerCase();
      filteredCards = filteredCards.filter((card) =>
        card.medicineId.toString().includes(searchLower) || card.medicineName.toLowerCase().includes(searchLower)
      );
    }
    // Sort
    if (sortOption === 'priceLowToHigh') {
      filteredCards.sort((a, b) => a.unitPrice - b.unitPrice);
    } else if (sortOption === 'priceHighToLow') {
      filteredCards.sort((a, b) => b.unitPrice - a.unitPrice);
    }

    // Filter
    if (filterOption === 'soldOut') {
      filteredCards = filteredCards.filter((card) => card.stockQuantity >= 0 && card.stockQuantity<=15);
    } else if (filterOption === 'yetToSold') {
      filteredCards = filteredCards.filter((card) => card.stockQuantity > 0 && card.stockQuantity <= 100);
    } else if (filterOption === 'fullAvailability') {
      filteredCards = filteredCards.filter((card) => card.stockQuantity >= 500);
    }

    setFilteredCardsData(filteredCards);
  }, [cardsData, searchText, sortOption, filterOption]);

  // Update filtered cards when search, sort, or filter options change
  useEffect(() => {
    filterCards();
  }, [filterCards]);

  const handleClear = () => {
    setSearchText('');
    setSortOption('');
    setFilterOption('');
    filterCards(); // Reset to show all cards
  };

  const handleGoToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const [pageNumber, setPageNumber] = useState(0);
  const cardsPerPage = 9;
  const pagesVisited = pageNumber * cardsPerPage;
  const pageCount = Math.ceil(filteredCardsData.length / cardsPerPage);

  const displayCards = filteredCardsData.slice(pagesVisited, pagesVisited + cardsPerPage);

  const changePage = ({ selected }) => {
    setPageNumber(selected);
  };

  return (
    <div className={classes.mainContent} style={{ marginTop: '80px', marginLeft: "15rem", padding: '20px' }}>
      <h3>Welcome to Admin home page</h3>

      {/* New Grid with three cards */}
      <Grid container spacing={2}>
        {firstGridData.map((card, index) => (
          <Grid item xs={12} sm={6} md={6} lg={4} key={index}>
            <Card className={`${classes.card} ${index === 0 ? classes.redBackground : index === 1 ? classes.yellowBackground : classes.greenBackground}`}>
              <CardContent className={classes.cardContent}>
                <Typography variant="h6" component="h2">
                  {card.title}
                </Typography>
                <Typography variant="body2" component="p">
                  count :{card.content}
                </Typography>
                <Typography variant="body2" component="p">
                  Quantity: {card.quantity}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

       {/* Grid that includes all features called search sort and filter  */}
       <Grid container spacing={2} alignItems="center"style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-evenly',marginBottom:'1rem',marginTop:'1rem' }}>
          <Grid item xs={12} sm={6} md={6}>
            <div style={{ display: 'flex', alignItems: 'center', }}>
              <TextField
                label="Search by Medicine Id or Medicine Name"
                variant="outlined"
                fullWidth
                value={searchText}
                onChange={(e) => setSearchText(e.target.value)}
              />

            </div>
          </Grid>
          <Grid item xs={12} sm={6} md={6}>
            <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-evenly' }}>
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <SortIcon style={{ marginRight: '8px' }} /> {/* Add the Sort Icon */}
                <Select
                  className={classes.filterSelect}
                  value={sortOption}
                  onChange={(e) => setSortOption(e.target.value)}
                  displayEmpty
                >
                  <MenuItem value="" disabled>
                    Sort By
                  </MenuItem>
                  <MenuItem value="priceLowToHigh">Price Low to High</MenuItem>
                  <MenuItem value="priceHighToLow">Price High to Low</MenuItem>
                </Select>
              </div>
              <div style={{ display: 'flex', flexDirection: 'row', marginTop: '8px' }}>
                <FilterListIcon style={{ marginRight: '8px' }} /> {/* Add the Filter Icon */}
                <Select
                  className={classes.filterSelect}
                  value={filterOption}
                  onChange={(e) => setFilterOption(e.target.value)}
                  displayEmpty
                >
                  <MenuItem value="" disabled>
                    Filter By
                  </MenuItem>
                  <MenuItem value="soldOut">Sold Out</MenuItem>
                  <MenuItem value="yetToSold">Yet to Sold</MenuItem>
                  <MenuItem value="fullAvailability">Full Availability</MenuItem>
                </Select>
              </div>
              <Button variant="contained" color="secondary" onClick={handleClear} style={{ marginTop: '8px' }}>
                Clear
              </Button>
            </div>
          </Grid>
        </Grid>
      {/* Existing Grid */}
      {/* <ReactPaginating
        previousLabel={'Previous'}
        nextLabel={'Next'}
        pageCount={pageCount}
        onPageChange={changePage}
        containerClassName={'pagination'}
        previousLinkClassName={'previous'}
        nextLinkClassName={'next'}
        disabledClassName={'disabled'}
        activeClassName={'active'}
        initialPage={pageNumber}
      /> */}
      <div style={{ maxHeight: 'calc(100vh - 200px)', overflowY: 'auto', position: 'sticky', top: '300px', zIndex: '1' }}>
      <Grid container spacing={2}>
        {filteredCardsData.map((card, index) => (
          <Grid item xs={12} sm={6} md={6} lg={Math.floor(12 / columns)} key={index}>
            <Card className={`${classes.card} ${getBorderColorClass(card.stockQuantity)}`}>
              <img src={URL.createObjectURL(getBlobFromBase64(card.image))} alt={card.medicineName} className={classes.cardImage} />
              <CardContent className={classes.cardContent}>
                <TextField
                  label="Medicine ID"
                  value={card.medicineId}
                />
                <TextField
                  label="Medicine Name"
                  value={card.medicineName}
                  onChange={(e) => handleUpdateCard(index, 'medicineName', e.target.value)}
                />
                <TextField
                  label="Description"
                  value={card.medicineDescription}
                  onChange={(e) => handleUpdateCard(index, 'medicineDescription', e.target.value)}
                />
                <TextField
                  label="Manufacturer"
                  value={card.manufacturerName}
                  onChange={(e) => handleUpdateCard(index, 'manufacturerName', e.target.value)}
                />
                <TextField
                  label="Stock Quantity"
                  value={card.stockQuantity}
                  type="number"
                  onChange={(e) => handleUpdateCard(index, 'stockQuantity', parseInt(e.target.value))}
                />
                <TextField
                  label="Unit Price"
                  value={card.unitPrice}
                  type="number"
                  onChange={(e) => handleUpdateCard(index, 'unitPrice', parseFloat(e.target.value))}
                />
              </CardContent>
              <Box className={classes.buttonContainer}>
                <div>
                  <Button
                    variant="contained"
                    color="primary"
                    startIcon={<EditIcon />}
                    className={classes.updateButton}
                    onClick={() => {
                      sendData(index);
                    }}
                  >
                    Update
                  </Button>
                  <Button
                    variant="contained"
                    color="secondary"
                    startIcon={<DeleteIcon />}
                    className={classes.deleteButton}
                    onClick={() => {
                      handleRemoveCard(index);
                    }}
                  >
                    Delete
                  </Button>
                </div>
              </Box>
            </Card>
          </Grid>
        ))}
      </Grid>

      </div>
      {/* Go to Top Button */}
      {/* <Button
     variant="contained"
     color="primary"
     onClick={handleGoToTop}
     style={{ position: 'fixed', bottom: '20px', right: '20px', zIndex: '2' }}
   >
     Go to Top
   </Button> */}
    </div>

  );
};

export default MainContent;
