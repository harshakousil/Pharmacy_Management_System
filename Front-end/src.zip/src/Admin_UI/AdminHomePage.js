import React, { useState } from 'react';
import { CssBaseline, Drawer, List, ListItem, ListItemText, ListItemIcon, Divider, IconButton, AppBar, Toolbar, InputBase, Button } from '@material-ui/core';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import { Home as HomeIcon, AddBox as AddBoxIcon, Description as DescriptionIcon, ShoppingCart as ShoppingCartIcon, Menu as MenuIcon, Search as SearchIcon } from '@material-ui/icons';
import { Link, useNavigate } from 'react-router-dom';
import MedicalServicesIcon from '@mui/icons-material/MedicalServices';
import { useLocation } from 'react-router-dom';
import { useMediaQuery } from '@material-ui/core';


const drawerWidth = 240;

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    backgroundColor: '#4CAF50', // Green background for the AppBar
  },
  logo: {
    marginRight: theme.spacing(2),
    flexGrow: 1,
  },
  search: {
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: '#FFF', // White background for the search bar
    color: 'black', // Black text in search bar
    '&:hover': {
      backgroundColor: '#FFF',
    },
    marginLeft: theme.spacing(2),
    width: 'auto',
    [theme.breakpoints.up('sm')]: {
      marginLeft: theme.spacing(3),
      width: 'auto',
    },
  },
  searchIcon: {
    padding: theme.spacing(0, 2),
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  inputRoot: {
    color: 'inherit',
  },
  inputInput: {
    padding: theme.spacing(1, 1, 1, 0),
    paddingLeft: `calc(1em + ${theme.spacing(4)}px)`,
    transition: theme.transitions.create('width'),
    width: '100%',
    [theme.breakpoints.up('sm')]: {
      width: '20ch', // Increased search bar size
      '&:focus': {
        width: '25ch', // Increased search bar size on focus
      },
    },
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
  },
  drawerPaper: {
    width: drawerWidth,
  },
  drawerContainer: {
    overflow: 'auto',
  },
  menuButton: {
    marginRight: theme.spacing(2),
    [theme.breakpoints.up('md')]: {
      display: 'none',
    },
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
  },
  drawerContent: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'left',
  },
  listItemIcon: {
    color: '#4CAF50', // Green color for the icons
  },
}));

const AdminHomePage = () => {
  
  const classes = useStyles();
  const theme = useTheme();
  const [mobileOpen, setMobileOpen] = useState(false);
  const isTabletOrLarger = useMediaQuery(theme.breakpoints.up('md'));
 const navigate=useNavigate();
  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };
  const handlelogout = () => {
  
    sessionStorage.removeItem("roleName");
    navigate("/")
  }

  // Get the current location from react-router-dom
  const location = useLocation();

  return (
    <div className={classes.root}>
      <CssBaseline />
      <AppBar position="fixed" className={classes.appBar}>
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            className={classes.menuButton}
          >
            <MenuIcon />
          </IconButton>
          <div className={classes.logo}>
            <h2>Health Sure Pharamcy</h2>
          </div>
          <div >
            <div>
              <Button  style={{ backgroundColor: 'white', color: 'black' }} onClick={handlelogout} >Logout </Button>
             
            </div>
          </div>
        </Toolbar>
      </AppBar>
      <nav>
        {isTabletOrLarger ? (
          <Drawer
            className={classes.drawer}
            variant="permanent"
            classes={{
              paper: classes.drawerPaper,
            }}
            open
          >
            <Toolbar />
            <div className={classes.drawerContainer}>
              <div className={classes.drawerContent}>
                <List>
                  <ListItem
                    button
                    component={Link}
                    to="/home"
                    selected={location.pathname === '/home'} // Check if the current location matches the route path
                  >
                    <ListItemIcon className={classes.listItemIcon}>
                      <HomeIcon />
                    </ListItemIcon>
                    <ListItemText primary="Home" />
                  </ListItem>
                  <ListItem
                    button
                    component={Link}
                    to="/Addscheme"
                    selected={location.pathname === '/Addscheme'} // Check if the current location matches the route path
                  >
                    <ListItemIcon className={classes.listItemIcon}>
                      <AddBoxIcon />
                    </ListItemIcon>
                    <ListItemText primary="Add New Scheme" />
                  </ListItem>
                  <ListItem
                    button
                    component={Link}
                    to="/generatereport"
                    selected={location.pathname === '/generatereport'} // Check if the current location matches the route path
                  >
                    <ListItemIcon className={classes.listItemIcon}>
                      <DescriptionIcon />
                    </ListItemIcon>
                    <ListItemText primary="Generate Reports" />
                  </ListItem>
                  <ListItem
                    button
                    component={Link}
                    to="/AddMedicine"
                    selected={location.pathname === '/AddMedicine'} // Check if the current location matches the route path
                  >
                    <ListItemIcon className={classes.listItemIcon}>
                      <MedicalServicesIcon  />
                    </ListItemIcon>
                    <ListItemText primary="Add New Medicine" />
                  </ListItem>
                  <ListItem
                    button
                    component={Link}
                    to="/OrderMedicines"
                    selected={location.pathname === '/OrderMedicines'} // Check if the current location matches the route path
                  >
                    <ListItemIcon className={classes.listItemIcon}>
                      <ShoppingCartIcon />
                    </ListItemIcon>
                    <ListItemText primary="Order New Medicines" />
                  </ListItem>
                </List>
                <Divider />
              </div>
            </div>
          </Drawer>
        ) : (
          <Drawer
            className={classes.drawer}
            variant="temporary"
            classes={{
              paper: classes.drawerPaper,
            }}
            open={mobileOpen}
            onClose={handleDrawerToggle}
          >
            <Toolbar />
            <div className={classes.drawerContainer}>
              <div className={classes.drawerContent}>
                <List>
                  <ListItem
                    button
                    component={Link}
                    to="/home"
                    selected={location.pathname === '/home'} // Check if the current location matches the route path
                  >
                    <ListItemIcon className={classes.listItemIcon}>
                      <HomeIcon />
                    </ListItemIcon>
                    <ListItemText primary="Home" />
                  </ListItem>
                  <ListItem
                    button
                    component={Link}
                    to="/Addscheme"
                    selected={location.pathname === '/Addscheme'} // Check if the current location matches the route path
                  >
                    <ListItemIcon className={classes.listItemIcon}>
                      <AddBoxIcon />
                    </ListItemIcon>
                    <ListItemText primary="Add New Scheme" />
                  </ListItem>
                  <ListItem
                    button
                    component={Link}
                    to="/generatereport"
                    selected={location.pathname === '/generatereport'} // Check if the current location matches the route path
                  >
                    <ListItemIcon className={classes.listItemIcon}>
                      <DescriptionIcon />
                    </ListItemIcon>
                    <ListItemText primary="Generate Reports" />
                  </ListItem>
                  <ListItem
                    button
                    component={Link}
                    to="/OrderMedicines"
                    selected={location.pathname === '/OrderMedicines'} // Check if the current location matches the route path
                  >
                    <ListItemIcon className={classes.listItemIcon}>
                      <ShoppingCartIcon />
                    </ListItemIcon>
                    <ListItemText primary="Order New Medicines" />
                  </ListItem>
                </List>
                <Divider />
              </div>
            </div>
          </Drawer>
        )}
      </nav>
    </div>
  );
};

export default AdminHomePage;
