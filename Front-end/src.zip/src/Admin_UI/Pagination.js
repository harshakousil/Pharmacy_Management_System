import React from 'react';
import { Button, ButtonGroup } from '@material-ui/core';

const CustomPagination = ({ pageCount, currentPage, onPageChange }) => {
  const handlePageChange = (newPage) => {
    onPageChange(newPage);
  };

  const renderPageNumbers = () => {
    const pageNumbers = [];
    for (let i = 0; i < pageCount; i++) {
      pageNumbers.push(
        <Button
          key={i}
          variant={i === currentPage ? 'contained' : 'outlined'}
          color="primary"
          onClick={() => handlePageChange(i)}
        >
          {i + 1}
        </Button>
      );
    }
    return pageNumbers;
  };

  return (
    <ButtonGroup>
      <Button
        color="primary"
        onClick={() => handlePageChange(currentPage - 1)}
        disabled={currentPage === 0}
      >
        Previous
      </Button>
      {renderPageNumbers()}
      <Button
        color="primary"
        onClick={() => handlePageChange(currentPage + 1)}
        disabled={currentPage === pageCount - 1}
      >
        Next
      </Button>
    </ButtonGroup>
  );
};

export default CustomPagination;
