
import React, { useState } from 'react';
import { TextField, Button, FormControl } from '@mui/material';
import axios from 'axios';
import { IconButton, Snackbar } from '@material-ui/core';
import SearchIcon from '@mui/icons-material/Search';
import MuiAlert from '@mui/material/Alert';

const AddMedicine = () => {
    const [isInfoSnackbarOpen, setIsInfoSnackbarOpen] = React.useState(false);

    const [infoSnackbarMessage, setInfoSnackbarMessage] = React.useState('');

    const [isSnackbarOpen, setIsSnackbarOpen] = React.useState(false);

    const [SnackbarMessage, setSnackbarMessage] = React.useState('');

    const [isSuccessSnackbarOpen, setSuccessSnackbarOpen] = React.useState(false);

    const [successSnackbarMessage, setSuccessSnackbarMessage] = React.useState('');

    const [fieldsDisabled, setFieldsDisabled] = useState(true);
    const [formData, setFormData] = useState({
        medicineId: '',
        medicineName: '',
        medicineDescription: '',
        manufacturerName: '',
        stockQuantity: '',
        unitPrice: '',
        expiryDate: '',
        isAvailable: false,
        image: null,
    });

    const [errors, setErrors] = useState({
        medicineId: '',
        medicineName: '',
        medicineDescription: '',
        manufacturerName: '',
        stockQuantity: '',
        unitPrice: '',
        expiryDate: '',
        image: '',
    });

    const handleSnackbarClose = () => {

        setIsSnackbarOpen(false);
        // setIsInfoSnackbarOpen(false)

    };
    const handleSnackbarClosed = () => {

        setIsInfoSnackbarOpen(false)

    };
    const handleSuccessSnackbarClosed = () => {

        setSuccessSnackbarOpen(false)
        window.location.reload(true);

    };
    // Initially, all fields are disabled.

    const handleChange = (e) => {
        const { name, value, type, files } = e.target;

        if (type === 'file') {
            setFormData((prevFormData) => ({
                ...prevFormData,
                [name]: files[0],
            }));
        } else {
            setFormData((prevFormData) => ({
                ...prevFormData,
                [name]: value,
            }));
        }

        setErrors((prevErrors) => ({
            ...prevErrors,
            [name]: '',
        }));
    };

    const handleMedicineSearch = async () => {
        if (formData.medicineId.trim() === '') {
            //alert("Please enter the medicine id");
            setSnackbarMessage("Please enter the medicine id")
            setIsSnackbarOpen(true)
            return;
        }

        try {
            var medicineId = formData.medicineId;
            const response = await axios.get(`http://localhost:9091/findmedicine/${medicineId}`);

            if (response.data) {
                // alert("Medicine Already Exists");
                setInfoSnackbarMessage("Medicine Already Exists")
                setIsInfoSnackbarOpen(true)
                return;
            } else {
                alert('No Medicine Id Found, Continue to Add');
                setFieldsDisabled(false);
            }
        } catch (error) {
            console.error('Error:', error);
        }
    };

    const handleSubmit = async (base64Image) => {
        let formValid = true;
        const newErrors = {
            medicineId: '',
            medicineName: '',
            medicineDescription: '',
            manufacturerName: '',
            stockQuantity: '',
            unitPrice: '',
            expiryDate: '',
            image: '',
        };

        if (formData.medicineId.trim() === '') {
            newErrors.medicineId = 'Medicine ID is required';
            formValid = false;
        }

        if (formData.medicineName.trim() === '') {
            newErrors.medicineName = 'Medicine Name is required';
            formValid = false;
        }

        if (formData.medicineDescription.trim() === '') {
            newErrors.medicineDescription = 'Medicine Description is required';
            formValid = false;
        }

        if (formData.manufacturerName.trim() === '') {
            newErrors.manufacturerName = 'Manufacturer Name is required';
            formValid = false;
        }

        if (formData.stockQuantity.trim() === '') {
            newErrors.stockQuantity = 'Stock Quantity is required';
            formValid = false;
        }

        if (formData.unitPrice.trim() === '') {
            newErrors.unitPrice = 'Unit Price is required';
            formValid = false;
        }

        if (formData.expiryDate === '') {
            newErrors.expiryDate = 'Expiry Date is required';
            formValid = false;
        }

        if (!formData.image) {
            newErrors.image = 'Image is required';
            formValid = false;
        }

        setErrors(newErrors);

        if (formValid) {
            // Code to change the Image to Base64URL
            if (formData.image) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    const base64Image = e.target.result.split(',')[1];
                    sendData(base64Image); // Call the function to send data
                };
                reader.readAsDataURL(formData.image); // Read the image as Base64
            } else {
                sendData(null); // Call the function to send data without image
            }

            const sendData = async (base64Image) => {
                try {
                    const Response = await axios({
                        method: 'POST',
                        url: 'http://localhost:9091/addMedicine',
                        headers: { 'content-type': 'application/json' },
                        data: {
                            ...formData,
                            image: base64Image, // Add Base64 encoded image
                        },
                    });

                    if (Response) {
                        //alert("Medicine Added Successfully");
                        setSuccessSnackbarMessage("Medicine Added Successfully")
                        setSuccessSnackbarOpen(true)
                        
                    } else {
                        alert("Data Mismatch, Try Again");
                    }
                } catch (error) {
                    console.error('Error:', error);
                }
            };
        }
    };

    const handleReset = () => {
        setFormData({
            medicineId: '',
            medicineName: '',
            medicineDescription: '',
            manufacturerName: '',
            stockQuantity: '',
            unitPrice: '',
            expiryDate: '',
            isAvailable: false,
            image: null,
        });
        setErrors({
            medicineId: '',
            medicineName: '',
            medicineDescription: '',
            manufacturerName: '',
            stockQuantity: '',
            unitPrice: '',
            expiryDate: '',
            image: '',
        });
    };

    return (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', marginTop: "200px" }}>
            <div style={{ padding: '80px', border: '1px solid #ccc', width: '50%' }}>
                <div style={{ marginBottom: '20px', display: 'flex', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                    <FormControl variant="outlined" style={{ width: '70%' }}>
                        <TextField
                            id="medicineId"
                            name="medicineId"
                            value={formData.medicineId}
                            onChange={handleChange}
                            variant="outlined"
                            label="Medicine ID"
                            error={!!errors.medicineId}
                            helperText={errors.medicineId}
                        />
                    </FormControl>
                    <Button variant="contained" color="primary" onClick={handleMedicineSearch} style={{ backgroundColor: '#4CAF50' }}>
                        <SearchIcon />Search
                    </Button>
                </div>
                <div style={{ marginBottom: '20px' }}>
                    <FormControl fullWidth variant="outlined">
                        <TextField
                            id="medicineName"
                            name="medicineName"
                            value={formData.medicineName}
                            onChange={handleChange}
                            variant="outlined"
                            label="Medicine Name"
                            error={!!errors.medicineName}
                            helperText={errors.medicineName}
                            disabled={fieldsDisabled}
                        />
                    </FormControl>
                </div>
                <div style={{ marginBottom: '20px' }}>
                    <FormControl fullWidth variant="outlined">
                        <TextField
                            id="medicineDescription"
                            name="medicineDescription"
                            value={formData.medicineDescription}
                            onChange={handleChange}
                            variant="outlined"
                            label="Medicine Description"
                            error={!!errors.medicineDescription}
                            helperText={errors.medicineDescription}
                            disabled={fieldsDisabled}
                        />
                    </FormControl>
                </div>
                <div style={{ marginBottom: '20px' }}>
                    <FormControl fullWidth variant="outlined">
                        <TextField
                            id="manufacturerName"
                            name="manufacturerName"
                            value={formData.manufacturerName}
                            onChange={handleChange}
                            variant="outlined"
                            label="Manufacturer Name"
                            error={!!errors.manufacturerName}
                            helperText={errors.manufacturerName}
                            disabled={fieldsDisabled}
                        />
                    </FormControl>
                </div>
                <div style={{ marginBottom: '20px' }}>
                    <FormControl fullWidth variant="outlined">
                        <TextField
                            id="stockQuantity"
                            name="stockQuantity"
                            value={formData.stockQuantity}
                            onChange={handleChange}
                            variant="outlined"
                            label="Stock Quantity"
                            error={!!errors.stockQuantity}
                            helperText={errors.stockQuantity}
                            disabled={fieldsDisabled} // Invert the disabled state
                            inputProps={{ min: 1 }} // Set the minimum value to 1
                        />
                    </FormControl>
                </div>
                <div style={{ marginBottom: '20px' }}>
                    <FormControl fullWidth variant="outlined">
                        <TextField
                            id="unitPrice"
                            name="unitPrice"
                            value={formData.unitPrice}
                            onChange={handleChange}
                            variant="outlined"
                            label="Unit Price"
                            error={!!errors.unitPrice}
                            helperText={errors.unitPrice}
                            disabled={fieldsDisabled}
                        />
                    </FormControl>
                </div>
                <div style={{ marginBottom: '20px' }}>
                    <FormControl fullWidth variant="outlined">
                        <TextField
                            id="expiryDate"
                            name="expiryDate"
                            type="date"
                            value={formData.expiryDate}
                            onChange={handleChange}
                            variant="outlined"
                            label="Expiry Date"
                            InputLabelProps={{
                                shrink: true,
                            }}
                            error={!!errors.expiryDate}
                            helperText={errors.expiryDate}
                            disabled={fieldsDisabled}
                        />
                    </FormControl>
                </div>
                <div style={{ marginBottom: '20px' }}>
                    <FormControl fullWidth variant="outlined">
                        <TextField
                            id="image"
                            name="image"
                            type="file"
                            accept="image/*"
                            onChange={handleChange}
                            variant="outlined"
                            label="Image"
                            error={!!errors.image}
                            helperText={errors.image}
                            disabled={fieldsDisabled}
                        />
                    </FormControl>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Button variant="contained" color="secondary" onClick={handleReset}>
                        Reset
                    </Button>
                    <Button variant="contained" color="primary" onClick={handleSubmit} disabled={fieldsDisabled}>
                        Submit
                    </Button>
                </div>
            </div>
            <Snackbar

                open={isSnackbarOpen}

                autoHideDuration={3000}

                onClose={handleSnackbarClose}

                anchorOrigin={{ vertical: 'top', horizontal: 'right' }}

            >

                <MuiAlert onClose={handleSnackbarClose} severity="info" sx={{ width: '100%' }}>

                    {SnackbarMessage}

                </MuiAlert>

            </Snackbar>

            <Snackbar

                open={isInfoSnackbarOpen}

                autoHideDuration={3000}

                onClose={handleSnackbarClosed}

                anchorOrigin={{ vertical: 'top', horizontal: 'right' }}

            >

                <MuiAlert onClose={handleSnackbarClosed} severity="warning" sx={{ width: '100%' }}>

                    {infoSnackbarMessage}

                </MuiAlert>

            </Snackbar>
            <Snackbar

                open={isSuccessSnackbarOpen}

                autoHideDuration={3000}

                onClose={handleSuccessSnackbarClosed}

                anchorOrigin={{ vertical: 'top', horizontal: 'right' }}

            >

                <MuiAlert onClose={handleSuccessSnackbarClosed} severity="success" sx={{ width: '100%' }}>

                    {successSnackbarMessage}

                </MuiAlert>

            </Snackbar>
        </div>

    );
};

export default AddMedicine;
