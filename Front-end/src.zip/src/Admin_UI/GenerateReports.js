
import React, { useState, useEffect, useMemo } from 'react';
import axios from 'axios';
import { MaterialReactTable } from 'material-react-table';
import { Button,  } from '@mui/material';
import jsPDF from 'jspdf';
import { styled } from '@material-ui/core';

const ReportTable = () => {
  const [data, setResponseData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [rowSelection, setRowSelection] = useState({});

  const PharmaButton = styled(Button)(({ theme }) => ({
    color: theme.palette.getContrastText('#007bff'),
    backgroundColor: '#007bff',
    '&:hover': {
      backgroundColor: '#0056b3',
    },
  }));

  useEffect(() => {
    try {
      axios({
        method: 'GET',
        url: 'http://localhost:9093/findAllOrders/',
        headers: { 'content-type': 'application/json' },
      })
        .then((response) => {
          console.log(response.data);
          setResponseData(response.data);
          setLoading(false);
        })
        .catch((error) => {
          console.error('Error:', error);
          alert('Server Issue');
          setLoading(false);
        });
    } catch (error) {
      console.error('Error:', error);
      alert('Server Issue');
      setLoading(false);
    }
  }, []);

  // const handleDownloadPdf = (row) => {
  //   const pdfContent = `
  //     <html>
  //       <head>
  //         <style>
  //           body {
  //             font-family: Arial, sans-serif;
  //           }
  //           .header {
  //             text-align: center;
  //             font-size: 20px;
  //             font-weight: bold;
  //             margin-bottom: 20px;
  //           }
  //           .info {
  //             border: 1px solid #ccc;
  //             padding: 10px;
  //             margin-bottom: 10px;
  //           }
  //           .footer {
  //             text-align: center;
  //             margin-top: 20px;
  //             font-size: 12px;
  //           }
  //         </style>
  //       </head>
  //       <body>
  //         <div class="header">Health Sure Pharma</div>
  //         <div class="info">
  //           <h6><strong>Medicine Name:</strong> ${row.medicineName}</h6>
  //           <h6><strong>Retailer Name:</strong> ${row.retailerName}</h6>
  //           <h6><strong>Date of Order:</strong> ${row.orderDate}</h6>
  //           <h6><strong>Date of Delivery:</strong> ${row.deliveryDate}</h6>
  //           <h6><strong>Quantity:</strong> ${row.quantity}</h6>
  //         </div>
  //         <div class="footer">Copyright @2023 Health Sure Pharma</div>
  //       </body>
  //     </html>
  //   `;
  
  //   const generatePDF = (htmlContent) => {
  //     const doc = new jsPDF();
  //     doc.html(htmlContent, {
  //       callback: function (doc) {
  //         doc.save('receipt.pdf');
  //       },
  //       x: 5,
  //       y: 5,
  //     });
  //   };
  //   generatePDF(pdfContent);
  // };
  const handleDownloadSelected = () => {
    const selectedRowsData = [];

    for (let i = 0; i < data.length; i++) {
      if (rowSelection[i]) {
        selectedRowsData.push(data[i]);
      }
    }

    if (selectedRowsData.length === 0) {
      alert("Please Select at Least One Order to Proceed");
      return;
    }

    const pdf = new jsPDF();
    pdf.setFontSize(14);
    pdf.text("Health Sure Pharma - Receipts", 10, 10);

    let y = 30;
    selectedRowsData.forEach((row) => {
      pdf.setFontSize(12);
      pdf.text(`Medicine Name: ${row.medicineName}`, 10, y);
      pdf.text(`Retailer Name: ${row.retailerName}`, 10, y + 10);
      pdf.text(`Date of Order: ${row.orderDate}`, 10, y + 20);
      pdf.text(`Delivery Address: ${row.deliveryAddress}`, 10, y + 30);
      pdf.text(`Quantity: ${row.quantity}`, 10, y + 40);
      pdf.addPage(); // Add a new page for each receipt
      y = 10; // Reset the Y position for the next receipt
    });

    pdf.save('receipts.pdf');
  };
  const columns = useMemo(
    () => [
      {
        accessorKey: 'medicineName',
        header: 'Medicine Name',
      },
      {
        accessorKey: 'retailerName',
        header: 'Retailer Name',
      },
      {
        accessorKey: 'orderDate',
        header: 'Date of Order',
      },
      {
        accessorKey: 'deliveryAddress',
        header: 'Delivery Address',
      },
      {
        accessorKey: 'quantity',
        header: 'Quantity',
      },
    ],
    []
  );


  // const handleDownloadSelected = () => {
  //   const selectedRowsData = [];

  //   for (let i = 0; i < data.length; i++) {
  //     if (rowSelection[i]) {
  //       handleDownloadPdf(data[i])
  //       selectedRowsData.push(data[i]);
  //     }
  //     else{
  //       alert("Please Select an Order to proceed")
  //       return
  //     }
  //   }

  //   console.log(selectedRowsData);


  // };

  return (
    <div
      style={{
        marginTop: '70px',
        marginLeft: '260px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        padding: '20px',
      }}
    >
      {loading ? (
        <h2>Loading...</h2>
      ) : (
        <>
          <MaterialReactTable
            columns={columns}
            data={data}

            enableRowSelection
            onRowSelectionChange={setRowSelection}
            enableStickyHeader
            state={{ rowSelection }}
            muiTableContainerProps={{ sx: { maxHeight: '300px' } }}
          // getRowId={(row) => row.medicineName}
          // onRowSelectionChange={handleRowSelectionChange}
          />
         <Button sx={{marginTop:'2rem'}} variant="contained" color="primary" onClick={handleDownloadSelected}>
    Download Receipt
  </Button>
        </>
      )}
    </div>
  );
};

export default ReportTable;



