

import React, { useState } from 'react';
import { TextField, Button, FormControl, InputLabel, Select, MenuItem } from '@mui/material';
import axios from 'axios';

const AddScheme = () => {
  const [formData, setFormData] = useState({
    inputField: '',
    selectField: 'Default',
    dateField1: '',
    dateField2: '',
  });

  const [errors, setErrors] = useState({
    inputField: '',
    dateField1: '',
    dateField2: '',
    dynamicField: '',
  });

  const [dynamicField, setDynamicField] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === 'selectField') {
      setDynamicField('');
    }
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: value,
    }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [name]: '',
    }));
  };

  const handleSubmit = async () => {
    let formValid = true;
    const newErrors = {
      inputField: '',
      dateField1: '',
      dateField2: '',
      dynamicField: '',
    };

    if (formData.inputField.trim() === '') {
      newErrors.inputField = 'Input Field is required';
      formValid = false;
    }

    if (formData.dateField1 === '') {
      newErrors.dateField1 = 'Date Field 1 is required';
      formValid = false;
    }

    if (formData.dateField2 === '') {
      newErrors.dateField2 = 'Date Field 2 is required';
      formValid = false;
    }

    if (formData.selectField === '%Based' && dynamicField.trim() === '') {
      newErrors.dynamicField = '% Based Value is required';
      formValid = false;
    }

    if (formData.selectField === 'Flat' && dynamicField === '') {
      newErrors.dynamicField = 'Flat Option is required';
      formValid = false;
    }

    setErrors(newErrors);

    if (formValid) {

      const postData = {
        schemeName: formData.inputField,
        schemeType: formData.selectField,
        schemeValue: dynamicField, // Add dynamic field to the data
        fromDate: formData.dateField1,
        toDate: formData.dateField2,
      };
      console.log(postData)
      try {
        const Response = await axios({
          method: 'POST',
          url: 'http://localhost:9091/addscheme',// Update with your actual endpoint
          headers: { 'content-type': 'application/json' },
          data: postData
        });

        if (Response) {
          alert("Medicine Added Sucessfully");
        }
        else {
          alert("data Mismatch try Again")
        }
      } catch (error) {
        console.error('Error:', error);
      }
    }
  };

  const handleReset = () => {
    setFormData({
      inputField: '',
      selectField: 'Default',
      dateField1: '',
      dateField2: '',
    });
    setErrors({
      inputField: '',
      dateField1: '',
      dateField2: '',
      dynamicField: '',
    });
    setDynamicField('');
  };

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', marginTop: '70px' }}>
      <div style={{ padding: '80px', border: '1px solid #ccc', width: '50%' }}>
        <div style={{ marginBottom: '20px' }}>
          <FormControl fullWidth variant="outlined">
            <TextField
              id="inputField"
              name="inputField"
              value={formData.inputField}
              onChange={handleChange}
              variant="outlined"
              label="Scheme Name"
              error={!!errors.inputField}
              helperText={errors.inputField}
            />
          </FormControl>
        </div>
        <div style={{ marginBottom: '20px' }}>
          <FormControl fullWidth variant="outlined">
            <InputLabel htmlFor="ApplicableTo">SchemeType</InputLabel>
            <Select
              id="selectField"
              name="selectField"
              value={formData.selectField}
              onChange={handleChange}
              label="Scheme Type"
            >
              <MenuItem value="Default">Choose Option</MenuItem>
              <MenuItem value="%Based">% Based Discount</MenuItem>
            </Select>
          </FormControl>
        </div>
        {formData.selectField === '%Based' && (
          <div style={{ marginBottom: '20px' }}>
            <FormControl fullWidth variant="outlined">
              <TextField
                id="dynamicField"
                name="dynamicField"
                value={dynamicField}
                onChange={(e) => setDynamicField(e.target.value)}
                variant="outlined"
                label="% Percentage Value"
                error={!!errors.dynamicField}
                helperText={errors.dynamicField}
              />
            </FormControl>
          </div>
        )}
        {formData.selectField === 'Flat' && (
          <div style={{ marginBottom: '20px' }}>
            <FormControl fullWidth variant="outlined">
              <InputLabel htmlFor="flatOption">Flat Option</InputLabel>
              <Select
                id="flatOption"
                name="flatOption"
                value={dynamicField}
                onChange={(e) => setDynamicField(e.target.value)}
                label="Flat Option"
              >
                <MenuItem value="Medicines Quantity >75000">40% Discount Medicines Quantity &gt; 75000</MenuItem>
                <MenuItem value="Medicines Quantity >100000"> 40% Discount Medicines Quantity &gt; 100000</MenuItem>
              </Select>
            </FormControl>
          </div>
        )}
        <div style={{ marginBottom: '20px' }}>
          <FormControl fullWidth variant="outlined">
            <TextField
              id="dateField1"
              name="dateField1"
              type="date"
              value={formData.dateField1}
              onChange={handleChange}
              variant="outlined"
              label="Start Date"
              InputLabelProps={{
                shrink: true,
              }}
              error={!!errors.dateField1}
              helperText={errors.dateField1}
            />
          </FormControl>
        </div>
        <div style={{ marginBottom: '20px' }}>
          <FormControl fullWidth variant="outlined">
            <TextField
              id="dateField2"
              name="dateField2"
              type="date"
              value={formData.dateField2}
              onChange={handleChange}
              variant="outlined"
              label="End  Date"
              InputLabelProps={{
                shrink: true,
              }}
              error={!!errors.dateField2}
              helperText={errors.dateField2}
            />
          </FormControl>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <Button variant="contained" color="secondary" onClick={handleReset}>
            Reset
          </Button>
          <Button variant="contained" color="primary" onClick={handleSubmit}>
            Submit
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AddScheme;

