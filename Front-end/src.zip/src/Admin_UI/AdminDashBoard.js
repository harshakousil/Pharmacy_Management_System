import React from "react";
import { Route, Routes } from "react-router-dom";

import LoginPage from "../Registration/LoginPage";
import AddScheme from "./AddNewScheme";
import ReportTable from "./GenerateReports";
import OrderMedicine from "./OrderMedicines";
import MainContent from "./AdminContent";
import AddMedicine from "./AddMedicine";
import AdminHomePage from "./AdminHomePage";

const AdminDashboard = () => {
  return (
    <div>
<AdminHomePage></AdminHomePage>
    <Routes>
      <Route path="/logout" element={<LoginPage />} />
      <Route path="/*" element={<MainContent />} />
      <Route path="/home" element={<MainContent />} />
      <Route path="/Addscheme" element={<AddScheme />} />
      <Route path="/AddMedicine" element={<AddMedicine />} />
      <Route path="/generatereport" element={<ReportTable />} />
      <Route path="/OrderMedicines" element={<OrderMedicine />} />
    </Routes>
    </div>
  );
};

export default AdminDashboard;
