import React, { useState } from 'react';
import { TextField, Button, FormControl, } from '@mui/material';
import axios from 'axios';
import { TextareaAutosize } from '@material-ui/core';

const OrderMedicine = () => {
  const [formData, setFormData] = useState({
    status: 'Processing',
    medicineName: '',
    Quantity: '',
    retailerName: '',
    deliveryAddress: '',
    strengthOrDosage: '', 
    instructions: '', 
  });
  
  const [errors, setErrors] = useState({
    medicineName: '',
    Quantity: '',
    retailerName: '',
    deliveryAddress: '',
    strengthOrDosage: '', 
    instructions: '', 
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: value,
    }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [name]: '',
    }));
  };

  const handleSubmit = async () => {
    let formValid = true;
    const newErrors = {
      medicineName: '',
      Quantity: '',
      retailerName: '',
      deliveryAddress: '',
    };

    if (formData.medicineName.trim() === '') {
      newErrors.medicineName = 'Medicine Name is required';
      formValid = false;
    }

    if (formData.Quantity.trim() === '') {
      newErrors.Quantity = 'Quantity is required';
      formValid = false;
    }

    if (formData.retailerName.trim() === '') {
      newErrors.retailerName = 'Retailer Name is required';
      formValid = false;
    }

    if (formData.deliveryAddress.trim()==='') {
      newErrors.deliveryAddress = 'Delivery address is required';
      formValid = false;
    }

    setErrors(newErrors);

    if (formValid) {
      // You can perform form submission logic here

      try {
        console.log(formData.Quantity);
        const Response = await axios({
          method: 'POST',
          url: `http://localhost:9093/placenewOrder/${formData.Quantity}`, // Update with your actual endpoint
          headers: { 'content-type': 'application/json' },
          data: formData
        });

        if (Response) {
          alert("Medicine Ordered Sucessfully");
        }
        else {
          alert("data Mismatch try Again")
        }
      } catch (error) {
        console.error('Error:', error);
        alert("Server Issue")
      }

      console.log(formData);
      window.location.reload(true);
    }
  };

  const handleReset = () => {
    setFormData({
      medicineName: '',
      Quantity: '',
      retailerName: '',
      deliveryAddress: '',
    });
    setErrors({
      medicineName: '',
      Quantity: '',
      retailerName: '',
      deliveryAddress: '',
    });
  };

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', marginTop: "100px" }}>
      <div style={{ padding: '80px', border: '1px solid #ccc', width: '50%' }}>
        <div style={{ marginBottom: '20px' }}>
          <h2>Order Medicine</h2>
          <FormControl fullWidth variant="outlined">
            <TextField
              id="medicineName"
              name="medicineName"
              value={formData.medicineName}
              onChange={handleChange}
              variant="outlined"
              label="Medicine Name"
              error={!!errors.medicineName}
              helperText={errors.medicineName}
            />
          </FormControl>
        </div>
        <div style={{ marginBottom: '20px' }}>
          <FormControl fullWidth variant="outlined">
            <TextField
              id="strengthOrDosage"
              name="strengthOrDosage"
              value={formData.strengthOrDosage}
              onChange={handleChange}
              variant="outlined"
              label="Strength or Dosage (Optional)"
              error={!!errors.strengthOrDosage}
              helperText={errors.strengthOrDosage}
            />
          </FormControl>
        </div>
        <div style={{ marginBottom: '20px' }}>
          <FormControl fullWidth variant="outlined">
            <TextField
              id="Quantity"
              name="Quantity"
              value={formData.Quantity}
              onChange={handleChange}
              variant="outlined"
              label="Quantity"
              error={!!errors.Quantity}
              helperText={errors.Quantity}
            />
          </FormControl>
        </div>
        <div style={{ marginBottom: '20px' }}>
          <FormControl fullWidth variant="outlined">
            <TextField
              id="retailerName"
              name="retailerName"
              value={formData.retailerName}
              onChange={handleChange}
              variant="outlined"
              label="Retailer Name"
              error={!!errors.retailerName}
              helperText={errors.retailerName}
            />
          </FormControl>
        </div>

        <div style={{ marginBottom: '20px' }}>
          <FormControl fullWidth variant="outlined">
            <TextareaAutosize
              id="Delivery Address"
              name="deliveryAddress" // Make sure the name matches the formData property
              value={formData.deliveryAddress}
              onChange={handleChange}
              aria-label="minimum height"
              minRows={4} 
              placeholder="Delivery Address"
              style={{
                width: '100%', 
                resize: 'none', 
              }}
              error={!!errors.deliveryAddress}
              helperText={errors.deliveryAddress}
            />
          </FormControl>
        </div>
        <div style={{ marginBottom: '20px' }}>
          <FormControl fullWidth variant="outlined">
            <TextField
              id="instructions"
              name="instructions"
              value={formData.instructions}
              onChange={handleChange}
              variant="outlined"
              label="Instructions (Optional)"
              error={!!errors.instructions}
              helperText={errors.instructions}
            />
          </FormControl>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <Button variant="contained" color="secondary" onClick={handleReset}>
            Reset
          </Button>
          <Button variant="contained" color="primary" onClick={handleSubmit}>
            Submit
          </Button>
        </div>
      </div>
    </div>
  );
};

export default OrderMedicine;
