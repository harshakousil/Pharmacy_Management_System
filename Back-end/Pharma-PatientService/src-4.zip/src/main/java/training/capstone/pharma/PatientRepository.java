package training.capstone.pharma;



import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface PatientRepository extends MongoRepository<PatientEO, String> {
	
//	Named query Find User by email 
	@Query("{ '_id' : ?0 }") 
    PatientEO findByEmail(String email);
	
	
	// Named Query to add a patient
    @SuppressWarnings("unchecked")
	PatientEO save(PatientEO patient);
    
   

    // Named Query to add Orders in PatientEO
    @Query(value = "{ '_id': ?0 }")
    PatientEO findPatientWithOrdersById(String email);

    // Named Query to change the "Status" of Order to other value
    @Query(value = "{ 'orders._id': ?0 }", fields = "{ 'orders.$': 1 }")
    OrderEO findOrderById(int orderId);

    
    //Find all Patients
    //List<PatientEO> findAllPatients();
    
    
    @Query(value = "{'patientId': ?0}, {'orders': { $slice: -1 }, 'orders.id': 1}")
    PatientEO findLastOrderIdByPatientId(String patientId);
    
    // Update the status of the order using the received OrderEO object
//    @Query(value = "{ '_id': ?0, 'orders._id': ?1 }",update = "{ '$set': { 'orders.$.status': ?2 } }")
//    void updateOrderStatus(String patientId, String orderId, String newStatus);
}

