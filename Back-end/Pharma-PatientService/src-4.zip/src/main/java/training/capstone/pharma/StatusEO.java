package training.capstone.pharma;

public class StatusEO {
	
	
	private String email;
	
	private int orderId;
	
	private String newStatus;
	
	public StatusEO()

	{
		
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getNewStatus() {
		return newStatus;
	}

	public void setNewStatus(String newStatus) {
		this.newStatus = newStatus;
	}

	public StatusEO(String email, int orderId, String newStatus) {
		super();
		this.email = email;
		this.orderId = orderId;
		this.newStatus = newStatus;
	}

	@Override
	public String toString() {
		return "StatusEO [email=" + email + ", orderId=" + orderId + ", newStatus=" + newStatus + "]";
	}
	
	
	
	
}
