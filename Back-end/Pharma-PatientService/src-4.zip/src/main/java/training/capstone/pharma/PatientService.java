package training.capstone.pharma;

import java.util.List;

public interface PatientService {
	
	
//Adition operations
	public PatientEO  addPatient(PatientEO patient);
	public UserEO     addUser(UserEO user);
	
	
	//Searching opeations
	public PatientEO findbyemail(String email);
	
	public Boolean IsUser(String email);
	
	public PatientEO   findPatientWithOrdersById(String patientId);
	
	public OrderEO findOrderById(int orderId);
	
	public List<PatientEO> findAllPatients();
	
	public int getLastOrderid(String patientId);
	
	//Updation  opeartions
	public void updateOrderStatus(String patientId, int orderId, String newStatus);
	
	

}
