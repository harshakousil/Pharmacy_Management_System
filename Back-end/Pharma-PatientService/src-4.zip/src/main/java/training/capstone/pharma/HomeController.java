package training.capstone.pharma;




import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/")
@CrossOrigin(origins = "http://localhost:3000")
public class HomeController {
	
	@Autowired
	private PatientService patientServiceRef;
	
	//This function should be called while Registration of new patient
	@PostMapping("/addPatient")
	public PatientEO addNewPatient(@RequestBody PatientEO patient)
	{
		System.out.println(patient.getEmail());
		
		Boolean alreadExists=patientServiceRef.IsUser(patient.getEmail());
		
		PatientEO NewPatientDet =patientServiceRef.addPatient(patient);
		
		if(alreadExists){
		
			throw new IllegalArgumentException("User already Exist's");
		}
		else
		{
			String email=patient.getEmail();
			String password=patient.getPassword();
			String rolename="Patient";
			UserEO user= new UserEO(email,password,rolename);	
			UserEO newUserDetails=patientServiceRef.addUser(user);
		}
		return NewPatientDet;
	}
	
	
	@PostMapping("/addOrder")
	public String addnewOrder(@RequestBody PatientEO patientDet )
	{
		PatientEO userDet =patientServiceRef.findbyemail(patientDet.getEmail());
		System.out.println(userDet);
		
		List<OrderEO> orders =patientDet.getOrders();
		
		int orderId=patientServiceRef.getLastOrderid(patientDet.getEmail());
		if(orders.size()==1)
		{
			OrderEO order =orders.get(0);
			order.setOrderId(orderId);
			userDet.getOrders().add(order);
		}
		else
		{
			
		}
		if(patientServiceRef.addPatient(userDet)!=null)
		{
			return "successs";
		}
		
		else return "failure";
	}
	
	@GetMapping("/PatientOrders/{PatientId}")
	public PatientEO findPatientWithOrdersById(@PathVariable("PatientId") String patientId)
	{
		PatientEO PatientOrderDet=patientServiceRef.findPatientWithOrdersById(patientId);
		return PatientOrderDet;
	}

	
	@PostMapping("/OrderStatus/{OrderId}")
	public OrderEO findOrderById(@PathVariable("OrderId") int orderId) 
	{
		OrderEO OrderDetails =patientServiceRef.findOrderById(orderId);
		return OrderDetails;
	}
	
	@PostMapping("/updateOrderStatus")
	public void updateOrderStatusofPatient(@RequestBody StatusEO data)
	{
		String patientId=data.getEmail();
		int orderId=data.getOrderId();
		String newStatus=data.getNewStatus();
		patientServiceRef.updateOrderStatus(patientId, orderId, newStatus);
	}
	
	@GetMapping("/findAllPatientOrders")
	public List<PatientEO> FindAllOrdersofPatients()
	{
		List<PatientEO> PatientDetails =patientServiceRef.findAllPatients();
		return PatientDetails;
	}
}
