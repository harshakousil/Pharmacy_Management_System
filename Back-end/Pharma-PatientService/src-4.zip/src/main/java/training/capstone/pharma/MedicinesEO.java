package training.capstone.pharma;



import org.springframework.data.annotation.Id;


public class MedicinesEO {
	@Id
	private Integer medicineId;
	
	private String medicineName;
	
	private String manufacturerName;
	
	private String quantity_ordered;
	
	private String unitPrice;
	
	private String isAvaible;
	
	
	
	
	public MedicinesEO()
	{
		
	
	}




	public Integer getMedicineId() {
		return medicineId;
	}




	public void setMedicineId(Integer medicineId) {
		this.medicineId = medicineId;
	}




	public String getMedicineName() {
		return medicineName;
	}




	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}




	public String getManufacturerName() {
		return manufacturerName;
	}




	public void setManufacturerName(String manufacturerName) {
		this.manufacturerName = manufacturerName;
	}




	public String getQuantity_ordered() {
		return quantity_ordered;
	}




	public void setQuantity_ordered(String quantity_ordered) {
		this.quantity_ordered = quantity_ordered;
	}




	public String getUnitPrice() {
		return unitPrice;
	}




	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}




	public String getIsAvaible() {
		return isAvaible;
	}




	public void setIsAvaible(String isAvaible) {
		this.isAvaible = isAvaible;
	}




	public MedicinesEO(Integer medicineId, String medicineName, String manufacturerName, String quantity_ordered,
			String unitPrice, String isAvaible) {
		super();
		this.medicineId = medicineId;
		this.medicineName = medicineName;
		this.manufacturerName = manufacturerName;
		this.quantity_ordered = quantity_ordered;
		this.unitPrice = unitPrice;
		this.isAvaible = isAvaible;
	}




	@Override
	public String toString() {
		return "MedicinesEO [medicineId=" + medicineId + ", medicineName=" + medicineName + ", manufacturerName="
				+ manufacturerName + ", quantity_ordered=" + quantity_ordered + ", unitPrice=" + unitPrice
				+ ", isAvaible=" + isAvaible + "]";
	}




}