package training.capstone.pharma;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PatientServiceImpl implements PatientService {
	
	@Autowired
	PatientRepository patientRepoRef;
	
	@Autowired
	UserRepository userRepoRef;

	@Override
	public PatientEO addPatient(PatientEO patient) {
		// TODO Auto-generated method stub
		PatientEO patinetDet =patientRepoRef.save(patient);
		return patinetDet;
	}

	@Override
	public PatientEO findPatientWithOrdersById(String patientId) {
		// TODO Auto-generated method stub
		
		PatientEO patientByOrders =patientRepoRef.findByEmail(patientId);
		return patientByOrders;
	}

	@Override
	public OrderEO findOrderById(int orderId) {
		// TODO Auto-generated method stub
		OrderEO orders=patientRepoRef.findOrderById(orderId);
		return orders;
	}

	
	public void updateOrderStatus(String patientId, int orderId, String newStatus) {
		System.out.println(patientId);
        PatientEO patient = findPatientWithOrdersById(patientId);
        
        if (patient != null && patient.getOrders() != null) {
            for (OrderEO order : patient.getOrders()) {
                if (order.getOrderId()==orderId) {
                    order.setStatus(newStatus);
                    patientRepoRef.save(patient);
                    break;
                }
            }
        }
    }

	@Override
	public UserEO addUser(UserEO user) {

	UserEO userDet=userRepoRef.save(user);
		return userDet;
	}

	@Override
	public Boolean IsUser(String email) {
		
		UserEO userDet =userRepoRef.findByemail(email);
		
		if(userDet==null)
		{
			return false;
		}
		else return true;
	}

	@Override
	public PatientEO findbyemail(String email) {
		
		return patientRepoRef.findByEmail(email);
	}

	@Override
	public List<PatientEO> findAllPatients() {
		// TODO Auto-generated method stub
	List<PatientEO> patientDet=	patientRepoRef.findAll();
	
		return patientDet ;
	}

	@Override
	public int getLastOrderid(String patientId) {
		
		 PatientEO PatientDet= patientRepoRef.findByEmail(patientId);
		 if(PatientDet!=null && PatientDet.getOrders() !=null && !PatientDet.getOrders().isEmpty())
		 {
			 OrderEO lastOrder=PatientDet.getOrders().get(PatientDet.getOrders().size()-1);
			 int lastOrderId=lastOrder.getOrderId();
			 return lastOrderId+1;
		 }
		 else
		 {
			 return 1;
			
		 }
	}








}
