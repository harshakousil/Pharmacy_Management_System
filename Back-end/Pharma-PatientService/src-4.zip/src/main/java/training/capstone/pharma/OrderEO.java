package training.capstone.pharma;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;

public class OrderEO {
	
	@Id
	private int orderId;
	
	private Date orderDate;
	
	private Date deliveryDate;
	
	
	private String status;
	
	private List<MedicinesEO> medicines;

	
	public OrderEO()
	{
		
	}


	@Override
	public String toString() {
		return "OrderEO [orderId=" + orderId + ", orderDate=" + orderDate + ", deliveryDate=" + deliveryDate
				+ ", status=" + status + ", medicines=" + medicines + "]";
	}


	public OrderEO(int orderId, Date orderDate, Date deliveryDate, String status, List<MedicinesEO> medicines) {
		super();
		this.orderId = orderId;
		this.orderDate = orderDate;
		this.deliveryDate = deliveryDate;
		this.status = status;
		this.medicines = medicines;
	}


	public int getOrderId() {
		return orderId;
	}


	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}


	public Date getOrderDate() {
		return orderDate;
	}


	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
		
		Date dateString =orderDate ;
        SimpleDateFormat dateFormat = new SimpleDateFormat("yy:mm:dd");

        try {
            // Now, let's extract year, month, and day to create the equivalent date object
            int year = dateString.getYear() + 1900; // Year is 1900-based
            int month = dateString.getMonth();
            int day = dateString.getDate();

            // Create a Date object using the extracted values
            Date convertedDate = new Date(year, month, day);
            this.orderDate=convertedDate;
        } catch (Exception e) {
            e.printStackTrace();
        }
	}


	public Date getDeliveryDate() {
		return deliveryDate;
	}


	public void setDeliveryDate(Date deliveryDate) {
		this.deliveryDate = deliveryDate;
		Date dateString =orderDate ;
        SimpleDateFormat dateFormat = new SimpleDateFormat("yy:mm:dd");

        try {
            // Now, let's extract year, month, and day to create the equivalent date object
            int year = dateString.getYear() + 1900; // Year is 1900-based
            int month = dateString.getMonth();
            int day = dateString.getDate();

            // Create a Date object using the extracted values
            Date convertedDate = new Date(year, month, day);
            this.deliveryDate=convertedDate;
        } catch (Exception e) {
            e.printStackTrace();
        }
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public List<MedicinesEO> getMedicines() {
		return medicines;
	}


	public void setMedicines(List<MedicinesEO> medicines) {
		this.medicines = medicines;
	}
	

}
