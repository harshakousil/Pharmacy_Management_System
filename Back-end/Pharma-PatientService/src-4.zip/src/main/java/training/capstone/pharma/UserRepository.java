package training.capstone.pharma;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends MongoRepository<UserEO ,String> {
	
	@Query("{'email' : ?0}")                 
	 UserEO findByemail(String email);
	
	
	
	 //Named Query to add patient to one of user's of application
    @SuppressWarnings("unchecked")
	UserEO save(UserEO user);
	
	
}
