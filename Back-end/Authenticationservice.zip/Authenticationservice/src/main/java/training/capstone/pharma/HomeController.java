package training.capstone.pharma;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;




@RestController
@RequestMapping("/")
@CrossOrigin(origins = "http://localhost:3000")
public class HomeController {

	
	@Autowired
	private UserService userService;
	
	
	 // Login Validation
    @PostMapping("/login")
    public String  validateLogin(@RequestBody UserEO user) {
    	
    	String email= user.getEmail();
    	System.out.println(email);
    	String pass= user.getPassword();
        UserEO UserDetails = userService.findByEmail(email);
        UserEO passDetails = userService.findBypassword(pass);
        if (UserDetails != null ) {
        	
        	
        	String roleName=UserDetails.getRolename();
        	String password =passDetails.getPassword();
        	
            return roleName;
        } else {
        	throw new ResponseStatusException(HttpStatus.NO_CONTENT, "User Doesn't exist");
        }
    }
    
}
