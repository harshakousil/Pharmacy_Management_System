package training.capstone.pharma;


public interface UserService {
	
	
	public UserEO findByEmail(String email);
	
	public UserEO adduser(UserEO user);
	
	public UserEO  findBypassword(String password);

}
