package training.capstone.pharma;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthenticationserviceApplication implements CommandLineRunner {

	@Autowired	
	UserService userserviceRef;
	
	
	
	public static void main(String[] args) {
		SpringApplication.run(AuthenticationserviceApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
//		userserviceRef.adduser(new UserEO("Admin@gmail.com","Admin123","ADMIN"));
//		
//		userserviceRef.adduser(new UserEO("Incharge@gmail.com","Incharge123","Incharge"));
//		
//		userserviceRef.adduser(new UserEO("Patient@gmail.com","Patient123","PATIENT"));
//		
	}
}
