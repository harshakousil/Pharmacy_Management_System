package training.capstone.pharma;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class UserServiceImpl implements UserService {

	
	 @Autowired(required=true)
	 private UserRepository userRepoRef;

	@Override
	public UserEO findByEmail(String email) {
		// TODO Auto-generated method stub
		return userRepoRef.findByemail(email);
	}

	@Override
	public UserEO adduser(UserEO user) {
		// TODO Auto-generated method stub
		return userRepoRef.save(user);
	}

	@Override
	public UserEO findBypassword(String password) {
		// TODO Auto-generated method stub
		return userRepoRef.findBypassword(password);
	}
	    
}
