package training.captone.medicines;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PharmaMedicineServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
