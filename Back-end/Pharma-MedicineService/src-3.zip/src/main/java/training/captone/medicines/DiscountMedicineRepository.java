package training.captone.medicines;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface DiscountMedicineRepository extends MongoRepository<DiscountMedicineEO, String> {

	 @Query("{}")
	 List<DiscountMedicineEO> findAllDiscountedData();
	
	
}
