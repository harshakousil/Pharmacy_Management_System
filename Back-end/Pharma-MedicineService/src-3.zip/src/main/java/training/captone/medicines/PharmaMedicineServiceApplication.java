package training.captone.medicines;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PharmaMedicineServiceApplication implements CommandLineRunner {

	@Autowired
	MedicineService medicineDet;
	public static void main(String[] args) {
		SpringApplication.run(PharmaMedicineServiceApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		//Date expiryDate = new Date(123, 11, 31); 
		//medicineDet.addMedicines(new MedicinesEO(1,"Paracetomol","For Relief","ABC","1000","1",expiryDate));
	}

}
