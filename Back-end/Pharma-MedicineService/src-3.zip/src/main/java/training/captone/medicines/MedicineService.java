package training.captone.medicines;

import java.util.List;

public interface MedicineService {
	
	
	public List<MedicinesEO> findAllMedicines();

	
	public MedicinesEO addMedicines(MedicinesEO medicine);
	
	public MedicinesEO updateMedicines(MedicinesEO medicine);
	
	
	public String DeleteMedicines(Integer medicineId);
	
	
}
