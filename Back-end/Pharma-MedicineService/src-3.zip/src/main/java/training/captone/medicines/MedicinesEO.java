package training.captone.medicines;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Date;
import java.util.TimeZone;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("medicines")
public class MedicinesEO {
	
	@Id
	private Integer medicineId;
	
	private String medicineName;
	
	private String medicineDescription;
	
	private String manufacturerName;
	
	private String stockQuantity;
	
	private String unitPrice;
	
	private Date  expiryDate;
	
	
	private byte[] image;
	
	
	
	public MedicinesEO()
	{
		
	
	}



	public MedicinesEO(Integer medicineId, String medicineName, String medicineDescription, String manufacturerName,
			String stockQuantity, String unitPrice, Date expiryDate, byte[] image) {
		super();
		this.medicineId = medicineId;
		this.medicineName = medicineName;
		this.medicineDescription = medicineDescription;
		this.manufacturerName = manufacturerName;
		this.stockQuantity = stockQuantity;
		this.unitPrice = unitPrice;
		this.expiryDate = expiryDate;
		this.image = image;
	}



	public Integer getMedicineId() {
		return medicineId;
	}



	public void setMedicineId(Integer medicineId) {
		this.medicineId = medicineId;
	}



	public String getMedicineName() {
		return medicineName;
	}



	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}



	public String getMedicineDescription() {
		return medicineDescription;
	}



	public void setMedicineDescription(String medicineDescription) {
		this.medicineDescription = medicineDescription;
	}



	public String getManufacturerName() {
		return manufacturerName;
	}



	public void setManufacturerName(String manufacturerName) {
		this.manufacturerName = manufacturerName;
	}



	public String getStockQuantity() {
		return stockQuantity;
	}



	public void setStockQuantity(String stockQuantity) {
		this.stockQuantity = stockQuantity;
	}



	public String getUnitPrice() {
		return unitPrice;
	}



	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}



	public Date  getExpiryDate() {
		return expiryDate;
	}



	public void setExpiryDate(Date  expiryDate) {
		
		 	Date dateString =expiryDate ;
	        SimpleDateFormat dateFormat = new SimpleDateFormat("yy:mm:dd");

	        try {
	            // Now, let's extract year, month, and day to create the equivalent date object
	            int year = dateString.getYear() + 1900; // Year is 1900-based
	            int month = dateString.getMonth();
	            int day = dateString.getDate();

	            // Create a Date object using the extracted values
	            Date convertedDate = new Date(year, month, day);
	            this.expiryDate=convertedDate;
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        
	    }

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}



	@Override
	public String toString() {
		return "MedicinesEO [medicineId=" + medicineId + ", medicineName=" + medicineName + ", medicineDescription="
				+ medicineDescription + ", manufacturerName=" + manufacturerName + ", stockQuantity=" + stockQuantity
				+ ", unitPrice=" + unitPrice + ", expiryDate=" + expiryDate +  ", image="
				+ Arrays.toString(image) + "]";
	}

	
	
	



}