package training.captone.medicines;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MedicineServiceImpl implements MedicineService {

	
	
	@Autowired
	MedicineRepository medRepoRef;
	
	@Override
	public List<MedicinesEO> findAllMedicines() {
		
		List<MedicinesEO> medicinesList =medRepoRef.findAll();
		
		return medicinesList;
	}

	@Override
	public MedicinesEO addMedicines(MedicinesEO medicine) {
		
		MedicinesEO medicineData =medRepoRef.save(medicine);
		return medicineData;
	}

	@Override
	public MedicinesEO updateMedicines(MedicinesEO medicine) {
		
		MedicinesEO updatedMedicineData =medRepoRef.save(medicine);
		return updatedMedicineData;
	}

	@Override
	public String DeleteMedicines(Integer medicineId) {

		 try
		 {
			 medRepoRef.deleteById(medicineId);
			 return("Success");
		 }
		 catch(Exception e)
		 {
			 e.printStackTrace();
			 
			 return("unable to Delete");
		 }

	}

}
