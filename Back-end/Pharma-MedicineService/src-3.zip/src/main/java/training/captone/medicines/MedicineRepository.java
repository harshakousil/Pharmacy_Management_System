package training.captone.medicines;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface MedicineRepository extends MongoRepository<MedicinesEO, Integer> {
	
	
	//Retrieve all medicines from database;
	 @Query("{}")
	 List<MedicinesEO> findAllMedicines();
	 
	 
	//Updates or adds the  the Medicine Document
	@SuppressWarnings("unchecked")
	@Transactional
	MedicinesEO  save(MedicinesEO medicine);
	
	
	//Delete the medicines Document
	 @Transactional
	 @Query("{'id': ?0}")
	 void deleteMedicineById(String medicineId);
	 
	 
	 
//	@Modifying
//	@Transactional
//	@Query("{'id': ?0}")
//	MedicinesEO medicineData  updateMedicine(String medicineId, MedicinesEO updatedMedicine);

}
