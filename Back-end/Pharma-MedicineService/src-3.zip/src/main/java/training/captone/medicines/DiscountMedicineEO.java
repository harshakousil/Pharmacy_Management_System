package training.captone.medicines;


import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

@Document("DiscountedMedicines")
public class DiscountMedicineEO {
	
	
	private String schemeName;
	
	private String schemeType;
	
	private String schemeValue;
	
	private Date fromDate;
	
	private Date toDate;
	
	private List<MedicinesEO> medicines;
	

	public DiscountMedicineEO()
	{
		
	}


	public String getSchemeName() {
		return schemeName;
	}


	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}


	public String getSchemeType() {
		return schemeType;
	}


	public void setSchemeType(String schemeType) {
		this.schemeType = schemeType;
	}


	public String getSchemeValue() {
		return schemeValue;
	}


	public void setSchemeValue(String schemeValue) {
		this.schemeValue = schemeValue;
	}


	public Date getFromDate() {
		return fromDate;
	}


	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}


	public Date getToDate() {
		return toDate;
	}


	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}


	public List<MedicinesEO> getMedicines() {
		return medicines;
	}


	public void setMedicines(List<MedicinesEO> medicines) {
		this.medicines = medicines;
	}


	public DiscountMedicineEO(String schemeName, String schemeType, String schemeValue, Date fromDate, Date toDate,
			List<MedicinesEO> medicines) {
		super();
		this.schemeName = schemeName;
		this.schemeType = schemeType;
		this.schemeValue = schemeValue;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.medicines = medicines;
	}


	@Override
	public String toString() {
		return "DiscountMedicineEO [schemeName=" + schemeName + ", schemeType=" + schemeType + ", schemeValue="
				+ schemeValue + ", fromDate=" + fromDate + ", toDate=" + toDate + ", medicines=" + medicines + "]";
	}
	
	
	
	
}
