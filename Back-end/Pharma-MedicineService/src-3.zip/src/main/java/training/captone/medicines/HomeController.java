package training.captone.medicines;


import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
@CrossOrigin(origins = "http://localhost:3000" )
public class HomeController {
	
	@Autowired
	private MedicineService medservice;
	
	@Autowired
	private DiscountMedicineRepository DiscountRepoRef;
	
	
	
	@PostMapping("/addscheme")
	private String addNewScheme(@RequestBody DiscountMedicineEO scheme)
	{
		
		List<MedicinesEO> AllMedicines = medservice.findAllMedicines();
		List<MedicinesEO> discountedMedicines= new ArrayList<>();
		System.out.println(scheme);
		for (Iterator iterator = AllMedicines.iterator(); iterator.hasNext();) {
			MedicinesEO medicinesEO = (MedicinesEO) iterator.next();
			
				Integer medicineId= medicinesEO.getMedicineId();
				String medicineName=medicinesEO.getMedicineName();
				
				String medicineDiscription=medicinesEO.getMedicineDescription();
				
				String manufacturerName=medicinesEO.getManufacturerName();
				
				String stockQuantity=medicinesEO.getStockQuantity();
			
				String unitPrice=medicinesEO.getUnitPrice();
				
		if(scheme.getSchemeType().equalsIgnoreCase("Flat"))
		{
			if(scheme.getSchemeValue().equalsIgnoreCase("Medicines Quantity >75000"))
					{
					if(Integer.parseInt(stockQuantity)>=75000 && Integer.parseInt(stockQuantity)<=10000)
						{
							
							unitPrice= String.valueOf(Integer.parseInt(unitPrice) * 0.60);
								
						}
					}
			else if(scheme.getSchemeValue().equalsIgnoreCase("Medicines Quantity >100000"))
			{
				if(Integer.parseInt(stockQuantity)>=100000 && Integer.parseInt(stockQuantity)<=10000)
				{
				
					unitPrice= String.valueOf(Integer.parseInt(unitPrice) * 0.60);
						
				}
			}
		}
		else if(scheme.getSchemeType().equalsIgnoreCase("%Based"))
		{
			int schemeValue=Integer.parseInt(scheme.getSchemeValue());
			
		
			 double reductionAmount = Double.parseDouble(unitPrice) * (schemeValue / 100.0);
			 unitPrice=String.valueOf(Double.parseDouble(unitPrice) - reductionAmount);
			 System.out.println(unitPrice);
		}
		
		Date expiryDate=medicinesEO.getExpiryDate();
		
		byte[] image=medicinesEO.getImage();
		discountedMedicines.add(new MedicinesEO(medicineId,medicineName,medicineDiscription,manufacturerName,stockQuantity,unitPrice,expiryDate,image));
		}
		scheme.setMedicines(discountedMedicines);
		
		DiscountRepoRef.save(scheme);
		return "Success";
	}
	@PostMapping("/addMedicine")
	private MedicinesEO addMedicines(@RequestBody MedicinesEO Medicine )
	{
		// byte[] imageData = Medicine.getImage();
//		System.out.println(imageData);
		MedicinesEO AddedMedicine =medservice.addMedicines(Medicine);
		return AddedMedicine;
	}
	
	@GetMapping("/GetAllMedicines")
	private List<MedicinesEO> AllMedicines()
	{
		
	List<MedicinesEO> medicinesList =medservice.findAllMedicines();
	return medicinesList;
	}
	@GetMapping("/GetAllDiscountedMedicines")
	private List<DiscountMedicineEO> AllDiscountedMedicines()
	{
		
	List<DiscountMedicineEO> DiscountmedicinesList=DiscountRepoRef.findAllDiscountedData();

	return DiscountmedicinesList;
	}
	
	@PostMapping("/updateMedicine")
	private MedicinesEO udpateMedicines(@RequestBody MedicinesEO Medicine )
	{
		System.out.println(Medicine);
		MedicinesEO updateMedicine =medservice.addMedicines(Medicine);
		return updateMedicine;
	}
	
	@GetMapping(value="/deleteMedicine/{medicineId}")
	private String deleteMedicine(@PathVariable("medicineId") Integer medicineId){
		
		String response =medservice.DeleteMedicines(medicineId);
		
		return response;
	}
	

}
