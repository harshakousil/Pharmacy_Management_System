package training.iqgateway.pharma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PharmaGenerateReportServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
