package training.iqgateway.pharma;

import java.util.List;

public interface OrderReportsService {

	
	public List<OrderReportsEO> findAllOrders();
	
	
	public OrderReportsEO placeOrder(OrderReportsEO order);
	
	public List<OrderReportsEO> findOrderByStatus(String status);
}
