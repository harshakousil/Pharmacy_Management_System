package training.iqgateway.pharma;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface OrderReportsRepositroy extends MongoRepository<OrderReportsEO,String> {
	
	 @Query("{}")
	 List<OrderReportsEO> findAllOrders();
	 
	@Query("{'status' : ?0}")
	List<OrderReportsEO> findOrdersByStatus(String status);
	
	OrderReportsEO save(OrderReportsEO order);
}
