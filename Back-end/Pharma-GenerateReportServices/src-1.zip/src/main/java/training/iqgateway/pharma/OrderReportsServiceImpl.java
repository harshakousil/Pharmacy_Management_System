package training.iqgateway.pharma;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderReportsServiceImpl implements OrderReportsService {

	
	@Autowired
	OrderReportsRepositroy orderRepoRef;
	@Override
	public List<OrderReportsEO> findAllOrders() {
		
		List<OrderReportsEO> AllOrders =orderRepoRef.findAll();
		return AllOrders;
	}
	@Override
	public OrderReportsEO placeOrder(OrderReportsEO Order) {

		OrderReportsEO newOrder=orderRepoRef.save(Order);
		
		return newOrder;
	}
	@Override
	public List<OrderReportsEO> findOrderByStatus(String status) {
	
		List<OrderReportsEO> OrdersByStatus=orderRepoRef.findOrdersByStatus(status);
		return OrdersByStatus;
	}

}
