package training.iqgateway.pharma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PharmaGenerateReportServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(PharmaGenerateReportServicesApplication.class, args);
	}

}
